# Demo script for judges (about 6 minutes)

**Before you start:** `npm run dev`, open http://localhost:5173, sign in as the administrator (password printed by `npm run db:seed`).

1. **The pitch (30 s).** Open the landing page. "A temperature log is only useful if you can trust it. ColdChain Sentinel
   records readings in a SHA-256 hash chain so edits, deletions and reordering are detectable."
2. **Live data (45 s).** Go to *Live monitoring*, scroll to the *Simulator* card and click *Start simulator*
   (or *Generate 30 readings now* for instant data). Point at the **SIMULATION** badge: "Everything here is labelled as simulated.
   With the ESP32 online it switches to **LIVE HARDWARE** and hardware records are labelled Hardware."
3. **A genuine excursion is not tampering (60 s).** On the same card pick a simulated device and click *Trigger temperature excursion*. A **temperature** alert
   appears (amber). Open *Integrity ledger* → *Verify chain*: still **Verified**. "A real warm reading is a valid record."
4. **Tamper detection (2 min).** Open *Tamper lab* (isolated sandbox database, the real ledger is never touched).
   - *Verify sandbox ledger* → all hashes match.
   - Pick record 12, change it to 3.3 °C (*Change temperature*), *Verify*: record 12 **Invalid hash**, record 13 **Broken link**.
     The table shows original versus modified data.
   - *Reset sandbox*. Now click *Edit and re-hash the whole chain*, *Verify*: hashes and links look consistent (the attacker fixed them),
     but **Checkpoint mismatch** appears: "the signed checkpoint is kept outside the database, so recomputing every hash is not enough."
   - *Delete record* and *Swap with next record* show *Missing record* and *Reordered*.
   - *Reset sandbox* restores the identical, verified data.
5. **Hardware (60 s).** Show the ESP32 with the OLED, the wiring table (docs/WIRING.md), and the *Devices* page: authentication status,
   firmware version, last seen. Warm the probe with your hand; the excursion appears live.
6. **Honest limits (30 s).** Hash chain proves the *stored history* was not changed; it cannot prove a compromised sensor measured correctly.
   Checkpoints should be copied off the server for real independence. Educational prototype, not certified.

**Q&A hints:** SHA-256 is a hash, not encryption. Device requests are authenticated with HMAC-SHA-256. Secrets are AES-256-GCM encrypted at rest and shown once.
Concurrent ingestion is serialised by a write transaction plus a UNIQUE(device, sequence) constraint.
