# REST API (base path `/api/v1`)

Responses are JSON. Errors always look like `{"error":{"code":"...","message":"...","details":...}}`.
Browser endpoints use an httpOnly session cookie and require the header `X-Requested-With: ColdChainSentinel` on
every non-GET request (anti-CSRF). Device ingestion uses HMAC signatures instead of cookies.

## Device ingestion
`POST /readings` – headers: `X-Device-Id: <id>`, `X-Signature: hex(HMAC-SHA256(deviceSecret, rawBody))`, `Content-Type: application/json`

```json
{ "deviceId": "COLD-BOX-01", "sequence": 12, "temperatureC": 4.2, "recordedAt": "2026-10-24T10:30:00.000Z",
  "sensorStatus": "OK", "firmwareVersion": "1.0.0" }
```
`humidityPct` is optional. `sensorStatus` is `OK`, `DISCONNECTED` or `INVALID` (non-OK readings carry no temperature).
Unknown fields are rejected. Body limit 8 kB. Rate-limited.

| Status | Meaning |
|---|---|
| 201 | accepted and hash-chained (`record.hash`, `record.previousHash`, `nextSequence`) |
| 200 | duplicate of an already-accepted reading (idempotent retry) |
| 400 | validation error |
| 401 | device authentication failed (deliberately vague: wrong secret, unknown or revoked device) |
| 409 | `SEQUENCE_CONFLICT` (same sequence, different measurement) or `STALE_SEQUENCE` (sequence not newer than the last accepted) |
| 413 / 429 | too large / rate limited |

## Public
`GET /health`

## Session (cookie)
`POST /auth/login` `{email,password}` · `POST /auth/logout` · `GET /auth/me` · `GET /status`

## Read (any signed-in user)
`GET /overview` · `GET /readings` · `GET /readings/:id` · `GET /ledger` · `GET /ledger/summary` · `GET /ledger/verifications` ·
`GET /ledger/checkpoints` · `GET /devices` · `GET /alerts` · `GET /alerts/summary` · `GET /shipments` · `GET /shipments/:id` · `GET /settings` ·
`GET /reports/temperature | ledger | incidents | shipments/:id` (`format=csv|json`, filters `deviceId`, `shipmentId`, `from`, `to`)

List endpoints take `page`, `pageSize` and filters (see the Zod schemas in `backend/src/routes`).

## Administrator only
`POST /ledger/verify` `{scope:"LEDGER"|"DEVICE"|"RANGE", deviceId?, from?, to?}` · `POST /ledger/checkpoints` `{deviceId}` ·
`POST /devices` · `POST /devices/:id/revoke` · `POST /devices/:id/rotate` · `POST /shipments` · `PATCH /shipments/:id` ·
`PATCH /alerts/:id/acknowledge` · `PATCH /alerts/:id/resolve` · `PATCH /settings` · `GET /audit` · `GET|POST /users`, `PATCH /users/:id`

## Development only (administrator, and 404 when `NODE_ENV=production` or `ENABLE_DEV_ENDPOINTS=false`)
`GET /dev/simulator` · `POST /dev/simulator/start|stop|excursion|disconnect|generate` · `PATCH /dev/simulator` · `POST /dev/demo/reset` `{confirm:true}` ·
`GET /dev/sandbox` · `POST /dev/sandbox/reset|verify|tamper`

## Live updates
Socket.IO on the same origin, authenticated with the session cookie. Events: `reading:new`, `alert:new`, `alert:updated`,
`verification:done`, `device:updated`, `simulator:state`, `sandbox:updated`, `settings:updated`. The UI falls back to polling when the socket is down.

## Verification statuses
`VERIFIED`, `INVALID_HASH`, `BROKEN_LINK`, `MISSING_RECORD`, `SEQUENCE_GAP`, `REORDERED`, `CHECKPOINT_MISMATCH`,
and `UNVERIFIED` for records that no verification run has covered yet.
