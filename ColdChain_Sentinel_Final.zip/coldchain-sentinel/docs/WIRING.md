# Hardware wiring (ESP32 DevKit + DS18B20 + 0.96" I2C OLED)

**Parts:** ESP32 DevKit (ESP32-WROOM-32, 30 or 38 pin), DS18B20 waterproof probe (3 wires), one **4.7 kΩ resistor**,
0.96" SSD1306 I2C OLED (4 pins: GND, VCC, SCL, SDA), breadboard, jumper wires, USB data cable (not a charge-only cable).

Everything runs at **3.3 V**. Do not connect any of these parts to 5 V.

| # | From (part pin) | To (ESP32 pin) | Notes |
|---|-----------------|----------------|-------|
| 1 | DS18B20 **VCC** (red) | **3V3** | |
| 2 | DS18B20 **GND** (black) | **GND** | |
| 3 | DS18B20 **DATA** (yellow / white) | **GPIO 4** | 1-Wire data line |
| 4 | **4.7 kΩ resistor**, leg A | **3V3** | pull-up |
| 5 | **4.7 kΩ resistor**, leg B | **GPIO 4** (same row as DATA) | pull-up between DATA and 3V3 |
| 6 | OLED **VCC** | **3V3** | |
| 7 | OLED **GND** | **GND** | |
| 8 | OLED **SDA** | **GPIO 21** | I2C data |
| 9 | OLED **SCL** | **GPIO 22** | I2C clock |

```
            ESP32                       DS18B20 probe
        +-----------+                  red    ---- 3V3 ----+---- [4.7k] ----+
        |       3V3 |------------------------------------- |               |
        |       GND |------------------- black ------------|               |
        |   GPIO 4  |------------------- yellow (DATA) ----+---------------+
        |  GPIO 21  |--- SDA  \
        |  GPIO 22  |--- SCL   >  OLED (VCC to 3V3, GND to GND)
        +-----------+
```

If you use a **breakout module** for the DS18B20 that already has a resistor on the board (3 pins marked S/+/-),
you do not need the extra resistor.

Wire colours of probes vary: red = VCC, black = GND, yellow or white = DATA is the common convention. Check your probe's datasheet.

## Why these pins
GPIO 4 is a safe general-purpose pin (not a boot-strapping pin, no conflict with Wi-Fi). GPIO 21/22 are the ESP32's
default I2C pins. You can change pins in `config.h` (`PIN_ONEWIRE`, `PIN_I2C_SDA`, `PIN_I2C_SCL`).
Avoid GPIO 0, 2, 12, 15 for the sensor (boot strapping) and GPIO 34-39 (input only, no pull-ups).

## Checks
* OLED stays blank: wrong address (try `OLED_ADDRESS 0x3D`), SDA/SCL swapped, or VCC not connected.
* Serial Monitor says "no DS18B20 found" or the screen shows SENSOR ERR: DATA not on GPIO 4, missing pull-up resistor, or a loose wire.
* Reading is exactly **85.0 °C**: the sensor just powered on or the pull-up is missing; the firmware reports it as INVALID, not as a temperature.
* Reading is **-127 °C**: sensor disconnected; reported as DISCONNECTED.
