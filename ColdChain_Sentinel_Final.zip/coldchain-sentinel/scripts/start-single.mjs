// Single-process mode: backend serves the built frontend at http://localhost:4000
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const isWin = process.platform === "win32";
const p = spawn(isWin ? "npm.cmd" : "npm", ["run", "start"], { cwd: path.join(root, "backend"), stdio: "inherit", shell: isWin, env: { ...process.env, SERVE_FRONTEND: "true" } });
process.on("SIGINT", () => p.kill("SIGINT"));
p.on("exit", (c) => process.exit(c ?? 0));
