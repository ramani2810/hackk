// Creates backend/.env with freshly generated random keys (only if it does not exist yet).
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const example = path.join(root, "backend", ".env.example");
const target = path.join(root, "backend", ".env");
const feTarget = path.join(root, "frontend", ".env");

if (fs.existsSync(target)) {
  console.log("backend/.env already exists - leaving it unchanged.");
} else {
  const key = () => crypto.randomBytes(32).toString("hex");
  let text = fs.readFileSync(example, "utf8");
  text = text.replace(/^DEVICE_SECRET_ENC_KEY=.*$/m, `DEVICE_SECRET_ENC_KEY=${key()}`)
             .replace(/^CHECKPOINT_SIGNING_KEY=.*$/m, `CHECKPOINT_SIGNING_KEY=${key()}`);
  fs.writeFileSync(target, text, { mode: 0o600 });
  console.log("Created backend/.env with new random keys.");
}
if (!fs.existsSync(feTarget)) {
  fs.copyFileSync(path.join(root, "frontend", ".env.example"), feTarget);
  console.log("Created frontend/.env.");
}
