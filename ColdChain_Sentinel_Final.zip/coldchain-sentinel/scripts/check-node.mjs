const [maj, min] = process.versions.node.split(".").map(Number);
if (maj < 22 || (maj === 22 && min < 13)) {
  console.error(`Node.js ${process.versions.node} is too old. ColdChain Sentinel needs Node.js 22.13 or newer (https://nodejs.org).`);
  process.exit(1);
}
console.log(`Node.js ${process.versions.node} OK`);
