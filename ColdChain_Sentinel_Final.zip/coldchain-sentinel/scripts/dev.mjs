// Starts backend and frontend together in one terminal. Ctrl+C stops both.
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const isWin = process.platform === "win32";
const npm = isWin ? "npm.cmd" : "npm";
const procs = [];
const start = (name, cwd, args) => {
  const p = spawn(npm, args, { cwd: path.join(root, cwd), stdio: "inherit", shell: isWin });
  p.on("exit", (code) => { if (code && !shuttingDown) { console.error(`\n[${name}] exited with code ${code}`); shutdown(); } });
  procs.push(p);
};
let shuttingDown = false;
function shutdown() {
  shuttingDown = true;
  for (const p of procs) { try { isWin ? spawn("taskkill", ["/pid", String(p.pid), "/T", "/F"]) : p.kill("SIGINT"); } catch {} }
  setTimeout(() => process.exit(0), 1500);
}
process.on("SIGINT", shutdown); process.on("SIGTERM", shutdown);
start("backend", "backend", ["run", "start"]);
start("frontend", "frontend", ["run", "dev"]);
