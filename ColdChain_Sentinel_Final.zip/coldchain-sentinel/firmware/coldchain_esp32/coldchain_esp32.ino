/*
  ColdChain Sentinel - ESP32 firmware (educational prototype)

  Reads a DS18B20 temperature sensor, shows status on a 0.96" SSD1306 OLED, and sends each reading to the
  backend as JSON signed with HMAC-SHA-256 (header X-Signature, computed over the exact request body with the
  per-device secret). The backend verifies the signature and adds the reading to its SHA-256 hash chain.

  Libraries (Arduino IDE > Library Manager):  OneWire, DallasTemperature, Adafruit SSD1306, Adafruit GFX Library
  Board package: "esp32 by Espressif Systems" (Boards Manager). Board: "ESP32 Dev Module".

  Design notes
  - Sequence numbers never repeat after a restart: the next block of SEQ_RESERVE_BLOCK numbers is reserved in
    flash (Preferences/NVS) BEFORE being used, and after a reboot the device continues from the reserved ceiling.
    The skipped numbers show up on the server as an acknowledged "sequence gap" (not as tampering).
  - Unsent readings are kept in a RAM queue (MAX_BUFFERED) and re-sent oldest-first with the IDENTICAL body.
    A reboot loses the queue (also reported as a gap). The server de-duplicates by (device, sequence).
  - The clock is set by NTP. Until it is synchronised, "recordedAt" is omitted and the server stores
    "unsynchronised device clock" and relies on its own receipt time.
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <Wire.h>
#include <time.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "mbedtls/md.h"

#if __has_include("config.h")
#include "config.h"
#else
#error "config.h not found. Copy config.example.h to config.h and fill in your Wi-Fi, backend URL, device ID and secret."
#endif

OneWire oneWire(PIN_ONEWIRE);
DallasTemperature sensors(&oneWire);
Adafruit_SSD1306 display(128, 64, &Wire, -1);
Preferences prefs;
bool oledOk = false;

struct Pending {
  uint32_t seq;
  char body[300];
};
Pending queue[MAX_BUFFERED];
int qHead = 0, qCount = 0;

uint32_t nextSeq = 1;
uint32_t reservedUntil = 0;
unsigned long lastSample = 0;
unsigned long lastSendAttempt = 0;
unsigned long backoffMs = 0;
float lastTemp = NAN;
const char *lastSensorStatus = "OK";
int lastHttp = 0;
bool backendOk = false;
uint32_t sentCount = 0;

// ---------- sequence persistence ----------
void reserveSequenceBlock() {
  reservedUntil = nextSeq + SEQ_RESERVE_BLOCK;
  prefs.putUInt("ceiling", reservedUntil);  // written BEFORE the numbers are used
}

void initSequence() {
  prefs.begin("coldchain", false);
  uint32_t ceiling = prefs.getUInt("ceiling", 0);
  nextSeq = ceiling + 1;  // continue after everything that may have been used before the restart
  reserveSequenceBlock();
}

uint32_t takeSequence() {
  if (nextSeq >= reservedUntil) reserveSequenceBlock();
  return nextSeq++;
}

// ---------- HMAC-SHA-256 ----------
void hmacHex(const char *key, const char *msg, char out[65]) {
  uint8_t mac[32];
  const mbedtls_md_info_t *info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  mbedtls_md_context_t ctx;
  mbedtls_md_init(&ctx);
  mbedtls_md_setup(&ctx, info, 1);
  mbedtls_md_hmac_starts(&ctx, (const unsigned char *)key, strlen(key));
  mbedtls_md_hmac_update(&ctx, (const unsigned char *)msg, strlen(msg));
  mbedtls_md_hmac_finish(&ctx, mac);
  mbedtls_md_free(&ctx);
  static const char *hex = "0123456789abcdef";
  for (int i = 0; i < 32; i++) {
    out[i * 2] = hex[mac[i] >> 4];
    out[i * 2 + 1] = hex[mac[i] & 15];
  }
  out[64] = 0;
}

// ---------- display ----------
void drawScreen() {
  if (!oledOk) return;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print(DEVICE_ID);
  display.setCursor(0, 12);
  display.setTextSize(2);
  if (strcmp(lastSensorStatus, "OK") == 0 && !isnan(lastTemp)) {
    display.printf("%.1f C", lastTemp);
  } else {
    display.print("SENSOR ERR");
  }
  display.setTextSize(1);
  display.setCursor(0, 34);
  display.print(WiFi.status() == WL_CONNECTED ? "WiFi: OK " : "WiFi: DOWN ");
  if (WiFi.status() == WL_CONNECTED) display.print(WiFi.localIP());
  display.setCursor(0, 44);
  if (WiFi.status() != WL_CONNECTED) display.print("Server: -");
  else if (qCount == 0 && backendOk) display.print("Server: OK");
  else if (lastHttp == 401) display.print("Server: AUTH FAIL");
  else display.printf("Server: retry (%d)", qCount);
  display.setCursor(0, 54);
  display.printf("seq %lu  sent %lu", (unsigned long)(nextSeq - 1), (unsigned long)sentCount);
  display.display();
}

// ---------- queue ----------
void enqueue(uint32_t seq, const char *body) {
  if (qCount == MAX_BUFFERED) {  // drop the OLDEST when full; the server will record the gap
    qHead = (qHead + 1) % MAX_BUFFERED;
    qCount--;
  }
  int idx = (qHead + qCount) % MAX_BUFFERED;
  queue[idx].seq = seq;
  strncpy(queue[idx].body, body, sizeof(queue[idx].body) - 1);
  queue[idx].body[sizeof(queue[idx].body) - 1] = 0;
  qCount++;
}

void dequeue() {
  qHead = (qHead + 1) % MAX_BUFFERED;
  qCount--;
}

// ---------- sampling ----------
void sampleAndEnqueue() {
  sensors.requestTemperatures();
  float t = sensors.getTempCByIndex(0);
  const char *status = "OK";
  // -127 = sensor not responding; 85.0 = power-on reset value (conversion not finished or wiring problem)
  if (t == DEVICE_DISCONNECTED_C) status = "DISCONNECTED";
  else if (t == 85.0f || t < -55.0f || t > 125.0f || isnan(t)) status = "INVALID";
  lastSensorStatus = status;
  lastTemp = (strcmp(status, "OK") == 0) ? t : NAN;

  char ts[40] = "";
  time_t now = time(nullptr);
  if (now > 1704067200) {  // after 2024-01-01 means NTP has set the clock
    struct tm tmv;
    gmtime_r(&now, &tmv);
    char iso[32];
    strftime(iso, sizeof(iso), "%Y-%m-%dT%H:%M:%S.000Z", &tmv);
    snprintf(ts, sizeof(ts), ",\"recordedAt\":\"%s\"", iso);
  }

  uint32_t seq = takeSequence();
  char body[300];
  if (strcmp(status, "OK") == 0) {
    snprintf(body, sizeof(body), "{\"deviceId\":\"%s\",\"sequence\":%lu,\"temperatureC\":%.3f,\"sensorStatus\":\"OK\",\"firmwareVersion\":\"%s\"%s}", DEVICE_ID, (unsigned long)seq, t, FIRMWARE_VERSION, ts);
  } else {
    snprintf(body, sizeof(body), "{\"deviceId\":\"%s\",\"sequence\":%lu,\"sensorStatus\":\"%s\",\"firmwareVersion\":\"%s\"%s}", DEVICE_ID, (unsigned long)seq, status, FIRMWARE_VERSION, ts);
  }
  enqueue(seq, body);
  Serial.printf("[sample] seq=%lu status=%s temp=%.2f queue=%d\n", (unsigned long)seq, status, isnan(lastTemp) ? 0.0f : lastTemp, qCount);
}

// ---------- sending ----------
void trySend() {
  if (qCount == 0 || WiFi.status() != WL_CONNECTED) return;
  if (millis() - lastSendAttempt < backoffMs) return;
  lastSendAttempt = millis();

  Pending &p = queue[qHead];
  char sig[65];
  hmacHex(DEVICE_SECRET, p.body, sig);

  HTTPClient http;
  http.setTimeout(6000);
  if (!http.begin(BACKEND_URL)) { lastHttp = -1; backendOk = false; backoffMs = 5000; return; }
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Id", DEVICE_ID);
  http.addHeader("X-Signature", sig);
  int code = http.POST((uint8_t *)p.body, strlen(p.body));  // the exact bytes that were signed
  String resp = code > 0 ? http.getString() : String();
  http.end();
  lastHttp = code;

  if (code == 200 || code == 201) {        // accepted (200 = duplicate of an earlier delivery)
    backendOk = true; backoffMs = 0; sentCount++;
    dequeue();
  } else if (code == 409) {                // sequence conflict / stale: re-sync with the server's counter
    backendOk = true; backoffMs = 0;
    int i = resp.indexOf("lastSequence\":");
    if (i >= 0) {
      uint32_t last = (uint32_t)resp.substring(i + 14).toInt();
      if (last >= nextSeq) { nextSeq = last + 1; if (nextSeq >= reservedUntil) reserveSequenceBlock(); }
    }
    Serial.printf("[send] 409 for seq %lu, dropping it and re-syncing\n", (unsigned long)p.seq);
    dequeue();
  } else if (code == 400) {                // malformed: retrying the same bytes cannot succeed
    Serial.printf("[send] 400 for seq %lu, dropping: %s\n", (unsigned long)p.seq, resp.c_str());
    dequeue();
  } else {                                 // 401 (wrong secret / revoked), 429, 5xx, network error: keep and back off
    backendOk = false;
    backoffMs = min<unsigned long>(backoffMs ? backoffMs * 2 : 2000, 30000);
    Serial.printf("[send] failed http=%d, will retry in %lu ms\n", code, backoffMs);
  }
}

void connectWifi() {
  if (WiFi.status() == WL_CONNECTED) return;
  static unsigned long lastTry = 0;
  if (millis() - lastTry < 8000 && lastTry != 0) return;
  lastTry = millis();
  Serial.println("[wifi] connecting...");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.printf("\nColdChain Sentinel firmware %s, device %s\n", FIRMWARE_VERSION, DEVICE_ID);
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  oledOk = display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS);
  if (!oledOk) Serial.println("[oled] not found: check SDA/SCL wiring and address (0x3C or 0x3D)");
  sensors.begin();
  sensors.setResolution(12);
  if (sensors.getDeviceCount() == 0) Serial.println("[sensor] no DS18B20 found: check DATA wiring and the 4.7k pull-up resistor");
  initSequence();
  Serial.printf("[seq] starting at %lu (reserved up to %lu)\n", (unsigned long)nextSeq, (unsigned long)reservedUntil);
  connectWifi();
  configTime(0, 0, "pool.ntp.org", "time.google.com");
  drawScreen();
}

void loop() {
  connectWifi();
  if (millis() - lastSample >= SAMPLE_INTERVAL_MS || lastSample == 0) {
    lastSample = millis();
    sampleAndEnqueue();
    drawScreen();
  }
  trySend();
  static unsigned long lastDraw = 0;
  if (millis() - lastDraw > 1000) { lastDraw = millis(); drawScreen(); }
  delay(20);
}
