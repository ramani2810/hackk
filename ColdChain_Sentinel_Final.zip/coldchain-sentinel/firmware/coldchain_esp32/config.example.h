// ColdChain Sentinel ESP32 configuration.
// 1. Copy this file to "config.h" (same folder).  2. Fill in your values.  3. NEVER share or commit config.h.
#pragma once

// ---- Wi-Fi (2.4 GHz only; the ESP32 cannot join 5 GHz networks) ----
#define WIFI_SSID        "YOUR_WIFI_NAME"
#define WIFI_PASSWORD    "YOUR_WIFI_PASSWORD"

// ---- Backend ----
// Use your laptop's LAN IP address (run "ipconfig" in PowerShell, look for "IPv4 Address"),
// NOT "localhost": on the ESP32, localhost means the ESP32 itself.
#define BACKEND_URL      "http://192.168.1.50:4000/api/v1/readings"

// ---- Device identity (must match a device registered in the dashboard / seed output) ----
#define DEVICE_ID        "COLD-BOX-01"
// The 64-character secret printed ONCE by "npm run db:seed" (or shown when you register/rotate a device).
#define DEVICE_SECRET    "PASTE_THE_64_CHARACTER_SECRET_HERE"

// ---- Behaviour ----
#define SAMPLE_INTERVAL_MS   5000   // time between readings (default 5 s)
#define FIRMWARE_VERSION     "1.0.0"
#define MAX_BUFFERED         40     // readings kept in RAM while the backend is unreachable
#define SEQ_RESERVE_BLOCK    100    // sequence numbers reserved per flash write (see README)

// ---- Pins (see docs/WIRING.md) ----
#define PIN_ONEWIRE      4    // DS18B20 DATA
#define PIN_I2C_SDA      21   // OLED SDA
#define PIN_I2C_SCL      22   // OLED SCL
#define OLED_ADDRESS     0x3C
