-- ColdChain Sentinel schema v1 (SQLite)
-- Applied by src/db/index.ts. The same schema is used for the live database and the
-- isolated tamper-demonstration sandbox database.

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('ADMIN','VIEWER')),
  password_hash TEXT NOT NULL,
  disabled      INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL,
  last_login_at TEXT
);

CREATE TABLE sessions (
  id         TEXT PRIMARY KEY,           -- SHA-256 of the opaque session token (token itself is never stored)
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip         TEXT,
  user_agent TEXT
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

CREATE TABLE devices (
  id                  TEXT PRIMARY KEY,   -- device identifier, e.g. COLD-BOX-01
  name                TEXT NOT NULL,
  type                TEXT NOT NULL CHECK (type IN ('ESP32','SIMULATED','SANDBOX')),
  description         TEXT,
  created_at          TEXT NOT NULL,
  created_by          TEXT,
  last_seen_at        TEXT,               -- server receipt time of the last accepted reading
  last_temperature_c  REAL,
  last_sensor_status  TEXT,
  last_reading_id     TEXT,
  firmware_version    TEXT,
  last_sequence       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE device_credentials (
  id                 TEXT PRIMARY KEY,
  device_id          TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  secret_enc         TEXT NOT NULL,       -- AES-256-GCM ciphertext of the HMAC secret (needed server-side to verify HMACs)
  secret_fingerprint TEXT NOT NULL,       -- first 12 hex chars of SHA-256(secret); safe to display
  status             TEXT NOT NULL CHECK (status IN ('ACTIVE','REVOKED')),
  created_at         TEXT NOT NULL,
  revoked_at         TEXT,
  revoked_by         TEXT,
  last_used_at       TEXT
);
CREATE UNIQUE INDEX uq_device_active_credential ON device_credentials(device_id) WHERE status = 'ACTIVE';

CREATE TABLE shipments (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  product     TEXT,
  origin      TEXT,
  destination TEXT,
  status      TEXT NOT NULL CHECK (status IN ('PLANNED','IN_TRANSIT','DELIVERED','CANCELLED')),
  device_id   TEXT REFERENCES devices(id),
  min_temp_c  REAL NOT NULL,
  max_temp_c  REAL NOT NULL,
  created_at  TEXT NOT NULL,
  created_by  TEXT,
  started_at  TEXT,
  ended_at    TEXT,
  CHECK (min_temp_c < max_temp_c)
);
CREATE INDEX idx_shipments_device ON shipments(device_id);

-- The ledger. One hash chain per device. ledger_index is insertion order.
CREATE TABLE readings (
  ledger_index     INTEGER PRIMARY KEY AUTOINCREMENT,
  id               TEXT NOT NULL UNIQUE,
  device_id        TEXT NOT NULL,
  sequence         INTEGER NOT NULL,
  temperature_c    REAL,
  humidity_pct     REAL,
  sensor_status    TEXT NOT NULL CHECK (sensor_status IN ('OK','DISCONNECTED','INVALID')),
  device_timestamp TEXT,
  received_at      TEXT NOT NULL,
  source           TEXT NOT NULL CHECK (source IN ('HARDWARE','SIMULATOR','SANDBOX')),
  firmware_version TEXT,
  shipment_id      TEXT,
  gap_before       INTEGER NOT NULL DEFAULT 0,
  previous_hash    TEXT NOT NULL,
  hash             TEXT NOT NULL,
  UNIQUE (device_id, sequence)
);
CREATE INDEX idx_readings_device_seq ON readings(device_id, sequence);
CREATE INDEX idx_readings_received ON readings(received_at);
CREATE INDEX idx_readings_shipment ON readings(shipment_id);

-- Result of the most recent verification for each record (written by the verifier).
CREATE TABLE record_integrity (
  record_id   TEXT PRIMARY KEY,
  status      TEXT NOT NULL,              -- VERIFIED or the highest-priority failure kind
  kinds_json  TEXT NOT NULL,
  run_id      TEXT NOT NULL,
  verified_at TEXT NOT NULL
);

CREATE TABLE verification_runs (
  id                TEXT PRIMARY KEY,
  dataset           TEXT NOT NULL CHECK (dataset IN ('LIVE','SANDBOX')),
  scope             TEXT NOT NULL CHECK (scope IN ('LEDGER','DEVICE','RANGE')),
  device_id         TEXT,
  range_from        TEXT,
  range_to          TEXT,
  status            TEXT NOT NULL CHECK (status IN ('VERIFIED','VERIFICATION_FAILED')),
  records_checked   INTEGER NOT NULL,
  devices_checked   INTEGER NOT NULL,
  checkpoints_checked INTEGER NOT NULL DEFAULT 0,
  failures_json     TEXT NOT NULL,
  notes_json        TEXT NOT NULL,
  started_at        TEXT NOT NULL,
  finished_at       TEXT NOT NULL,
  triggered_by      TEXT
);
CREATE INDEX idx_runs_finished ON verification_runs(dataset, finished_at);

CREATE TABLE alerts (
  id               TEXT PRIMARY KEY,
  category         TEXT NOT NULL CHECK (category IN ('TEMPERATURE','SECURITY')),
  kind             TEXT NOT NULL,
  severity         TEXT NOT NULL CHECK (severity IN ('INFO','LOW','MEDIUM','HIGH','CRITICAL')),
  status           TEXT NOT NULL CHECK (status IN ('OPEN','RESOLVED')),
  scope            TEXT NOT NULL DEFAULT 'LIVE' CHECK (scope IN ('LIVE','SANDBOX')),
  device_id        TEXT,
  shipment_id      TEXT,
  record_id        TEXT,
  title            TEXT NOT NULL,
  description      TEXT NOT NULL,
  details_json     TEXT NOT NULL DEFAULT '{}',
  dedupe_key       TEXT,
  created_at       TEXT NOT NULL,
  updated_at       TEXT NOT NULL,
  acknowledged_at  TEXT,
  acknowledged_by  TEXT,
  resolved_at      TEXT,
  resolved_by      TEXT,
  resolution_note  TEXT
);
CREATE INDEX idx_alerts_created ON alerts(created_at);
CREATE INDEX idx_alerts_device ON alerts(device_id);
CREATE UNIQUE INDEX uq_alert_open_dedupe ON alerts(dedupe_key) WHERE status = 'OPEN' AND dedupe_key IS NOT NULL;

CREATE TABLE audit_events (
  id          TEXT PRIMARY KEY,
  ts          TEXT NOT NULL,
  actor_id    TEXT,
  actor_label TEXT NOT NULL,
  action      TEXT NOT NULL,
  target_type TEXT,
  target_id   TEXT,
  scope       TEXT NOT NULL DEFAULT 'LIVE',
  details_json TEXT NOT NULL DEFAULT '{}',
  ip          TEXT
);
CREATE INDEX idx_audit_ts ON audit_events(ts);

-- Database copy of signed checkpoints. The AUTHORITATIVE copy lives in a separate append-only file
-- (see backend/src/services/checkpoints.ts); verification compares the two.
CREATE TABLE checkpoints (
  id             TEXT PRIMARY KEY,
  device_id      TEXT NOT NULL,
  record_count   INTEGER NOT NULL,
  last_sequence  INTEGER NOT NULL,
  head_hash      TEXT NOT NULL,
  prev_digest    TEXT NOT NULL,
  created_at     TEXT NOT NULL,
  key_id         TEXT NOT NULL,
  signature      TEXT NOT NULL,
  UNIQUE (device_id, last_sequence)
);

CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Used only by the sandbox database: snapshot of the untouched demo records, for side-by-side comparison.
CREATE TABLE sandbox_originals (
  record_id TEXT PRIMARY KEY,
  snapshot_json TEXT NOT NULL
);
