import { describe, expect, it, beforeEach, afterEach } from "vitest";
import { canonicalize, computeRecordHash, genesisHash, sha256Hex, canonicalRecord, hmacSha256Hex, encryptSecret, decryptSecret, hashPassword, verifyPassword } from "../src/lib/crypto";
import { appendRecord, listDeviceRecords } from "../src/services/ledger";
import { verifyLedger } from "../src/services/verifier";
import { run, all } from "../src/db/index";
import { makeEnv, type TestEnv } from "./helpers";

const base = { id: "r1", deviceId: "D", sequence: 1, temperatureC: 4.2, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: "2026-01-01T00:00:00.000Z", source: "SIMULATOR", firmwareVersion: "1", shipmentId: null, gapBefore: 0, previousHash: "0".repeat(64) };

describe("SHA-256 and canonical serialization", () => {
  it("matches known SHA-256 test vectors", () => {
    expect(sha256Hex("")).toBe("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    expect(sha256Hex("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
  it("matches RFC 4231 HMAC-SHA-256 test case 2", () => {
    expect(hmacSha256Hex("Jefe", "what do ya want for nothing?")).toBe("5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");
  });
  it("canonicalize sorts keys and is whitespace-free", () => {
    expect(canonicalize({ b: 1, a: [true, null, "x"] })).toBe('{"a":[true,null,"x"],"b":1}');
    expect(canonicalize({ a: 1, b: 2 })).toBe(canonicalize({ b: 2, a: 1 }));
  });
  it("canonicalize rejects floats and undefined", () => {
    expect(() => canonicalize({ a: 1.5 })).toThrow();
    expect(() => canonicalize({ a: undefined })).toThrow();
  });
  it("record hash is deterministic and sensitive to every field", () => {
    const h = computeRecordHash(base);
    expect(h).toBe(computeRecordHash({ ...base }));
    expect(h).toMatch(/^[0-9a-f]{64}$/);
    for (const [k, v] of Object.entries({ temperatureC: 4.3, sequence: 2, deviceId: "E", receivedAt: "2026-01-01T00:00:01.000Z", previousHash: "1".repeat(64), source: "HARDWARE", gapBefore: 1, sensorStatus: "INVALID", id: "r2" })) {
      expect(computeRecordHash({ ...base, [k]: v } as typeof base), k).not.toBe(h);
    }
  });
  it("fixed-precision encoding makes 4.2 and 4.2000 identical", () => {
    expect(canonicalRecord({ ...base, temperatureC: 4.2 })).toContain('"temperatureC":"4.200"');
  });
  it("genesis value is documented, per-device and deterministic", () => {
    expect(genesisHash("A")).toBe(sha256Hex("coldchain-sentinel/genesis/v1:A"));
    expect(genesisHash("A")).not.toBe(genesisHash("B"));
  });
  it("AES-GCM secrets round-trip and reject tampering; scrypt passwords verify", () => {
    const key = Buffer.alloc(32, 3);
    const blob = encryptSecret(key, "s3cret");
    expect(blob).not.toContain("s3cret");
    expect(decryptSecret(key, blob)).toBe("s3cret");
    const parts = blob.split(":"); parts[3] = Buffer.from("xxxxxxxx").toString("base64");
    expect(() => decryptSecret(key, parts.join(":"))).toThrow();
    const h = hashPassword("correct horse"); expect(verifyPassword("correct horse", h)).toBe(true); expect(verifyPassword("wrong", h)).toBe(false);
  });
});

describe("hash chain and verifier", () => {
  let env: TestEnv;
  const dev = "SIM-COLD-01";
  beforeEach(async () => {
    env = await makeEnv();
    for (let i = 1; i <= 12; i++) {
      const r = appendRecord(env.ctx.live.db, { deviceId: dev, sequence: i, temperatureC: 4 + i / 10, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date(1.8e12 + i * 1000).toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
      expect(r.kind).toBe("created");
    }
  });
  afterEach(() => env.cleanup());
  const verify = () => verifyLedger(env.ctx.live.db, env.ctx.live.checkpoints, "LIVE", { scope: "LEDGER" });
  const db = () => env.ctx.live.db;

  it("links every record to its predecessor and the first to genesis", () => {
    const rows = listDeviceRecords(db(), dev);
    expect(rows[0]!.previousHash).toBe(genesisHash(dev));
    for (let i = 1; i < rows.length; i++) expect(rows[i]!.previousHash).toBe(rows[i - 1]!.hash);
  });
  it("verifies an unchanged chain", () => {
    const v = verify();
    expect(v.status).toBe("VERIFIED"); expect(v.recordsChecked).toBe(12); expect(v.failures).toEqual([]);
  });
  it("detects a modified temperature (INVALID_HASH at the record, BROKEN_LINK after it)", () => {
    run(db(), "UPDATE readings SET temperature_c = 9.9 WHERE device_id = ? AND sequence = 5", dev);
    const v = verify();
    expect(v.status).toBe("VERIFICATION_FAILED");
    expect(v.failures.map((f) => `${f.kind}@${f.sequence}`)).toEqual(expect.arrayContaining(["INVALID_HASH@5", "BROKEN_LINK@6"]));
    expect(v.failures.filter((f) => f.kind === "INVALID_HASH")).toHaveLength(1);
  });
  it("detects a modified previous-hash", () => {
    run(db(), "UPDATE readings SET previous_hash = ? WHERE device_id = ? AND sequence = 7", "a".repeat(64), dev);
    const kinds = verify().failures.map((f) => `${f.kind}@${f.sequence}`);
    expect(kinds).toContain("BROKEN_LINK@7"); expect(kinds).toContain("INVALID_HASH@7");
  });
  it("detects a deleted record in the middle as MISSING_RECORD", () => {
    run(db(), "DELETE FROM readings WHERE device_id = ? AND sequence = 6", dev);
    const f = verify().failures;
    expect(f.some((x) => x.kind === "MISSING_RECORD" && x.sequence === 7)).toBe(true);
    expect(f.some((x) => x.kind === "BROKEN_LINK" && x.sequence === 7)).toBe(true);
  });
  it("detects deletion of the newest records via the device registry", () => {
    run(db(), "DELETE FROM readings WHERE device_id = ? AND sequence > 10", dev);
    expect(verify().failures.some((x) => x.kind === "MISSING_RECORD")).toBe(true);
  });
  it("detects removal of the first record (genesis link breaks)", () => {
    run(db(), "DELETE FROM readings WHERE device_id = ? AND sequence = 1", dev);
    expect(verify().failures.some((x) => x.kind === "BROKEN_LINK" && x.sequence === 2)).toBe(true);
  });
  it("detects reordered records", () => {
    const rows = listDeviceRecords(db(), dev);
    const a = rows[3]!, b = rows[4]!;
    run(db(), "UPDATE readings SET ledger_index = -1 WHERE id = ?", a.id);
    run(db(), "UPDATE readings SET ledger_index = ? WHERE id = ?", a.ledgerIndex, b.id);
    run(db(), "UPDATE readings SET ledger_index = ? WHERE id = ?", b.ledgerIndex, a.id);
    const kinds = verify().failures.map((f) => f.kind);
    expect(kinds).toContain("REORDERED"); expect(kinds).toContain("BROKEN_LINK");
  });
  it("detects a sequence gap whose hash link was re-forged (SEQUENCE_GAP, unacknowledged)", () => {
    // forge: renumber record 9 -> 10 and rehash only that record and its successors correctly linked
    run(db(), "UPDATE readings SET sequence = 20 WHERE device_id = ? AND sequence = 9", dev);
    const kinds = verify().failures.map((f) => f.kind);
    expect(kinds.some((k) => k === "SEQUENCE_GAP" || k === "MISSING_RECORD" || k === "INVALID_HASH")).toBe(true);
  });
  it("does NOT flag an acknowledged gap recorded at ingestion", () => {
    const r = appendRecord(db(), { deviceId: dev, sequence: 16, temperatureC: 5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date().toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    expect(r.kind === "created" && r.record.gapBefore).toBe(3);
    const v = verify();
    expect(v.status).toBe("VERIFIED"); expect(v.notes.join(" ")).toMatch(/skipped/);
  });
  it("is idempotent for identical retries and conflicts on different content", () => {
    const again = appendRecord(db(), { deviceId: dev, sequence: 12, temperatureC: 4 + 12 / 10, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date().toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    expect(again.kind).toBe("duplicate");
    const diff = appendRecord(db(), { deviceId: dev, sequence: 12, temperatureC: 20, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date().toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    expect(diff.kind).toBe("conflict");
    expect(all(db(), "SELECT 1 FROM readings WHERE device_id = ?", dev)).toHaveLength(12);
  });
  it("rejects stale sequences (a sequence at or below the highest ever accepted that no longer exists)", () => {
    run(db(), "DELETE FROM readings WHERE device_id = ? AND sequence = 3", dev); // attacker removes #3
    const s = appendRecord(db(), { deviceId: dev, sequence: 3, temperatureC: 5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date().toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    expect(s.kind).toBe("stale");
  });
  it("range verification anchors on the preceding record", () => {
    const rows = listDeviceRecords(db(), dev);
    const v = verifyLedger(db(), env.ctx.live.checkpoints, "LIVE", { scope: "RANGE", deviceId: dev, from: rows[4]!.receivedAt, to: rows[8]!.receivedAt });
    expect(v.status).toBe("VERIFIED"); expect(v.recordsChecked).toBe(5);
    run(db(), "UPDATE readings SET temperature_c = 1 WHERE id = ?", rows[6]!.id);
    const v2 = verifyLedger(db(), env.ctx.live.checkpoints, "LIVE", { scope: "RANGE", deviceId: dev, from: rows[4]!.receivedAt, to: rows[8]!.receivedAt });
    expect(v2.status).toBe("VERIFICATION_FAILED");
  });
});
