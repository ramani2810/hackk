import { afterEach, beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { all, get } from "../src/db/index";
import { makeEnv, seedUsers, loginCookie as login, esp32, signedPostDev as sPost, readingOf as rd, H, type TestEnv } from "./helpers";
import { createShipment } from "../src/services/shipments";
import { SYSTEM_ACTOR } from "../src/services/audit";
import { resetSandbox } from "../src/services/sandbox";
import { appendRecord } from "../src/services/ledger";

let env: TestEnv; let admin = ""; let viewer = "";
beforeEach(async () => {
  env = await makeEnv(); seedUsers(env.ctx);
  admin = (await login(env.app, "admin@test.local", "admin-password-123")).cookie;
  viewer = (await login(env.app, "viewer@test.local", "viewer-password-123")).cookie;
});
afterEach(() => env.cleanup());
const get_ = (p: string, c: string) => request(env.app).get("/api/v1" + p).set("Cookie", c);
const post_ = (p: string, c: string, b: object = {}) => request(env.app).post("/api/v1" + p).set("Cookie", c).set(H).send(b);

describe("authentication and authorization", () => {
  it("health is public; data endpoints need a session", async () => {
    expect((await request(env.app).get("/api/v1/health")).body.status).toBe("ok");
    for (const p of ["/overview", "/readings", "/ledger", "/devices", "/alerts", "/shipments", "/reports/temperature"]) {
      expect((await request(env.app).get("/api/v1" + p)).status, p).toBe(401);
    }
  });
  it("rejects bad logins with a generic message and never leaks hashes", async () => {
    const r = await request(env.app).post("/api/v1/auth/login").set(H).send({ email: "admin@test.local", password: "nope" });
    expect(r.status).toBe(401); expect(r.body.error.code).toBe("INVALID_CREDENTIALS");
    const ok = await request(env.app).post("/api/v1/auth/login").set(H).send({ email: "admin@test.local", password: "admin-password-123" });
    expect(JSON.stringify(ok.body)).not.toMatch(/scrypt|password/i);
    expect(ok.headers["set-cookie"]![0]).toMatch(/HttpOnly/i);
  });
  it("rate-limits repeated failed logins", async () => {
    let last = 0;
    for (let i = 0; i < 8; i++) last = (await request(env.app).post("/api/v1/auth/login").set(H).send({ email: "x@test.local", password: "bad" })).status;
    expect(last).toBe(429);
  });
  it("requires the anti-CSRF header on state-changing requests", async () => {
    const r = await request(env.app).post("/api/v1/auth/logout").set("Cookie", admin);
    expect(r.status).toBe(403); expect(r.body.error.code).toBe("CSRF_REJECTED");
    const evil = await request(env.app).post("/api/v1/ledger/verify").set("Cookie", admin).set(H).set("Origin", "https://evil.example").send({ scope: "LEDGER" });
    expect(evil.status).toBe(403);
  });
  it("viewers can read but cannot administer", async () => {
    expect((await get_("/overview", viewer)).status).toBe(200);
    expect((await post_("/devices", viewer, { id: "NEW-ESP", name: "n", type: "ESP32" })).status).toBe(403);
    expect((await post_("/ledger/verify", viewer, { scope: "LEDGER" })).status).toBe(403);
    expect((await get_("/audit", viewer)).status).toBe(403);
    expect((await get_("/users", viewer)).status).toBe(403);
    expect((await post_("/dev/simulator/start", viewer)).status).toBe(403);
    expect((await post_("/dev/sandbox/reset", viewer)).status).toBe(403);
    expect((await request(env.app).patch("/api/v1/settings").set("Cookie", viewer).set(H).send({ tempMaxC: 9 })).status).toBe(403);
  });
  it("logout destroys the session", async () => {
    await post_("/auth/logout", admin);
    expect((await get_("/overview", admin)).status).toBe(401);
  });
  it("dev endpoints are disabled (404) when switched off, even for admins", async () => {
    const e2 = await makeEnv({ enableDevEndpoints: false }); seedUsers(e2.ctx);
    const c = (await login(e2.app, "admin@test.local", "admin-password-123")).cookie;
    expect((await request(e2.app).get("/api/v1/dev/sandbox").set("Cookie", c)).status).toBe(404);
    expect((await request(e2.app).post("/api/v1/dev/simulator/start").set("Cookie", c).set(H).send({})).status).toBe(404);
    e2.cleanup();
  });
  it("loadConfig forces dev endpoints off in production", async () => {
    const { loadConfig } = await import("../src/config");
    const c = loadConfig({ nodeEnv: "production", enableDevEndpoints: true, deviceSecretKey: Buffer.alloc(32, 1), checkpointKey: Buffer.alloc(32, 2) });
    expect(c.enableDevEndpoints).toBe(false);
  });
});

describe("device ingestion API", () => {
  it("accepts a correctly signed reading, hash-chains it and returns the next sequence", async () => {
    const d = esp32(env.ctx);
    const r1 = await sPost(env.app, d, rd(d.id, 1, 4.2));
    expect(r1.status).toBe(201); expect(r1.body.record.hash).toMatch(/^[0-9a-f]{64}$/); expect(r1.body.nextSequence).toBe(2);
    const r2 = await sPost(env.app, d, rd(d.id, 2, 4.4));
    expect(r2.body.record.previousHash).toBe(r1.body.record.hash);
    const row = get<{ source: string }>(env.ctx.live.db, "SELECT source FROM readings WHERE sequence = 1 AND device_id = ?", d.id);
    expect(row!.source).toBe("HARDWARE");
  });
  it("is idempotent: the same reading twice yields one record", async () => {
    const d = esp32(env.ctx); const body = rd(d.id, 1, 4.2);
    expect((await sPost(env.app, d, body)).status).toBe(201);
    const again = await sPost(env.app, d, body);
    expect(again.status).toBe(200); expect(again.body.status).toBe("duplicate");
    expect(all(env.ctx.live.db, "SELECT 1 FROM readings WHERE device_id = ?", d.id)).toHaveLength(1);
  });
  it("rejects conflicting reuse of a sequence number and raises a security alert", async () => {
    const d = esp32(env.ctx);
    await sPost(env.app, d, rd(d.id, 1, 4.2));
    const r = await sPost(env.app, d, rd(d.id, 1, 7.7));
    expect(r.status).toBe(409); expect(r.body.error.code).toBe("SEQUENCE_CONFLICT");
    expect(get<{ c: number }>(env.ctx.live.db, "SELECT COUNT(*) AS c FROM alerts WHERE kind = 'SEQUENCE_CONFLICT'")!.c).toBe(1);
  });
  it("rejects a wrong secret, an unknown device, a missing signature and a tampered body", async () => {
    const d = esp32(env.ctx);
    expect((await sPost(env.app, d, rd(d.id, 1), { secret: "f".repeat(64) })).status).toBe(401);
    expect((await sPost(env.app, { id: "GHOST-01", secret: "a".repeat(64) }, rd("GHOST-01", 1))).status).toBe(401);
    expect((await request(env.app).post("/api/v1/readings").send(rd(d.id, 1))).status).toBe(401);
    const raw = JSON.stringify(rd(d.id, 1, 4)); const { hmacSha256Hex } = await import("../src/lib/crypto");
    const sig = hmacSha256Hex(d.secret, raw);
    const forged = await request(env.app).post("/api/v1/readings").set("Content-Type", "application/json").set("X-Device-Id", d.id).set("X-Signature", sig).send(raw.replace('"temperatureC":4', '"temperatureC":5'));
    expect(forged.status).toBe(401);
    expect(all(env.ctx.live.db, "SELECT 1 FROM readings")).toHaveLength(0);
    const err = (await sPost(env.app, d, rd(d.id, 1), { secret: "f".repeat(64) })).body.error;
    expect(err.message).toBe("Device authentication failed"); // no hint about which part failed
  });
  it("raises INVALID_DEVICE_AUTH and REPEATED_FAILED_REQUESTS alerts, without storing secrets", async () => {
    const d = esp32(env.ctx);
    for (let i = 0; i < 6; i++) await sPost(env.app, d, rd(d.id, 1), { secret: "bad".repeat(21) + "b" });
    const kinds = all<{ kind: string }>(env.ctx.live.db, "SELECT kind FROM alerts").map((a) => a.kind);
    expect(kinds).toContain("INVALID_DEVICE_AUTH"); expect(kinds).toContain("REPEATED_FAILED_REQUESTS");
    expect(JSON.stringify(all(env.ctx.live.db, "SELECT * FROM alerts"))).not.toContain(d.secret);
  });
  it("cannot be used with a revoked credential, and a rotated secret replaces the old one", async () => {
    const d = esp32(env.ctx);
    expect((await sPost(env.app, d, rd(d.id, 1))).status).toBe(201);
    const rot = await post_(`/devices/${d.id}/rotate`, admin);
    expect(rot.status).toBe(200);
    expect((await sPost(env.app, d, rd(d.id, 2))).status).toBe(401); // old secret
    expect((await sPost(env.app, { id: d.id, secret: rot.body.secret }, rd(d.id, 2))).status).toBe(201);
    expect((await post_(`/devices/${d.id}/revoke`, admin)).status).toBe(200);
    expect((await sPost(env.app, { id: d.id, secret: rot.body.secret }, rd(d.id, 3))).status).toBe(401);
  });
  it("validates input ranges, unknown fields, body size and deviceId mismatch", async () => {
    const d = esp32(env.ctx);
    expect((await sPost(env.app, d, rd(d.id, 1, 500))).status).toBe(400);
    expect((await sPost(env.app, d, rd(d.id, 0))).status).toBe(400);
    expect((await sPost(env.app, d, rd(d.id, 1.5))).status).toBe(400);
    expect((await sPost(env.app, d, { ...rd(d.id, 1), evil: "x" })).status).toBe(400);
    expect((await sPost(env.app, d, { deviceId: d.id, sequence: 1, sensorStatus: "OK" })).status).toBe(400); // OK needs a temperature
    expect((await sPost(env.app, d, { ...rd(d.id, 1), recordedAt: "yesterday" })).status).toBe(400);
    const big = await sPost(env.app, d, { ...rd(d.id, 1), firmwareVersion: "x".repeat(20000) });
    expect(big.status).toBe(413);
    const other = esp32(env.ctx, "TEST-ESP-02");
    expect((await sPost(env.app, d, rd(other.id, 1))).status).toBe(400);
  });
  it("records sensor faults without a temperature and flags unsynchronised device clocks", async () => {
    const d = esp32(env.ctx);
    const r = await sPost(env.app, d, { deviceId: d.id, sequence: 1, sensorStatus: "DISCONNECTED", recordedAt: "1970-01-01T00:00:05.000Z" });
    expect(r.status).toBe(201); expect(r.body.clock).toBe("UNSYNCHRONIZED");
    const row = get<{ temperature_c: number | null; device_timestamp: string | null }>(env.ctx.live.db, "SELECT * FROM readings WHERE device_id = ?", d.id)!;
    expect(row.temperature_c).toBeNull(); expect(row.device_timestamp).toBeNull();
    expect(get<{ kind: string }>(env.ctx.live.db, "SELECT kind FROM alerts")!.kind).toBe("SENSOR_DISCONNECTED");
  });
  it("concurrent ingestion never creates duplicate sequences or broken links", async () => {
    const d = esp32(env.ctx);
    const results = await Promise.all(Array.from({ length: 40 }, (_, i) => sPost(env.app, d, rd(d.id, i + 1, 4 + (i % 5) / 10))));
    expect(results.filter((r) => r.status === 201).length + results.filter((r) => r.status === 409).length).toBe(40);
    const rows = all<{ sequence: number }>(env.ctx.live.db, "SELECT sequence FROM readings WHERE device_id = ? ORDER BY sequence", d.id);
    expect(new Set(rows.map((r) => r.sequence)).size).toBe(rows.length);
    // same device, same sequence submitted 20x at once -> exactly one record
    const dup = await Promise.all(Array.from({ length: 20 }, () => sPost(env.app, d, rd(d.id, 1000, 5.5, { recordedAt: "2026-05-05T00:00:00.000Z" }))));
    expect(dup.filter((r) => r.status === 201)).toHaveLength(1);
    const v = await post_("/ledger/verify", admin, { scope: "DEVICE", deviceId: d.id });
    expect(v.body.status).toBe("VERIFIED");
  });
});

describe("temperature alerts vs integrity alerts", () => {
  it("an excursion creates a TEMPERATURE alert, not a SECURITY alert, and the ledger still verifies", async () => {
    const d = esp32(env.ctx);
    for (const [i, t] of [5, 5.1, 9.4, 9.8, 6, 5.5, 5.2].entries()) expect((await sPost(env.app, d, rd(d.id, i + 1, t))).status).toBe(201);
    const alerts = (await get_("/alerts", admin)).body.items as { category: string; kind: string; status: string; details: { peakC: number } }[];
    expect(alerts.filter((a) => a.category === "SECURITY")).toHaveLength(0);
    const exc = alerts.find((a) => a.kind === "TEMP_EXCURSION")!;
    expect(exc.category).toBe("TEMPERATURE"); expect(exc.details.peakC).toBe(9.8); expect(exc.status).toBe("RESOLVED"); // recovered after 2 in-range readings
    expect(alerts.some((a) => a.kind === "TEMP_RECOVERED")).toBe(true);
    const v = await post_("/ledger/verify", admin, { scope: "LEDGER" });
    expect(v.body.status).toBe("VERIFIED");
    expect(((await get_("/alerts?category=SECURITY", admin)).body.items as unknown[])).toHaveLength(0);
  });
  it("tampering creates SECURITY alerts and preserves the corrupted record", async () => {
    const d = esp32(env.ctx);
    for (let i = 1; i <= 6; i++) await sPost(env.app, d, rd(d.id, i, 5));
    env.ctx.live.db.prepare("UPDATE readings SET temperature_c = 7 WHERE device_id = ? AND sequence = 3").run(d.id);
    const v = await post_("/ledger/verify", admin, { scope: "LEDGER" });
    expect(v.body.status).toBe("VERIFICATION_FAILED");
    const sec = (await get_("/alerts?category=SECURITY", admin)).body.items as { kind: string }[];
    expect(sec.map((a) => a.kind)).toEqual(expect.arrayContaining(["HASH_MISMATCH", "BROKEN_LINK"]));
    expect(get<{ temperature_c: number }>(env.ctx.live.db, "SELECT temperature_c FROM readings WHERE device_id = ? AND sequence = 3", d.id)!.temperature_c).toBe(7); // not repaired
    const led = (await get_(`/ledger?deviceId=${d.id}&order=asc`, admin)).body.items as { sequence: number; integrity: { status: string } }[];
    expect(led.find((r) => r.sequence === 3)!.integrity.status).toBe("INVALID_HASH");
    expect(led.find((r) => r.sequence === 4)!.integrity.status).toBe("BROKEN_LINK");
    expect(led.find((r) => r.sequence === 1)!.integrity.status).toBe("VERIFIED");
  });
  it("shows UNVERIFIED (never VERIFIED) for records that have not been verified", async () => {
    const d = esp32(env.ctx); await sPost(env.app, d, rd(d.id, 1, 5));
    const row = (await get_("/ledger", admin)).body.items[0];
    expect(row.integrity.status).toBe("UNVERIFIED");
    expect((await get_("/ledger/summary", admin)).body.chainStatus.status).toBe("NEVER_VERIFIED");
  });
  it("stale-data detection raises a TEMPERATURE-category health alert", async () => {
    const d = esp32(env.ctx); await sPost(env.app, d, rd(d.id, 1, 5));
    env.ctx.live.db.prepare("UPDATE devices SET last_seen_at = ? WHERE id = ?").run(new Date(Date.now() - 600_000).toISOString(), d.id);
    const { checkStale } = await import("../src/services/monitor"); checkStale(env.ctx);
    const a = get<{ kind: string; category: string }>(env.ctx.live.db, "SELECT kind, category FROM alerts WHERE kind = 'STALE_READINGS'")!;
    expect(a.category).toBe("TEMPERATURE");
    const dev = (await get_("/devices", admin)).body.items.find((x: { id: string }) => x.id === d.id);
    expect(dev.connectivity).toBe("OFFLINE");
  });
});

describe("simulator", () => {
  it("ingests through the same pipeline, labels records SIMULATOR and builds valid chains", async () => {
    const g = await post_("/dev/simulator/generate", admin, { count: 25 });
    expect(g.status).toBe(200); expect(g.body.generated).toBe(75);
    const sources = all<{ source: string }>(env.ctx.live.db, "SELECT DISTINCT source FROM readings").map((r) => r.source);
    expect(sources).toEqual(["SIMULATOR"]);
    const v = await post_("/ledger/verify", admin, { scope: "LEDGER" });
    expect(v.body.status).toBe("VERIFIED"); expect(v.body.recordsChecked).toBe(75);
    expect(get<{ c: number }>(env.ctx.live.db, "SELECT COUNT(*) AS c FROM checkpoints")!.c).toBeGreaterThan(0);
    const mode = (await get_("/status", admin)).body;
    expect(mode.mode).toBe("SIMULATION");
  });
  it("can be started and stopped, and triggers excursions on demand", async () => {
    const s = await post_("/dev/simulator/start", admin, { intervalSec: 1, randomEvents: false });
    expect(s.body.running).toBe(true);
    await post_("/dev/simulator/stop", admin);
    expect((await get_("/dev/simulator", admin)).body.running).toBe(false);
    await post_("/dev/simulator/excursion", admin, { deviceId: "SIM-COLD-01", peakC: 11, readings: 4 });
    await post_("/dev/simulator/generate", admin, { count: 6, deviceIds: ["SIM-COLD-01"] });
    const exc = (await get_("/alerts?kind=TEMP_EXCURSION", admin)).body.items;
    expect(exc.length).toBeGreaterThan(0); expect(exc[0].category).toBe("TEMPERATURE");
    expect((await post_("/dev/simulator/excursion", admin, { deviceId: "NOPE-1234", peakC: 11 })).status).toBe(400);
  });
  it("demo reset only removes simulated data, never hardware records", async () => {
    const hw = esp32(env.ctx); await sPost(env.app, hw, rd(hw.id, 1, 5));
    await post_("/dev/simulator/generate", admin, { count: 5 });
    expect((await post_("/dev/demo/reset", admin, {})).status).toBe(400); // confirm required
    const r = await post_("/dev/demo/reset", admin, { confirm: true });
    expect(r.body.recordsRemoved).toBe(15);
    expect(all(env.ctx.live.db, "SELECT 1 FROM readings WHERE source = 'SIMULATOR'")).toHaveLength(0);
    expect(all(env.ctx.live.db, "SELECT 1 FROM readings WHERE source = 'HARDWARE'")).toHaveLength(1);
  });
});

describe("tamper sandbox (isolated)", () => {
  beforeEach(() => { resetSandbox(env.ctx, SYSTEM_ACTOR); });
  it("starts verified, with a genuine excursion that does not break the chain", async () => {
    const s = (await get_("/dev/sandbox", admin)).body;
    expect(s.records).toHaveLength(30); expect(s.lastVerification.status).toBe("VERIFIED");
    expect(s.alerts.temperature.some((a: { kind: string }) => a.kind === "TEMP_EXCURSION")).toBe(true);
    expect(s.alerts.integrity).toHaveLength(0);
  });
  it("detects a modified historical record, shows original vs modified and which links broke", async () => {
    const t = await post_("/dev/sandbox/tamper", admin, { action: "modify", sequence: 12, temperatureC: 3.3 });
    expect(t.status).toBe(200);
    const v = (await post_("/dev/sandbox/verify", admin)).body;
    expect(v.verification.status).toBe("VERIFICATION_FAILED");
    const kinds = v.verification.failures.map((f: { kind: string; sequence: number }) => `${f.kind}@${f.sequence}`);
    expect(kinds).toEqual(expect.arrayContaining(["INVALID_HASH@12", "BROKEN_LINK@13"]));
    const rec = v.state.records.find((r: { sequence: number }) => r.sequence === 12);
    expect(rec.original.temperatureC).toBe(5.1); expect(rec.temperatureC).toBe(3.3); expect(rec.modified).toBe(true);
  });
  it("delete / reorder / consistent-rewrite are each caught; reset restores byte-identical hashes", async () => {
    const before = (await get_("/dev/sandbox", admin)).body.records.map((r: { hash: string }) => r.hash);
    await post_("/dev/sandbox/tamper", admin, { action: "delete", sequence: 8 });
    let v = (await post_("/dev/sandbox/verify", admin)).body.verification;
    expect(v.failures.some((f: { kind: string }) => f.kind === "MISSING_RECORD")).toBe(true);
    await post_("/dev/sandbox/reset", admin);
    await post_("/dev/sandbox/tamper", admin, { action: "reorder", sequence: 5 });
    v = (await post_("/dev/sandbox/verify", admin)).body.verification;
    expect(v.failures.some((f: { kind: string }) => f.kind === "REORDERED")).toBe(true);
    await post_("/dev/sandbox/reset", admin);
    await post_("/dev/sandbox/tamper", admin, { action: "rewrite_chain", sequence: 4, temperatureC: 2.5 });
    v = (await post_("/dev/sandbox/verify", admin)).body.verification;
    expect(v.failures.some((f: { kind: string }) => f.kind === "INVALID_HASH" || f.kind === "BROKEN_LINK")).toBe(false); // chain looks consistent
    expect(v.failures.some((f: { kind: string }) => f.kind === "CHECKPOINT_MISMATCH")).toBe(true); // checkpoint catches it
    const reset = await post_("/dev/sandbox/reset", admin);
    expect(reset.body.state.records.map((r: { hash: string }) => r.hash)).toEqual(before);
    expect(reset.body.verification.status).toBe("VERIFIED");
  });
  it("never touches the real ledger or real alerts", async () => {
    const hw = esp32(env.ctx); await sPost(env.app, hw, rd(hw.id, 1, 5));
    const liveBefore = all(env.ctx.live.db, "SELECT hash FROM readings");
    await post_("/dev/sandbox/tamper", admin, { action: "modify", sequence: 3, temperatureC: 1 });
    await post_("/dev/sandbox/verify", admin);
    expect(all(env.ctx.live.db, "SELECT hash FROM readings")).toEqual(liveBefore);
    expect((await get_("/alerts?scope=LIVE&category=SECURITY", admin)).body.items).toHaveLength(0);
    expect((await get_("/alerts?scope=SANDBOX&category=SECURITY", admin)).body.items.length).toBeGreaterThan(0);
    const live = (await post_("/ledger/verify", admin, { scope: "LEDGER" })).body;
    expect(live.status).toBe("VERIFIED"); expect(live.dataset).toBe("LIVE");
  });
  it("appending after the last checkpoint stays valid", async () => {
    await post_("/dev/sandbox/tamper", admin, { action: "append", count: 3 });
    expect((await post_("/dev/sandbox/verify", admin)).body.verification.status).toBe("VERIFIED");
  });
});

describe("shipments, devices, reports, settings", () => {
  it("creates shipments and enforces one active shipment per device", async () => {
    const ok = await post_("/shipments", admin, { id: "SHP-TEST-1", name: "Test", deviceId: "SIM-COLD-01" });
    expect(ok.status).toBe(201); expect(ok.body.source).toBe("SIMULATOR");
    expect((await post_("/shipments", admin, { id: "SHP-TEST-2", name: "Dup", deviceId: "SIM-COLD-01" })).status).toBe(409);
    expect((await post_("/shipments", admin, { id: "SHP-TEST-3", name: "Bad", minTempC: 9, maxTempC: 3 })).status).toBe(400);
    expect((await post_("/shipments", viewer, { id: "SHP-TEST-4", name: "X" })).status).toBe(403);
  });
  it("registers devices, shows the secret once and never again", async () => {
    const r = await post_("/devices", admin, { id: "COLD-BOX-77", name: "Box", type: "ESP32" });
    expect(r.status).toBe(201); expect(r.body.secret).toMatch(/^[0-9a-f]{64}$/);
    const list = JSON.stringify((await get_("/devices", admin)).body);
    expect(list).not.toContain(r.body.secret); expect(list).not.toContain("secret_enc");
    expect((await post_("/devices", admin, { id: "COLD-BOX-77", name: "Box", type: "ESP32" })).status).toBe(409);
    expect((await post_("/devices", admin, { id: "bad id!", name: "Box", type: "ESP32" })).status).toBe(400);
    const stored = get<{ secret_enc: string }>(env.ctx.live.db, "SELECT secret_enc FROM device_credentials LIMIT 1")!.secret_enc;
    expect(stored).not.toContain(r.body.secret);
  });
  it("shipment excursions are scored against the shipment's own range", async () => {
    const hw = esp32(env.ctx, "COLD-BOX-02");
    await post_("/shipments", admin, { id: "SHP-FROZEN", name: "Frozen", deviceId: hw.id, minTempC: -25, maxTempC: -15 });
    await sPost(env.app, hw, rd(hw.id, 1, -20));
    await sPost(env.app, hw, rd(hw.id, 2, -10));
    const exc = (await get_("/alerts?kind=TEMP_EXCURSION", admin)).body.items;
    expect(exc).toHaveLength(1); expect(exc[0].shipmentId).toBe("SHP-FROZEN"); expect(exc[0].details.direction).toBe("HIGH");
  });
  it("exports CSV/JSON reports with filters, disclaimers and formula-injection protection", async () => {
    await post_("/dev/simulator/generate", admin, { count: 5, deviceIds: ["SIM-COLD-01"] });
    await post_("/ledger/verify", admin, { scope: "LEDGER" });
    const csv = await get_("/reports/temperature?deviceId=SIM-COLD-01", viewer);
    expect(csv.status).toBe(200); expect(csv.headers["content-type"]).toMatch(/text\/csv/); expect(csv.headers["content-disposition"]).toMatch(/attachment/);
    expect(csv.text).toMatch(/NOT certified/); expect(csv.text.split("\n").filter((l) => l.includes("SIM-COLD-01")).length).toBeGreaterThanOrEqual(5);
    expect(csv.text).toContain("VERIFIED");
    const led = await get_("/reports/ledger?format=json", viewer);
    expect(led.body.result).toBe("VERIFIED"); expect(led.body.recordSources.SIMULATOR).toBe(5);
    expect((await get_("/reports/incidents", viewer)).status).toBe(200);
    await post_("/shipments", admin, { id: "SHP-REP-1", name: "=cmd|' /C calc'!A0", deviceId: "SIM-COLD-02" });
    const sr = await get_("/reports/shipments/SHP-REP-1", viewer); expect(sr.status).toBe(200); expect(sr.text).toMatch(/INTEGRITY RESULT/);
    const { csvRow } = await import("../src/services/reports");
    expect(csvRow(["=1+1", "-2.5", -2.5, "a,b"])).toBe(`'=1+1,'-2.5,-2.5,"a,b"`);
    expect((await get_("/reports/shipments/NOPE", viewer)).status).toBe(404);
  });
  it("settings can be changed by admins only, validated, and drive alerting; actions are audited without secrets", async () => {
    const r = await request(env.app).patch("/api/v1/settings").set("Cookie", admin).set(H).send({ tempMaxC: 6 });
    expect(r.body.tempMaxC).toBe(6);
    expect((await request(env.app).patch("/api/v1/settings").set("Cookie", admin).set(H).send({ tempMinC: 7 })).status).toBe(400);
    const hw = esp32(env.ctx); await sPost(env.app, hw, rd(hw.id, 1, 7));
    expect(get<{ c: number }>(env.ctx.live.db, "SELECT COUNT(*) AS c FROM alerts WHERE kind = 'TEMP_EXCURSION'")!.c).toBe(1);
    const aud = (await get_("/audit", admin)).body.items as { action: string }[];
    expect(aud.map((a) => a.action)).toEqual(expect.arrayContaining(["auth.login", "settings.update"]));
    expect(JSON.stringify(aud)).not.toMatch(/admin-password-123/);
  });
  it("alerts can be acknowledged and resolved by admins", async () => {
    const hw = esp32(env.ctx); await sPost(env.app, hw, rd(hw.id, 1, 12));
    const id = (await get_("/alerts", admin)).body.items[0].id;
    const ack = await request(env.app).patch(`/api/v1/alerts/${id}/acknowledge`).set("Cookie", admin).set(H);
    expect(ack.body.acknowledged).toBe(true); expect(ack.body.acknowledgedBy).toMatch(/admin@test.local/);
    expect((await request(env.app).patch(`/api/v1/alerts/${id}/acknowledge`).set("Cookie", viewer).set(H)).status).toBe(403);
    const res = await request(env.app).patch(`/api/v1/alerts/${id}/resolve`).set("Cookie", admin).set(H).send({ note: "Checked" });
    expect(res.body.status).toBe("RESOLVED");
  });
  it("overview returns real aggregates and unknown routes return consistent JSON errors", async () => {
    await post_("/dev/simulator/generate", admin, { count: 4 }); await post_("/ledger/verify", admin, { scope: "LEDGER" });
    const o = (await get_("/overview", admin)).body;
    expect(o.kpis.totalRecords).toBe(12); expect(o.kpis.verifiedRecords).toBe(12); expect(o.kpis.failedRecords).toBe(0);
    expect(o.mode.mode).toBe("SIMULATION"); expect(o.kpis.lastSuccessfulVerificationAt).toBeTruthy();
    const nf = await get_("/nope", admin); expect(nf.status).toBe(404); expect(nf.body.error.code).toBe("NOT_FOUND");
    const bad = await get_("/readings?pageSize=abc", admin); expect(bad.status).toBe(400); expect(bad.body.error.code).toBe("VALIDATION_ERROR");
  });
});
void appendRecord; void createShipment;

describe("retry idempotency", () => {
  it("treats a retry with a regenerated timestamp as a duplicate, not a conflict", async () => {
    const env2 = await makeEnv(); const d = esp32(env2.ctx);
    expect((await sPost(env2.app, d, rd(d.id, 1, 4.4, { recordedAt: "2026-05-05T10:00:00.000Z" }))).status).toBe(201);
    const retry = await sPost(env2.app, d, rd(d.id, 1, 4.4, { recordedAt: "2026-05-05T10:00:09.000Z", firmwareVersion: "1.0.1" }));
    expect(retry.status).toBe(200); expect(retry.body.status).toBe("duplicate");
    expect(all(env2.ctx.live.db, "SELECT 1 FROM alerts WHERE kind = 'SEQUENCE_CONFLICT'")).toHaveLength(0);
    env2.cleanup();
  });
});
