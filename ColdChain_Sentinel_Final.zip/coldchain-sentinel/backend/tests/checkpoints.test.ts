import fs from "node:fs";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { all, run } from "../src/db/index";
import { appendRecord, listDeviceRecords } from "../src/services/ledger";
import { computeRecordHash } from "../src/lib/crypto";
import { createCheckpointFor } from "../src/services/integrity";
import { verifyLedger } from "../src/services/verifier";
import { CheckpointStore } from "../src/services/checkpoints";
import { makeEnv, type TestEnv } from "./helpers";
import type { ReadingRow } from "../src/services/ledger";
import { rowToRecord } from "../src/services/ledger";

const dev = "SIM-COLD-01";
describe("signed checkpoints", () => {
  let env: TestEnv;
  beforeEach(async () => {
    env = await makeEnv();
    for (let i = 1; i <= 12; i++) appendRecord(env.ctx.live.db, { deviceId: dev, sequence: i, temperatureC: 5 + i / 20, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date(1.8e12 + i * 1000).toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    createCheckpointFor(env.ctx, env.ctx.live, dev);
  });
  afterEach(() => env.cleanup());
  const v = () => verifyLedger(env.ctx.live.db, env.ctx.live.checkpoints, "LIVE", { scope: "LEDGER" });

  it("creates a signed checkpoint that verifies", () => {
    expect(env.ctx.live.checkpoints.latest(dev)?.lastSequence).toBe(12);
    const r = v(); expect(r.status).toBe("VERIFIED"); expect(r.checkpointsChecked).toBe(1);
  });
  it("catches a consistent rewrite (attacker recomputes every hash) via CHECKPOINT_MISMATCH", () => {
    const db = env.ctx.live.db;
    run(db, "UPDATE readings SET temperature_c = 9.5 WHERE device_id = ? AND sequence = 3", dev);
    let prev = "";
    for (const r of all<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? ORDER BY sequence", dev).map(rowToRecord)) {
      const ph = r.sequence === 1 ? r.previousHash : prev;
      const h = computeRecordHash({ ...r, previousHash: ph });
      run(db, "UPDATE readings SET previous_hash = ?, hash = ? WHERE id = ?", ph, h, r.id);
      prev = h;
    }
    const res = v();
    // hash chain alone is now self-consistent...
    expect(res.failures.some((f) => f.kind === "INVALID_HASH" || f.kind === "BROKEN_LINK")).toBe(false);
    // ...but the signed checkpoint exposes the rewrite
    expect(res.status).toBe("VERIFICATION_FAILED");
    expect(res.failures.some((f) => f.kind === "CHECKPOINT_MISMATCH")).toBe(true);
  });
  it("detects an edited checkpoint file (bad signature) and a deleted file", () => {
    const file = env.ctx.live.checkpoints.rawFilePath(dev);
    const original = fs.readFileSync(file, "utf8");
    fs.writeFileSync(file, original.replace('"lastSequence":12', '"lastSequence":11'));
    expect(v().failures.some((f) => f.kind === "CHECKPOINT_MISMATCH" && /signature/.test(f.message))).toBe(true);
    fs.rmSync(file);
    expect(v().failures.some((f) => f.kind === "CHECKPOINT_MISMATCH" && /missing/.test(f.message))).toBe(true);
  });
  it("rejects checkpoints signed with a different key", () => {
    const other = new CheckpointStore(env.dir + "/cp", Buffer.alloc(32, 1), env.ctx.live.db);
    expect(other.read(dev).problems.length).toBeGreaterThan(0);
  });
  it("detects deletion of middle checkpoints (digest chain)", () => {
    const db = env.ctx.live.db;
    for (let i = 13; i <= 24; i++) appendRecord(db, { deviceId: dev, sequence: i, temperatureC: 5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date(1.8e12 + i * 1000).toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    createCheckpointFor(env.ctx, env.ctx.live, dev);
    for (let i = 25; i <= 30; i++) appendRecord(db, { deviceId: dev, sequence: i, temperatureC: 5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date(1.8e12 + i * 1000).toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    createCheckpointFor(env.ctx, env.ctx.live, dev);
    expect(v().status).toBe("VERIFIED");
    const file = env.ctx.live.checkpoints.rawFilePath(dev);
    const lines = fs.readFileSync(file, "utf8").trim().split("\n");
    fs.writeFileSync(file, [lines[0], lines[2]].join("\n") + "\n");
    expect(v().failures.some((f) => f.kind === "CHECKPOINT_MISMATCH")).toBe(true);
  });
  it("refuses to checkpoint a corrupted ledger", () => {
    run(env.ctx.live.db, "UPDATE readings SET temperature_c = 1 WHERE device_id = ? AND sequence = 8", dev);
    appendRecord(env.ctx.live.db, { deviceId: dev, sequence: 13, temperatureC: 5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date().toISOString(), source: "SIMULATOR", firmwareVersion: "1", shipmentId: null });
    expect(listDeviceRecords(env.ctx.live.db, dev)).toHaveLength(13);
    // corruption is before the last checkpoint anchor, so a new checkpoint covers only the tail; full verify still fails:
    expect(v().status).toBe("VERIFICATION_FAILED");
  });
});
