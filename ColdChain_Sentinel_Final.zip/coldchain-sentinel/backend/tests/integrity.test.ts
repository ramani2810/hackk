import fs from "node:fs";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { all, get, run } from "../src/db/index";
import { SYSTEM_ACTOR } from "../src/services/audit";
import { createCheckpointFor, runVerification } from "../src/services/integrity";
import { appendRecord } from "../src/services/ledger";
import { resetSandbox, sandboxState, tamper } from "../src/services/sandbox";
import { resetDemoData } from "../src/services/simulator";
import { ingestReading } from "../src/services/ingest";
import { getDeviceRow } from "../src/services/devices";
import { ADMIN, CSRF, login, makeHarness, type Harness } from "./helpers";
import { computeRecordHash } from "../src/lib/crypto";
import { listDeviceRecords } from "../src/services/ledger";

let h: Harness;
beforeEach(async () => { h = await makeHarness(); });
afterEach(() => h.cleanup());

const verifyLive = () => runVerification(h.ctx, h.ctx.live, { scope: "LEDGER" }, SYSTEM_ACTOR);
const verifySbx = () => runVerification(h.ctx, h.ctx.sandbox, { scope: "LEDGER" }, SYSTEM_ACTOR);
const feed = (id: string, n: number, temp = (i: number) => 4 + (i % 5) / 10) => {
  const dev = getDeviceRow(h.ctx, id)!;
  for (let i = 0; i < n; i++) ingestReading(h.ctx, dev, { deviceId: id, sequence: dev.last_sequence + 1 + i, temperatureC: temp(i), sensorStatus: "OK", firmwareVersion: "t" });
};

describe("verification service", () => {
  it("passes on an untouched ledger, stores the run and marks every record VERIFIED", () => {
    feed("SIM-COLD-01", 25); feed("SIM-COLD-02", 7);
    const r = verifyLive();
    expect(r.status).toBe("VERIFIED");
    expect(r.recordsChecked).toBe(32);
    expect(r.devicesChecked).toBe(2);
    expect(get<{ c: number }>(h.ctx.live.db, "SELECT COUNT(*) AS c FROM record_integrity WHERE status='VERIFIED'")!.c).toBe(32);
  });
  it("an empty ledger verifies trivially with zero records", () => {
    const r = verifyLive();
    expect(r.status).toBe("VERIFIED");
    expect(r.recordsChecked).toBe(0);
  });
  it("tampering the LIVE ledger fails verification, raises SECURITY alerts, preserves the corrupted record and does not repair it", () => {
    feed("SIM-COLD-01", 20);
    expect(verifyLive().status).toBe("VERIFIED");
    run(h.ctx.live.db, "UPDATE readings SET temperature_c = 7.5 WHERE device_id='SIM-COLD-01' AND sequence = 8");
    const r = verifyLive();
    expect(r.status).toBe("VERIFICATION_FAILED");
    expect(r.failures.map((f) => f.kind)).toContain("INVALID_HASH");
    expect(r.failures.map((f) => f.kind)).toContain("BROKEN_LINK");
    expect(get<{ t: number }>(h.ctx.live.db, "SELECT temperature_c AS t FROM readings WHERE sequence = 8 AND device_id='SIM-COLD-01'")!.t).toBe(7.5);
    const kinds = all<{ kind: string; category: string }>(h.ctx.live.db, "SELECT kind, category FROM alerts WHERE scope='LIVE'");
    expect(kinds.some((k) => k.kind === "HASH_MISMATCH" && k.category === "SECURITY")).toBe(true);
    expect(get<{ status: string }>(h.ctx.live.db, "SELECT i.status FROM record_integrity i JOIN readings r ON r.id=i.record_id WHERE r.sequence = 8 AND r.device_id='SIM-COLD-01'")!.status).toBe("INVALID_HASH");
    const again = verifyLive();
    expect(again.status).toBe("VERIFICATION_FAILED");
    expect(all(h.ctx.live.db, "SELECT 1 FROM alerts WHERE kind='HASH_MISMATCH' AND status='OPEN'").length).toBe(1);
  });
  it("per-device scope verifies only that device's chain", () => {
    feed("SIM-COLD-01", 12); feed("SIM-COLD-02", 12);
    run(h.ctx.live.db, "UPDATE readings SET temperature_c = 9 WHERE device_id='SIM-COLD-02' AND sequence = 3");
    expect(runVerification(h.ctx, h.ctx.live, { scope: "DEVICE", deviceId: "SIM-COLD-01" }, SYSTEM_ACTOR).status).toBe("VERIFIED");
    expect(runVerification(h.ctx, h.ctx.live, { scope: "DEVICE", deviceId: "SIM-COLD-02" }, SYSTEM_ACTOR).status).toBe("VERIFICATION_FAILED");
  });
  it("time-range verification covers exactly the selected records and is anchored to the record just before the range", () => {
    for (let i = 1; i <= 12; i++) {
      const r = appendRecord(h.ctx.live.db, { deviceId: "SIM-COLD-03", sequence: i, temperatureC: 4.5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: new Date(1.8e12 + i * 60_000).toISOString(), source: "SIMULATOR", firmwareVersion: "t", shipmentId: null });
      expect(r.kind).toBe("created");
    }
    const at = (i: number) => new Date(1.8e12 + i * 60_000).toISOString();
    const clean = runVerification(h.ctx, h.ctx.live, { scope: "RANGE", deviceId: "SIM-COLD-03", from: at(6), to: at(9) }, SYSTEM_ACTOR);
    expect(clean.status).toBe("VERIFIED");
    expect(clean.recordsChecked).toBe(4);
    run(h.ctx.live.db, "UPDATE readings SET temperature_c = 9 WHERE device_id='SIM-COLD-03' AND sequence = 3");
    expect(runVerification(h.ctx, h.ctx.live, { scope: "RANGE", deviceId: "SIM-COLD-03", from: at(6), to: at(9) }, SYSTEM_ACTOR).status).toBe("VERIFIED");
    expect(runVerification(h.ctx, h.ctx.live, { scope: "RANGE", deviceId: "SIM-COLD-03", from: at(2), to: at(5) }, SYSTEM_ACTOR).status).toBe("VERIFICATION_FAILED");
  });
  it("detects deletion of the NEWEST records using the device registry", () => {
    feed("SIM-COLD-01", 12);
    run(h.ctx.live.db, "DELETE FROM readings WHERE device_id='SIM-COLD-01' AND sequence > 10");
    const r = verifyLive();
    expect(r.status).toBe("VERIFICATION_FAILED");
    expect(r.failures.some((f) => f.kind === "MISSING_RECORD")).toBe(true);
  });
});

describe("signed checkpoints", () => {
  it("are created automatically every N records, signed, and stored outside the database", () => {
    feed("SIM-COLD-01", 25);
    const cps = h.ctx.live.checkpoints.read("SIM-COLD-01");
    expect(cps.problems).toEqual([]);
    expect(cps.checkpoints.map((c) => c.lastSequence)).toEqual([10, 20]);
    expect(fs.existsSync(h.ctx.live.checkpoints.rawFilePath("SIM-COLD-01"))).toBe(true);
    expect(cps.checkpoints[0]!.signature).toMatch(/^[0-9a-f]{64}$/);
    expect(JSON.stringify(all(h.ctx.live.db, "SELECT * FROM checkpoints"))).not.toContain(h.ctx.config.checkpointKey.toString("hex"));
    expect(verifyLive().checkpointsChecked).toBe(2);
  });
  it("catch an attacker who edits a record AND re-computes every hash (the basic chain alone cannot)", () => {
    feed("SIM-COLD-01", 25);
    const db = h.ctx.live.db;
    run(db, "UPDATE readings SET temperature_c = 6.1 WHERE device_id='SIM-COLD-01' AND sequence = 5");
    let prev = listDeviceRecords(db, "SIM-COLD-01")[0]!.previousHash;
    for (const rec of listDeviceRecords(db, "SIM-COLD-01")) {
      const hash = computeRecordHash({ ...rec, previousHash: prev });
      run(db, "UPDATE readings SET previous_hash = ?, hash = ? WHERE id = ?", prev, hash, rec.id);
      prev = hash;
    }
    const r = verifyLive();
    expect(r.status).toBe("VERIFICATION_FAILED");
    const kinds = new Set(r.failures.map((f) => f.kind));
    expect(kinds.has("INVALID_HASH")).toBe(false);
    expect(kinds.has("BROKEN_LINK")).toBe(false);
    expect(kinds.has("CHECKPOINT_MISMATCH")).toBe(true);
    expect(all<{ kind: string }>(db, "SELECT kind FROM alerts WHERE category='SECURITY'").some((a) => a.kind === "CHECKPOINT_MISMATCH")).toBe(true);
  });
  it("detect a forged or edited checkpoint file (wrong signature)", () => {
    feed("SIM-COLD-01", 12);
    const f = h.ctx.live.checkpoints.rawFilePath("SIM-COLD-01");
    const cp = JSON.parse(fs.readFileSync(f, "utf8").trim());
    cp.headHash = "ab".repeat(32);
    fs.writeFileSync(f, JSON.stringify(cp) + "\n");
    const r = verifyLive();
    expect(r.status).toBe("VERIFICATION_FAILED");
    expect(r.failures.some((x) => x.kind === "CHECKPOINT_MISMATCH" && /signature/.test(x.message))).toBe(true);
  });
  it("detect a deleted checkpoint file and a truncated checkpoint chain", () => {
    feed("SIM-COLD-01", 25);
    const f = h.ctx.live.checkpoints.rawFilePath("SIM-COLD-01");
    const lines = fs.readFileSync(f, "utf8").trim().split("\n");
    fs.writeFileSync(f, lines[0] + "\n");
    expect(verifyLive().failures.some((x) => x.kind === "CHECKPOINT_MISMATCH")).toBe(true);
    fs.rmSync(f);
    expect(verifyLive().failures.some((x) => x.kind === "CHECKPOINT_MISMATCH" && /missing/.test(x.message))).toBe(true);
  });
  it("cannot be forged without the signing key", () => {
    feed("SIM-COLD-01", 12);
    const f = h.ctx.live.checkpoints.rawFilePath("SIM-COLD-01");
    const cp = JSON.parse(fs.readFileSync(f, "utf8").trim());
    cp.signature = "00".repeat(32);
    fs.writeFileSync(f, JSON.stringify(cp) + "\n");
    expect(h.ctx.live.checkpoints.read("SIM-COLD-01").checkpoints).toHaveLength(0);
  });
  it("refuse to checkpoint a ledger that already fails verification", () => {
    feed("SIM-COLD-01", 5);
    run(h.ctx.live.db, "UPDATE readings SET temperature_c = 9 WHERE device_id='SIM-COLD-01' AND sequence = 2");
    expect(() => createCheckpointFor(h.ctx, h.ctx.live, "SIM-COLD-01")).toThrow(/Refusing/);
  });
});

describe("temperature alerts are separate from integrity alerts", () => {
  it("a genuine excursion creates a TEMPERATURE alert and the ledger still verifies", () => {
    feed("SIM-COLD-01", 10, (i) => (i === 4 || i === 5 ? 11.2 : 5));
    const exc = all<{ category: string; kind: string; status: string }>(h.ctx.live.db, "SELECT category, kind, status FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'");
    expect(exc).toHaveLength(1);
    expect(exc[0]!.category).toBe("TEMPERATURE");
    expect(all(h.ctx.live.db, "SELECT 1 FROM alerts WHERE category='SECURITY' AND scope='LIVE'")).toHaveLength(0);
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("tracks duration, escalates severity, and auto-resolves after the documented recovery rule (2 in-range readings)", () => {
    feed("SIM-COLD-01", 3, () => 5);
    feed("SIM-COLD-01", 3, () => 12.5);
    let a = get<{ status: string; severity: string; details_json: string }>(h.ctx.live.db, "SELECT * FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")!;
    expect(a.status).toBe("OPEN");
    expect(a.severity).toBe("CRITICAL");
    expect(JSON.parse(a.details_json).outOfRangeReadings).toBe(3);
    feed("SIM-COLD-01", 1, () => 5);
    expect(get<{ status: string }>(h.ctx.live.db, "SELECT status FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")!.status).toBe("OPEN");
    feed("SIM-COLD-01", 1, () => 5);
    a = get(h.ctx.live.db, "SELECT * FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")!;
    expect(a.status).toBe("RESOLVED");
    expect(get(h.ctx.live.db, "SELECT 1 AS x FROM alerts WHERE kind='TEMP_RECOVERED'")).toBeTruthy();
  });
  it("low temperatures also raise an excursion", () => {
    feed("SIM-COLD-01", 1, () => 0.5);
    expect(get<{ d: string }>(h.ctx.live.db, "SELECT details_json AS d FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")!.d).toMatch(/LOW/);
  });
  it("sensor disconnection raises SENSOR_DISCONNECTED (not an integrity alert) and recovers", () => {
    const dev = getDeviceRow(h.ctx, "SIM-COLD-01")!;
    ingestReading(h.ctx, dev, { deviceId: dev.id, sequence: 1, sensorStatus: "DISCONNECTED", temperatureC: null });
    expect(get<{ category: string }>(h.ctx.live.db, "SELECT category FROM alerts WHERE kind='SENSOR_DISCONNECTED'")!.category).toBe("TEMPERATURE");
    feed("SIM-COLD-01", 1);
    expect(get<{ status: string }>(h.ctx.live.db, "SELECT status FROM alerts WHERE kind='SENSOR_DISCONNECTED'")!.status).toBe("RESOLVED");
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("changing the configured thresholds changes what counts as an excursion", () => {
    run(h.ctx.live.db, "INSERT INTO settings (key,value) VALUES ('tempMaxC','4.5')");
    feed("SIM-COLD-01", 1, () => 5);
    expect(get(h.ctx.live.db, "SELECT 1 AS x FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")).toBeTruthy();
  });
});

describe("concurrent ingestion", () => {
  it("serialises parallel appends: no duplicate sequence, no forked chain", async () => {
    const dev = getDeviceRow(h.ctx, "SIM-COLD-01")!;
    const results = await Promise.all(Array.from({ length: 40 }, (_, i) =>
      Promise.resolve().then(() => { try { return appendRecord(h.ctx.live.db, { deviceId: dev.id, sequence: i % 20 + 1, temperatureC: 4.5, humidityPct: null, sensorStatus: "OK", deviceTimestamp: null, receivedAt: h.ctx.now(), source: "SIMULATOR", firmwareVersion: "t", shipmentId: null }).kind; } catch (e) { return "error:" + (e as Error).message; } })));
    expect(results.filter((r) => r === "created").length).toBeLessThanOrEqual(20);
    expect(results.some((r) => r.startsWith("error"))).toBe(false);
    const seqs = all<{ sequence: number }>(h.ctx.live.db, "SELECT sequence FROM readings WHERE device_id='SIM-COLD-01'").map((r) => r.sequence);
    expect(new Set(seqs).size).toBe(seqs.length);
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("100 simultaneous signed HTTP requests produce one linear, verifiable chain", async () => {
    const { signedPost, reading } = await import("./helpers");
    const res = await Promise.all(Array.from({ length: 100 }, (_, i) => signedPost(h, reading(i + 1, 4 + (i % 10) / 10))));
    expect(res.every((r) => r.status === 201)).toBe(true);
    const rows = all<{ sequence: number; previous_hash: string; hash: string }>(h.ctx.live.db, "SELECT sequence, previous_hash, hash FROM readings WHERE device_id='COLD-BOX-01' ORDER BY ledger_index");
    expect(rows).toHaveLength(100);
    for (let i = 1; i < rows.length; i++) expect(rows[i]!.previous_hash).toBe(rows[i - 1]!.hash);
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("two verifier-independent processes cannot both write the same sequence (database UNIQUE constraint)", () => {
    feed("SIM-COLD-01", 1);
    expect(() => run(h.ctx.live.db, "INSERT INTO readings (id,device_id,sequence,sensor_status,received_at,source,previous_hash,hash) VALUES ('x','SIM-COLD-01',1,'OK','t','SIMULATOR','a','b')")).toThrow(/UNIQUE/);
  });
});

describe("simulator", () => {
  it("uses the same ingestion path: SIMULATOR-labelled, hash-chained, checkpointed and verifiable", () => {
    h.ctx.simulator.tickOnce();
    for (let i = 0; i < 24; i++) h.ctx.simulator.tickOnce();
    const rows = all<{ source: string; device_id: string }>(h.ctx.live.db, "SELECT source, device_id FROM readings");
    expect(rows.length).toBe(75);
    expect(rows.every((r) => r.source === "SIMULATOR")).toBe(true);
    expect(rows.some((r) => r.device_id === "COLD-BOX-01")).toBe(false);
    expect(h.ctx.live.checkpoints.read("SIM-COLD-01").checkpoints.length).toBe(2);
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("can trigger an excursion and a sensor disconnection on demand", () => {
    h.ctx.simulator.tickOnce(["SIM-COLD-01"]);
    h.ctx.simulator.triggerExcursion("SIM-COLD-01", { peakC: 12, readings: 4 });
    for (let i = 0; i < 6; i++) h.ctx.simulator.tickOnce(["SIM-COLD-01"]);
    expect(get(h.ctx.live.db, "SELECT 1 AS x FROM alerts WHERE kind='TEMP_EXCURSION' AND scope='LIVE'")).toBeTruthy();
    h.ctx.simulator.triggerDisconnect("SIM-COLD-01", 2);
    h.ctx.simulator.tickOnce(["SIM-COLD-01"]);
    expect(get(h.ctx.live.db, "SELECT 1 AS x FROM alerts WHERE kind='SENSOR_DISCONNECTED'")).toBeTruthy();
    expect(() => h.ctx.simulator.triggerExcursion("COLD-BOX-01")).toThrow();
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("start/stop and reset only touch simulated data, never hardware records", async () => {
    const { signedPost, reading } = await import("./helpers");
    await signedPost(h, reading(1, 4.4));
    h.ctx.simulator.start({ intervalSec: 1 });
    expect(h.ctx.simulator.state().running).toBe(true);
    h.ctx.simulator.stop();
    expect(h.ctx.simulator.state().running).toBe(false);
    const out = resetDemoData(h.ctx);
    expect(out.recordsRemoved).toBeGreaterThan(0);
    expect(get<{ c: number }>(h.ctx.live.db, "SELECT COUNT(*) AS c FROM readings WHERE source='SIMULATOR'")!.c).toBe(0);
    expect(get<{ c: number }>(h.ctx.live.db, "SELECT COUNT(*) AS c FROM readings WHERE source='HARDWARE'")!.c).toBe(1);
    expect(getDeviceRow(h.ctx, "SIM-COLD-01")!.last_sequence).toBe(0);
    expect(verifyLive().status).toBe("VERIFIED");
  });
});

describe("tamper-demonstration sandbox (end to end)", () => {
  it("starts valid, with a GENUINE excursion that is a temperature alert and not an integrity failure", () => {
    const s = sandboxState(h.ctx);
    expect(s.records).toHaveLength(30);
    expect(s.lastVerification!.status).toBe("VERIFIED");
    expect(s.alerts.temperature.some((a) => a.kind === "TEMP_EXCURSION")).toBe(true);
    expect(s.alerts.integrity).toHaveLength(0);
    expect(s.records.some((r) => r.temperatureC! > 8)).toBe(true);
  });
  it("modify -> verification fails at the modified record and the following link; original vs modified is shown", () => {
    tamper(h.ctx, { action: "modify", sequence: 12, temperatureC: 3.3 }, SYSTEM_ACTOR);
    const v = verifySbx();
    expect(v.status).toBe("VERIFICATION_FAILED");
    const inv = v.failures.find((f) => f.kind === "INVALID_HASH")!;
    expect(inv.sequence).toBe(12);
    expect(v.failures.find((f) => f.kind === "BROKEN_LINK")!.sequence).toBe(13);
    const st = sandboxState(h.ctx);
    const rec = st.records.find((r) => r.sequence === 12)!;
    expect(rec.temperatureChanged).toBe(true);
    expect(rec.original!.temperatureC).toBe(5.1);
    expect(rec.temperatureC).toBe(3.3);
    expect(rec.integrity.status).toBe("INVALID_HASH");
    expect(st.alerts.integrity.length).toBeGreaterThan(0);
  });
  it("delete and reorder are detected", () => {
    tamper(h.ctx, { action: "delete", sequence: 7 }, SYSTEM_ACTOR);
    const v = verifySbx();
    expect(v.failures.map((f) => f.kind)).toEqual(expect.arrayContaining(["BROKEN_LINK", "MISSING_RECORD"]));
    expect(sandboxState(h.ctx).deleted.map((d) => d.sequence)).toEqual([7]);
    resetSandbox(h.ctx, SYSTEM_ACTOR);
    tamper(h.ctx, { action: "reorder", sequence: 4 }, SYSTEM_ACTOR);
    const v2 = verifySbx();
    expect(v2.failures.map((f) => f.kind)).toEqual(expect.arrayContaining(["REORDERED"]));
  });
  it("full chain rewrite passes the hash chain but is caught by the signed checkpoint", () => {
    tamper(h.ctx, { action: "rewrite_chain", sequence: 5, temperatureC: 6.6 }, SYSTEM_ACTOR);
    const v = verifySbx();
    const kinds = new Set(v.failures.map((f) => f.kind));
    expect(kinds.has("INVALID_HASH")).toBe(false);
    expect(kinds.has("BROKEN_LINK")).toBe(false);
    expect(kinds.has("CHECKPOINT_MISMATCH")).toBe(true);
  });
  it("appending legitimate records after the checkpoint keeps the sandbox valid", () => {
    tamper(h.ctx, { action: "append", count: 3 }, SYSTEM_ACTOR);
    expect(verifySbx().status).toBe("VERIFIED");
  });
  it("reset restores the identical initial dataset (byte-identical hashes)", () => {
    const before = all<{ hash: string }>(h.ctx.sandbox.db, "SELECT hash FROM readings ORDER BY sequence").map((r) => r.hash);
    tamper(h.ctx, { action: "rewrite_chain", sequence: 2, temperatureC: 9 }, SYSTEM_ACTOR);
    tamper(h.ctx, { action: "delete", sequence: 20 }, SYSTEM_ACTOR);
    resetSandbox(h.ctx, SYSTEM_ACTOR);
    expect(all<{ hash: string }>(h.ctx.sandbox.db, "SELECT hash FROM readings ORDER BY sequence").map((r) => r.hash)).toEqual(before);
    expect(sandboxState(h.ctx).lastVerification!.status).toBe("VERIFIED");
    expect(sandboxState(h.ctx).alerts.integrity).toHaveLength(0);
  });
  it("never touches the real ledger, its alerts or its verification history", async () => {
    feed("SIM-COLD-01", 12);
    const before = JSON.stringify(all(h.ctx.live.db, "SELECT hash, temperature_c FROM readings ORDER BY ledger_index"));
    const liveRuns = get<{ c: number }>(h.ctx.live.db, "SELECT COUNT(*) AS c FROM verification_runs")!.c;
    tamper(h.ctx, { action: "modify", sequence: 3, temperatureC: 1 }, SYSTEM_ACTOR);
    verifySbx();
    expect(JSON.stringify(all(h.ctx.live.db, "SELECT hash, temperature_c FROM readings ORDER BY ledger_index"))).toBe(before);
    expect(get<{ c: number }>(h.ctx.live.db, "SELECT COUNT(*) AS c FROM verification_runs")!.c).toBe(liveRuns);
    expect(all(h.ctx.live.db, "SELECT 1 FROM alerts WHERE scope='LIVE' AND category='SECURITY'")).toHaveLength(0);
    expect(verifyLive().status).toBe("VERIFIED");
  });
  it("the HTTP API drives the whole demo and sandbox alerts do not pollute LIVE alert lists", async () => {
    const a = await login(h, ADMIN);
    expect((await a.post("/api/v1/dev/sandbox/reset").set(CSRF)).status).toBe(200);
    const t = await a.post("/api/v1/dev/sandbox/tamper").set(CSRF).send({ action: "modify", sequence: 9, temperatureC: 2.2 });
    expect(t.status).toBe(200);
    const v = await a.post("/api/v1/dev/sandbox/verify").set(CSRF);
    expect(v.body.verification.status).toBe("VERIFICATION_FAILED");
    expect((await a.get("/api/v1/alerts?scope=LIVE&category=SECURITY")).body.total).toBe(0);
    expect((await a.get("/api/v1/alerts?scope=SANDBOX&category=SECURITY")).body.total).toBeGreaterThan(0);
    expect((await a.post("/api/v1/dev/sandbox/tamper").set(CSRF).send({ action: "modify", sequence: 9999, temperatureC: 2 })).status).toBe(404);
    expect((await a.post("/api/v1/dev/sandbox/tamper").set(CSRF).send({ action: "drop_tables" })).status).toBe(400);
    expect((await a.post("/api/v1/dev/demo/reset").set(CSRF).send({})).status).toBe(400);
    expect((await a.post("/api/v1/dev/demo/reset").set(CSRF).send({ confirm: true })).status).toBe(200);
  });
  it("dev endpoints are disabled (404) in production mode, even for admins", async () => {
    const prod = await makeHarness({ nodeEnv: "production", enableDevEndpoints: true });
    expect(prod.ctx.config.enableDevEndpoints).toBe(false);
    const a = await login(prod, ADMIN);
    expect((await a.get("/api/v1/dev/sandbox")).status).toBe(404);
    expect((await a.post("/api/v1/dev/simulator/start").set(CSRF).send({})).status).toBe(404);
    expect((await a.post("/api/v1/dev/sandbox/tamper").set(CSRF).send({ action: "delete", sequence: 1 })).status).toBe(404);
    prod.cleanup();
  });
});

describe("audit and secrets hygiene", () => {
  it("audit events are recorded for admin operations and contain no secrets", async () => {
    const a = await login(h, ADMIN);
    const c = await a.post("/api/v1/devices").set(CSRF).send({ id: "AUDIT-DEV-1", name: "x", type: "ESP32" });
    await a.post("/api/v1/ledger/verify").set(CSRF).send({ scope: "LEDGER" });
    await a.post("/api/v1/devices/AUDIT-DEV-1/revoke").set(CSRF);
    const actions = all<{ action: string }>(h.ctx.live.db, "SELECT action FROM audit_events").map((x) => x.action);
    expect(actions).toEqual(expect.arrayContaining(["device.register", "ledger.verify", "device.credential_revoked", "auth.login", "sandbox.reset"]));
    expect(JSON.stringify(all(h.ctx.live.db, "SELECT * FROM audit_events"))).not.toContain(c.body.secret);
    const list = await a.get("/api/v1/audit?pageSize=5");
    expect(list.status).toBe(200);
    expect(list.body.items.length).toBeGreaterThan(0);
  });
});
