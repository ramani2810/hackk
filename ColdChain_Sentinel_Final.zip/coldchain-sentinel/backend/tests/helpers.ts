import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import request from "supertest";
import type { Express } from "express";
import { createApp } from "../src/app";
import { loadConfig, type AppConfig } from "../src/config";
import { createContext, type AppContext } from "../src/context";
import { createUser } from "../src/services/auth";
import { createDevice } from "../src/services/devices";
import { SYSTEM_ACTOR } from "../src/services/audit";
import { hmacSha256Hex } from "../src/lib/crypto";
import { ensureSimulatedDevices } from "../src/services/devices";
import { resetSandbox } from "../src/services/sandbox";

export interface TestEnv { ctx: AppContext; app: Express; dir: string; cleanup: () => void }

export async function makeEnv(over: Partial<AppConfig> = {}): Promise<TestEnv> {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ccs-test-"));
  const config = loadConfig({
    nodeEnv: "test", logLevel: "silent", dataDir: dir, checkpointDir: path.join(dir, "cp"), sandboxCheckpointDir: path.join(dir, "scp"),
    deviceSecretKey: Buffer.alloc(32, 7), checkpointKey: Buffer.alloc(32, 9), enableDevEndpoints: true, checkpointEvery: 10,
    loginRateMax: 5, ...over,
  });
  const ctx = await createContext(config, { memory: true });
  ensureSimulatedDevices(ctx);
  const app = createApp(ctx);
  return { ctx, app, dir, cleanup: () => { ctx.close(); fs.rmSync(dir, { recursive: true, force: true }); } };
}

export const H = { "X-Requested-With": "ColdChainSentinel" };

export function seedUsers(ctx: AppContext) {
  createUser(ctx, { email: "admin@test.local", name: "Admin", role: "ADMIN", password: "admin-password-123" });
  createUser(ctx, { email: "viewer@test.local", name: "Viewer", role: "VIEWER", password: "viewer-password-123" });
}

export async function loginCookie(app: Express, email: string, password: string) {
  const res = await request(app).post("/api/v1/auth/login").set(H).send({ email, password });
  const cookie = (res.headers["set-cookie"] as unknown as string[] | undefined)?.[0]?.split(";")[0] ?? "";
  return { res, cookie };
}

export function esp32(ctx: AppContext, id = "TEST-ESP-01") {
  const r = createDevice(ctx, { id, name: id, type: "ESP32" }, SYSTEM_ACTOR);
  return { id, secret: r.secret! };
}

export function signedPostDev(app: Express, dev: { id: string; secret: string }, body: object, opts: { secret?: string; deviceHeader?: string } = {}) {
  const raw = JSON.stringify(body);
  return request(app).post("/api/v1/readings").set("Content-Type", "application/json")
    .set("X-Device-Id", opts.deviceHeader ?? dev.id).set("X-Signature", hmacSha256Hex(opts.secret ?? dev.secret, raw)).send(raw);
}

export const readingOf = (deviceId: string, sequence: number, t = 5, extra: object = {}) =>
  ({ deviceId, sequence, temperatureC: t, sensorStatus: "OK", recordedAt: new Date().toISOString(), firmwareVersion: "1.0.0", ...extra });

/* ---- Harness used by tests/integrity.test.ts ---- */
export type Harness = TestEnv & { hw: { id: string; secret: string } };
export const CSRF = H;
export const ADMIN = { email: "admin@test.local", password: "admin-password-123" };
export const VIEWER = { email: "viewer@test.local", password: "viewer-password-123" };

/** Environment with users and the seeded tamper sandbox, like a freshly seeded dev install. */
export async function makeHarness(over: Partial<AppConfig> = {}): Promise<Harness> {
  const env = await makeEnv({ cookieSecure: false, ...over });
  seedUsers(env.ctx);
  resetSandbox(env.ctx, SYSTEM_ACTOR);
  const hw = esp32(env.ctx, "COLD-BOX-01");
  return { ...env, hw };
}

/** Harness-style helpers: sign and POST a reading for the harness's physical device COLD-BOX-01. */
export const reading = (sequence: number, t = 5, extra: object = {}) => readingOf("COLD-BOX-01", sequence, t, extra);
export function signedPost(h: Harness, body: object, opts: { secret?: string } = {}) {
  return signedPostDev(h.app, h.hw, body, opts);
}

/** Logs in and returns a supertest agent that keeps the session cookie. */
export async function login(h: Harness, creds: { email: string; password: string }) {
  const agent = request.agent(h.app);
  const res = await agent.post("/api/v1/auth/login").set(H).send(creds);
  if (res.status !== 200) throw new Error(`test login failed: ${res.status}`);
  return agent;
}
