import { all } from "../db/index";
import type { AppContext } from "../context";
import { getSettings } from "./settings";
import { raiseAlert } from "./alerts";
import { purgeExpiredSessions } from "./auth";

/**
 * Background watchdog: raises STALE_READINGS when a device that should be reporting goes silent.
 * "Online" is always derived from the server-side last-seen time, never from the browser being open.
 * Simulated devices are only watched while the simulator is running (stopping it is not a fault).
 */
export function checkStale(ctx: AppContext) {
  const settings = getSettings(ctx.live.db);
  const sim = ctx.simulator.state();
  const rows = all<{ id: string; type: string; last_seen_at: string | null }>(ctx.live.db, "SELECT id, type, last_seen_at FROM devices WHERE last_seen_at IS NOT NULL AND type <> 'SANDBOX'");
  const nowMs = Date.now();
  for (const d of rows) {
    if (d.type === "SIMULATED" && !(sim.running && sim.deviceIds.includes(d.id))) continue;
    const age = Math.round((nowMs - Date.parse(d.last_seen_at!)) / 1000);
    if (age > settings.staleSeconds) {
      raiseAlert(ctx, {
        kind: "STALE_READINGS", severity: "MEDIUM", deviceId: d.id, dedupeKey: `stale:${d.id}`,
        title: `No readings from ${d.id} for ${age} s`,
        description: `Device ${d.id} has not delivered a reading for ${age} seconds (limit ${settings.staleSeconds} s). It may be offline, out of Wi-Fi range or powered down. Data between the last reading and now is missing.`,
        details: { lastSeenAt: d.last_seen_at, ageSeconds: age, staleSeconds: settings.staleSeconds },
      });
    }
  }
}

export function startMonitor(ctx: AppContext): () => void {
  const t = setInterval(() => {
    try {
      checkStale(ctx);
      purgeExpiredSessions(ctx);
    } catch (err) {
      ctx.log.error("monitor failed", { error: (err as Error).message });
    }
  }, ctx.config.staleCheckIntervalMs);
  t.unref();
  return () => clearInterval(t);
}
