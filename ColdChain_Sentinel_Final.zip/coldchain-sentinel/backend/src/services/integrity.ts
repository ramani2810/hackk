import { all, get, run, tx } from "../db/index";
import type { AppContext, Dataset } from "../context";
import { newId } from "../lib/crypto";
import { AppError } from "../lib/errors";
import { audit, type Actor } from "./audit";
import { FAILURE_TO_ALERT, raiseAlert, type Severity } from "./alerts";
import type { Checkpoint } from "./checkpoints";
import { countDeviceRecords, getTail, listDeviceRecords } from "./ledger";
import { type Failure, type VerifyOptions, statusForKinds, verifyChainRows, verifyLedger } from "./verifier";

interface RunRow {
  id: string; dataset: "LIVE" | "SANDBOX"; scope: "LEDGER" | "DEVICE" | "RANGE"; device_id: string | null; range_from: string | null;
  range_to: string | null; status: "VERIFIED" | "VERIFICATION_FAILED"; records_checked: number; devices_checked: number;
  checkpoints_checked: number; failures_json: string; notes_json: string; started_at: string; finished_at: string; triggered_by: string | null;
}

export function runDto(r: RunRow) {
  const failures = JSON.parse(r.failures_json) as Failure[];
  const counts: Record<string, number> = {};
  for (const f of failures) counts[f.kind] = (counts[f.kind] ?? 0) + 1;
  return {
    id: r.id, dataset: r.dataset, scope: r.scope, deviceId: r.device_id, rangeFrom: r.range_from, rangeTo: r.range_to,
    status: r.status, recordsChecked: r.records_checked, devicesChecked: r.devices_checked, checkpointsChecked: r.checkpoints_checked,
    failures, failureCounts: counts, notes: Array.from(new Set(JSON.parse(r.notes_json) as string[])),
    startedAt: r.started_at, finishedAt: r.finished_at, triggeredBy: r.triggered_by,
  };
}
export type RunDto = ReturnType<typeof runDto>;

const TITLES: Record<string, string> = {
  HASH_MISMATCH: "Hash mismatch: record contents were modified",
  BROKEN_LINK: "Broken hash link between records",
  MISSING_RECORD: "Missing record(s) detected in the ledger",
  SEQUENCE_GAP: "Unacknowledged sequence gap",
  REORDERED_RECORDS: "Ledger records are out of order",
  CHECKPOINT_MISMATCH: "Ledger does not match its signed checkpoint",
};
const SEVERITY: Record<string, Severity> = { SEQUENCE_GAP: "HIGH", REORDERED_RECORDS: "HIGH" };
const MAX_ALERTS_PER_RUN = 50;

/**
 * Runs the real verifier, stores the run + per-record results, and raises SECURITY alerts for failures.
 * Corrupted records are never repaired or rewritten.
 */
export function runVerification(ctx: AppContext, ds: Dataset, opts: VerifyOptions, actor: Actor, ip?: string | null): RunDto {
  const result = verifyLedger(ds.db, ds.checkpoints, ds.name, opts, ctx.now);
  const runId = newId("run_");
  tx(ds.db, () => {
    run(ds.db,
      `INSERT INTO verification_runs (id, dataset, scope, device_id, range_from, range_to, status, records_checked, devices_checked,
         checkpoints_checked, failures_json, notes_json, started_at, finished_at, triggered_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      runId, ds.name, result.scope, result.deviceId, result.rangeFrom, result.rangeTo, result.status, result.recordsChecked,
      result.devicesChecked, result.checkpointsChecked, JSON.stringify(result.failures), JSON.stringify(result.notes),
      result.startedAt, result.finishedAt, actor.label);
    const up = ds.db.prepare(
      `INSERT INTO record_integrity (record_id, status, kinds_json, run_id, verified_at) VALUES (?,?,?,?,?)
       ON CONFLICT(record_id) DO UPDATE SET status = excluded.status, kinds_json = excluded.kinds_json, run_id = excluded.run_id, verified_at = excluded.verified_at`);
    for (const id of result.checkedRecordIds) {
      const kinds = result.perRecord.get(id) ?? [];
      up.run(id, statusForKinds(kinds), JSON.stringify(kinds), runId, result.finishedAt);
    }
  });

  let n = 0;
  for (const f of result.failures) {
    if (n++ >= MAX_ALERTS_PER_RUN) break;
    const kind = FAILURE_TO_ALERT[f.kind];
    raiseAlert(ctx, {
      kind, severity: SEVERITY[kind] ?? "CRITICAL", title: TITLES[kind]!, description: f.message, scope: ds.name,
      deviceId: f.deviceId, recordId: f.recordId, at: result.finishedAt,
      dedupeKey: `integrity:${ds.name}:${kind}:${f.recordId ?? `${f.deviceId}:${f.sequence ?? "-"}:${f.message.slice(0, 40)}`}`,
      details: { runId, sequence: f.sequence, expected: f.expected ?? null, actual: f.actual ?? null, missingSequences: f.missingSequences ?? null },
    });
  }

  audit(ctx, {
    actor, action: "ledger.verify", targetType: "ledger", targetId: result.deviceId ?? "all", scope: ds.name, ip,
    details: { runId, scope: result.scope, status: result.status, recordsChecked: result.recordsChecked, failures: result.failures.length },
  });
  const dto = runDto(get<RunRow>(ds.db, "SELECT * FROM verification_runs WHERE id = ?", runId)!);
  ctx.bus.publish("verification:done", { ...dto, failures: undefined, failureSummary: dto.failureCounts });
  return dto;
}

export function listRuns(ds: Dataset, limit = 20) {
  return all<RunRow>(ds.db, "SELECT * FROM verification_runs WHERE dataset = ? ORDER BY finished_at DESC, rowid DESC LIMIT ?", ds.name, limit).map(runDto);
}
export function getRun(ds: Dataset, id: string) {
  const r = get<RunRow>(ds.db, "SELECT * FROM verification_runs WHERE id = ?", id);
  return r ? runDto(r) : undefined;
}
export function latestRun(ds: Dataset): RunDto | undefined {
  const r = get<RunRow>(ds.db, "SELECT * FROM verification_runs WHERE dataset = ? ORDER BY finished_at DESC, rowid DESC LIMIT 1", ds.name);
  return r ? runDto(r) : undefined;
}
export function latestSuccessfulRun(ds: Dataset): RunDto | undefined {
  const r = get<RunRow>(ds.db, "SELECT * FROM verification_runs WHERE dataset = ? AND status = 'VERIFIED' ORDER BY finished_at DESC, rowid DESC LIMIT 1", ds.name);
  return r ? runDto(r) : undefined;
}

/** Creates a signed checkpoint for a device, but only if the chain since the last checkpoint is intact. */
export function createCheckpointFor(ctx: AppContext, ds: Dataset, deviceId: string): Checkpoint {
  const head = getTail(ds.db, deviceId);
  if (!head) throw new AppError(409, "NO_RECORDS", "This device has no ledger records to checkpoint");
  const last = ds.checkpoints.latest(deviceId);
  const rows = listDeviceRecords(ds.db, deviceId);
  // Only the part of the chain after the last checkpoint needs re-checking (anchored at the checkpointed record).
  const anchorIdx = last ? rows.findIndex((r) => r.sequence === last.lastSequence) : -1;
  const check = verifyChainRows(deviceId, anchorIdx >= 0 ? rows.slice(anchorIdx) : rows, { anchored: anchorIdx >= 0 });
  if (check.failures.length > 0) {
    throw new AppError(409, "CHAIN_NOT_INTACT", "Refusing to checkpoint a ledger that fails verification. Run a full verification to see the failures.", { failures: check.failures.slice(0, 5) });
  }
  return ds.checkpoints.create(deviceId, head, countDeviceRecords(ds.db, deviceId), ctx.now());
}

/** Called after ingestion: creates a checkpoint every `checkpointEvery` records. Never throws. */
export function autoCheckpoint(ctx: AppContext, ds: Dataset, deviceId: string): Checkpoint | null {
  try {
    const last = ds.checkpoints.latest(deviceId);
    const since = get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM readings WHERE device_id = ? AND sequence > ?", deviceId, last?.lastSequence ?? 0)?.c ?? 0;
    if (since < ctx.config.checkpointEvery) return null;
    return createCheckpointFor(ctx, ds, deviceId);
  } catch (err) {
    ctx.log.warn("auto-checkpoint skipped", { deviceId, reason: (err as Error).message });
    return null;
  }
}
