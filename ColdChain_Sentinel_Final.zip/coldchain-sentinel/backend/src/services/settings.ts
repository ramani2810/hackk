import { type DB, all, run } from "../db/index";

export interface Settings {
  tempMinC: number;
  tempMaxC: number;
  staleSeconds: number;
  recoveryReadings: number;
  simulatorIntervalSec: number;
}

export const DEFAULT_SETTINGS: Settings = {
  tempMinC: 2,
  tempMaxC: 8,
  staleSeconds: 60,
  recoveryReadings: 2,
  simulatorIntervalSec: 3,
};

export function getSettings(db: DB): Settings {
  const rows = all<{ key: string; value: string }>(db, "SELECT key, value FROM settings");
  const out: Settings = { ...DEFAULT_SETTINGS };
  for (const r of rows) {
    if (r.key in out) {
      try {
        (out as unknown as Record<string, number>)[r.key] = JSON.parse(r.value) as number;
      } catch {
        /* ignore corrupt value, keep default */
      }
    }
  }
  return out;
}

export function updateSettings(db: DB, patch: Partial<Settings>): Settings {
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined || !(k in DEFAULT_SETTINGS)) continue;
    run(db, "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", k, JSON.stringify(v));
  }
  return getSettings(db);
}
