import { all, get, run } from "../db/index";
import { DUMMY_PASSWORD_HASH, hashPassword, newId, randomHex, sha256Hex, verifyPassword } from "../lib/crypto";
import { AppError, conflict, notFound } from "../lib/errors";
import type { AppContext } from "../context";

export type Role = "ADMIN" | "VIEWER";
export interface SessionUser { id: string; email: string; name: string; role: Role }

interface UserRow { id: string; email: string; name: string; role: Role; password_hash: string; disabled: number; created_at: string; last_login_at: string | null }

export const COOKIE_NAME = "cc_session";
export const MIN_PASSWORD_LENGTH = 10;

const userDto = (u: UserRow) => ({ id: u.id, email: u.email, name: u.name, role: u.role, disabled: !!u.disabled, createdAt: u.created_at, lastLoginAt: u.last_login_at });

export function createUser(ctx: AppContext, input: { email: string; name: string; role: Role; password: string }) {
  if (input.password.length < MIN_PASSWORD_LENGTH) throw new AppError(400, "WEAK_PASSWORD", `Password must be at least ${MIN_PASSWORD_LENGTH} characters`);
  const email = input.email.trim().toLowerCase();
  if (get(ctx.live.db, "SELECT 1 AS x FROM users WHERE email = ?", email)) throw conflict("USER_EXISTS", "A user with that e-mail already exists");
  const id = newId("usr_");
  run(ctx.live.db, "INSERT INTO users (id, email, name, role, password_hash, created_at) VALUES (?,?,?,?,?,?)", id, email, input.name.trim(), input.role, hashPassword(input.password), ctx.now());
  return userDto(get<UserRow>(ctx.live.db, "SELECT * FROM users WHERE id = ?", id)!);
}

export function listUsers(ctx: AppContext) {
  return all<UserRow>(ctx.live.db, "SELECT * FROM users ORDER BY created_at").map(userDto);
}

export function setUserDisabled(ctx: AppContext, id: string, disabled: boolean) {
  const u = get<UserRow>(ctx.live.db, "SELECT * FROM users WHERE id = ?", id);
  if (!u) throw notFound("User");
  if (disabled && u.role === "ADMIN") {
    const admins = get<{ c: number }>(ctx.live.db, "SELECT COUNT(*) AS c FROM users WHERE role = 'ADMIN' AND disabled = 0 AND id <> ?", id)!.c;
    if (admins === 0) throw new AppError(409, "LAST_ADMIN", "You cannot disable the last administrator");
  }
  run(ctx.live.db, "UPDATE users SET disabled = ? WHERE id = ?", disabled ? 1 : 0, id);
  if (disabled) run(ctx.live.db, "DELETE FROM sessions WHERE user_id = ?", id);
  return userDto(get<UserRow>(ctx.live.db, "SELECT * FROM users WHERE id = ?", id)!);
}

/** Constant-ish time login: a dummy hash is verified when the user does not exist. */
export function authenticate(ctx: AppContext, email: string, password: string): SessionUser | null {
  const u = get<UserRow>(ctx.live.db, "SELECT * FROM users WHERE email = ?", email.trim().toLowerCase());
  const ok = verifyPassword(password, u?.password_hash ?? DUMMY_PASSWORD_HASH);
  if (!u || !ok || u.disabled) return null;
  run(ctx.live.db, "UPDATE users SET last_login_at = ? WHERE id = ?", ctx.now(), u.id);
  return { id: u.id, email: u.email, name: u.name, role: u.role };
}

/** Opaque random session token; only its SHA-256 is stored in the database. */
export function createSession(ctx: AppContext, userId: string, ip: string | null, userAgent: string | null): { token: string; expiresAt: string } {
  const token = randomHex(32);
  const expiresAt = new Date(Date.now() + ctx.config.sessionTtlHours * 3600_000).toISOString();
  run(ctx.live.db, "INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?,?,?,?,?,?)", sha256Hex(token), userId, ctx.now(), expiresAt, ip, userAgent?.slice(0, 200) ?? null);
  return { token, expiresAt };
}

export function sessionUser(ctx: AppContext, token: string | undefined): SessionUser | null {
  if (!token || !/^[0-9a-f]{64}$/.test(token)) return null;
  const row = get<UserRow & { expires_at: string }>(ctx.live.db,
    "SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?", sha256Hex(token));
  if (!row || row.disabled) return null;
  if (Date.parse(row.expires_at) < Date.now()) {
    run(ctx.live.db, "DELETE FROM sessions WHERE id = ?", sha256Hex(token));
    return null;
  }
  return { id: row.id, email: row.email, name: row.name, role: row.role };
}

export function destroySession(ctx: AppContext, token: string | undefined) {
  if (token) run(ctx.live.db, "DELETE FROM sessions WHERE id = ?", sha256Hex(token));
}

export function purgeExpiredSessions(ctx: AppContext) {
  run(ctx.live.db, "DELETE FROM sessions WHERE expires_at < ?", ctx.now());
}
