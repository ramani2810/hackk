import { all, get, run, tx } from "../db/index";
import type { AppContext } from "../context";
import { AppError, notFound } from "../lib/errors";
import { computeRecordHash } from "../lib/crypto";
import { audit, type Actor } from "./audit";
import { alertDto, type AlertRow } from "./alerts";
import { type LedgerRecord, appendRecord, listDeviceRecords, rowToRecord, type ReadingRow } from "./ledger";
import { listReadings, readingDto } from "./readings";
import { createCheckpointFor, latestRun, runVerification } from "./integrity";
import { evaluateReading } from "./temperature";

/**
 * The tamper-demonstration sandbox.
 *
 * It lives in a SEPARATE SQLite file (data/sandbox.db) with its own checkpoint directory, so nothing done here can
 * touch the real ledger. The tamper operations deliberately bypass the ledger service with raw SQL — that is exactly
 * what an attacker with database access would do — and are then caught by the REAL verifier.
 * Every record has a fixed id and timestamp, so a reset restores byte-identical data (identical hashes).
 */
export const SANDBOX_DEVICE = "SANDBOX-DEMO-01";
const BASE_TIME = Date.parse("2026-01-15T08:00:00.000Z");
// 30 readings, one per minute. Records 18-20 are a GENUINE excursion (above 8 °C) — the chain must stay valid there.
const TEMPS = [
  4.1, 4.2, 4.2, 4.4, 4.5, 4.6, 4.8, 4.9, 5.0, 5.1,
  5.2, 5.1, 5.0, 4.9, 5.2, 5.6, 6.4, 8.6, 9.2, 8.4,
  7.1, 6.2, 5.6, 5.3, 5.1, 5.0, 4.8, 4.7, 4.6, 4.5,
];

function sandboxCtxDevice(ctx: AppContext) {
  const db = ctx.sandbox.db;
  if (!get(db, "SELECT 1 AS x FROM devices WHERE id = ?", SANDBOX_DEVICE)) {
    run(db, "INSERT INTO devices (id, name, type, description, created_at) VALUES (?,?,'SANDBOX',?,?)", SANDBOX_DEVICE, "Disposable tamper-demo device", "Isolated sandbox ledger. Not part of the real ledger.", ctx.now());
  }
}

export function resetSandbox(ctx: AppContext, actor: Actor, ip?: string | null) {
  const db = ctx.sandbox.db;
  sandboxCtxDevice(ctx);
  tx(db, () => {
    for (const t of ["record_integrity", "verification_runs", "checkpoints", "sandbox_originals", "readings"]) run(db, `DELETE FROM ${t}`);
    run(db, "UPDATE devices SET last_seen_at = NULL, last_temperature_c = NULL, last_sensor_status = NULL, last_reading_id = NULL, last_sequence = 0 WHERE id = ?", SANDBOX_DEVICE);
  });
  ctx.sandbox.checkpoints.deleteDevice(SANDBOX_DEVICE);
  run(ctx.live.db, "DELETE FROM alerts WHERE scope = 'SANDBOX'");

  TEMPS.forEach((t, i) => {
    const res = appendRecord(db, {
      id: `sbx-${String(i + 1).padStart(4, "0")}`, deviceId: SANDBOX_DEVICE, sequence: i + 1, temperatureC: t, humidityPct: null, sensorStatus: "OK",
      deviceTimestamp: new Date(BASE_TIME + i * 60_000).toISOString(), receivedAt: new Date(BASE_TIME + i * 60_000 + 250).toISOString(),
      source: "SANDBOX", firmwareVersion: "sandbox-1.0", shipmentId: null,
    });
    if (res.kind !== "created") throw new Error("sandbox seed failed: " + res.kind);
    evaluateReading(ctx, res.record, "SANDBOX"); // genuine excursion -> TEMPERATURE alert only
    run(db, "INSERT INTO sandbox_originals (record_id, snapshot_json) VALUES (?, ?)", res.record.id, JSON.stringify(snapshot(res.record)));
    if ((i + 1) % 10 === 0) createCheckpointFor(ctx, ctx.sandbox, SANDBOX_DEVICE);
  });
  audit(ctx, { actor, action: "sandbox.reset", targetType: "sandbox", targetId: SANDBOX_DEVICE, scope: "SANDBOX", ip, details: { records: TEMPS.length } });
  const run0 = runVerification(ctx, ctx.sandbox, { scope: "LEDGER" }, actor, ip);
  ctx.bus.publish("sandbox:updated", { action: "reset" });
  return { reset: true, verification: run0 };
}

const snapshot = (r: LedgerRecord) => ({ id: r.id, sequence: r.sequence, temperatureC: r.temperatureC, receivedAt: r.receivedAt, previousHash: r.previousHash, hash: r.hash, ledgerIndex: r.ledgerIndex });

export type TamperAction =
  | { action: "modify"; sequence: number; temperatureC: number }
  | { action: "delete"; sequence: number }
  | { action: "reorder"; sequence: number }
  | { action: "rewrite_chain"; sequence: number; temperatureC: number }
  | { action: "append"; count: number };

export function tamper(ctx: AppContext, t: TamperAction, actor: Actor, ip?: string | null) {
  const db = ctx.sandbox.db;
  sandboxCtxDevice(ctx);
  if (!get(db, "SELECT 1 AS x FROM readings LIMIT 1")) throw new AppError(409, "SANDBOX_EMPTY", "The sandbox is empty. Reset the sandbox first.");
  const row = (seq: number) => get<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? AND sequence = ?", SANDBOX_DEVICE, seq);
  let description = "";

  if (t.action === "append") {
    const last = get<{ s: number }>(db, "SELECT MAX(sequence) AS s FROM readings")!.s;
    for (let i = 1; i <= t.count; i++) {
      const seq = last + i;
      const res = appendRecord(db, {
        deviceId: SANDBOX_DEVICE, sequence: seq, temperatureC: 5 + ((seq * 7) % 10) / 10, humidityPct: null, sensorStatus: "OK",
        deviceTimestamp: new Date(BASE_TIME + (seq - 1) * 60_000).toISOString(), receivedAt: new Date(BASE_TIME + (seq - 1) * 60_000 + 250).toISOString(),
        source: "SANDBOX", firmwareVersion: "sandbox-1.0", shipmentId: null,
      });
      if (res.kind === "created") run(db, "INSERT INTO sandbox_originals (record_id, snapshot_json) VALUES (?, ?)", res.record.id, JSON.stringify(snapshot(res.record)));
    }
    description = `Appended ${t.count} legitimate record(s) through the normal ledger service (after the last signed checkpoint).`;
  } else {
    const target = row(t.sequence);
    if (!target) throw notFound(`Sandbox record #${t.sequence}`);
    if (t.action === "modify") {
      run(db, "UPDATE readings SET temperature_c = ? WHERE id = ?", t.temperatureC, target.id);
      description = `Raw SQL UPDATE changed record #${t.sequence} from ${target.temperature_c} °C to ${t.temperatureC} °C. Hashes were NOT recomputed (a naive edit).`;
    } else if (t.action === "delete") {
      run(db, "DELETE FROM readings WHERE id = ?", target.id);
      description = `Raw SQL DELETE removed record #${t.sequence}.`;
    } else if (t.action === "reorder") {
      const next = row(t.sequence + 1);
      if (!next) throw new AppError(400, "NO_NEXT", "There is no following record to swap with");
      tx(db, () => {
        run(db, "UPDATE readings SET ledger_index = -1 WHERE id = ?", target.id);
        run(db, "UPDATE readings SET ledger_index = ? WHERE id = ?", target.ledger_index, next.id);
        run(db, "UPDATE readings SET ledger_index = ? WHERE id = ?", next.ledger_index, target.id);
      });
      description = `Swapped the ledger positions of records #${t.sequence} and #${t.sequence + 1}.`;
    } else if (t.action === "rewrite_chain") {
      // The sophisticated attacker: edit the value AND recompute every hash from that record to the end.
      tx(db, () => {
        run(db, "UPDATE readings SET temperature_c = ? WHERE id = ?", t.temperatureC, target.id);
        const rows = all<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? AND sequence >= ? ORDER BY sequence", SANDBOX_DEVICE, t.sequence).map(rowToRecord);
        let prevHash = rows[0]!.previousHash;
        for (const r of rows) {
          const updated = { ...r, previousHash: prevHash };
          const hash = computeRecordHash(updated);
          run(db, "UPDATE readings SET previous_hash = ?, hash = ? WHERE id = ?", prevHash, hash, r.id);
          prevHash = hash;
        }
      });
      description = `Changed record #${t.sequence} to ${t.temperatureC} °C and RE-COMPUTED every following hash, so the hash chain looks internally consistent. Only the signed checkpoint (key held outside the database) can expose this.`;
    }
  }
  audit(ctx, { actor, action: `sandbox.tamper.${t.action}`, targetType: "sandbox", targetId: SANDBOX_DEVICE, scope: "SANDBOX", ip, details: { ...t } });
  ctx.bus.publish("sandbox:updated", { action: t.action });
  return { applied: true, description };
}

export function sandboxState(ctx: AppContext) {
  sandboxCtxDevice(ctx);
  const db = ctx.sandbox.db;
  const list = listReadings(ctx.sandbox, { order: "asc", page: 1, pageSize: 500 });
  const originals = new Map(all<{ record_id: string; snapshot_json: string }>(db, "SELECT * FROM sandbox_originals").map((r) => [r.record_id, JSON.parse(r.snapshot_json) as ReturnType<typeof snapshot>]));
  const present = new Set(list.items.map((i) => i.id));
  const items = list.items.map((r) => {
    const o = originals.get(r.id);
    return { ...r, original: o ? { temperatureC: o.temperatureC, hash: o.hash, previousHash: o.previousHash } : null, modified: !!o && (o.temperatureC !== r.temperatureC || o.hash !== r.hash || o.previousHash !== r.previousHash), temperatureChanged: !!o && o.temperatureC !== r.temperatureC };
  });
  const deleted = [...originals.entries()].filter(([id]) => !present.has(id)).map(([, o]) => o).sort((a, b) => a.sequence - b.sequence);
  const alerts = all<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE scope = 'SANDBOX' ORDER BY created_at DESC, rowid DESC").map((a) => alertDto(a));
  const orderIssue = items.some((r, i) => i > 0 && r.sequence < items[i - 1]!.sequence);
  return {
    deviceId: SANDBOX_DEVICE,
    isSandbox: true,
    notice: "This is an isolated, disposable ledger stored in a separate database file. The real ledger is never modified here.",
    records: items,
    deleted,
    orderChanged: orderIssue,
    checkpoints: ctx.sandbox.checkpoints.read(SANDBOX_DEVICE).checkpoints,
    lastVerification: latestRun(ctx.sandbox) ?? null,
    alerts: { temperature: alerts.filter((a) => a.category === "TEMPERATURE"), integrity: alerts.filter((a) => a.category === "SECURITY") },
    seeded: items.length > 0 || deleted.length > 0,
  };
}

export function verifySandbox(ctx: AppContext, actor: Actor, ip?: string | null) {
  const result = runVerification(ctx, ctx.sandbox, { scope: "LEDGER" }, actor, ip);
  ctx.bus.publish("sandbox:updated", { action: "verify" });
  return result;
}

export { readingDto };
