import { all, get, run } from "../db/index";
import { AppError, conflict, notFound } from "../lib/errors";
import type { AppContext } from "../context";
import { getSettings } from "./settings";
import { audit, type Actor } from "./audit";
import { getDeviceRow } from "./devices";

export interface ShipmentRow {
  id: string; name: string; product: string | null; origin: string | null; destination: string | null;
  status: "PLANNED" | "IN_TRANSIT" | "DELIVERED" | "CANCELLED"; device_id: string | null; min_temp_c: number; max_temp_c: number;
  created_at: string; created_by: string | null; started_at: string | null; ended_at: string | null;
}

export const SHIPMENT_ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{2,39}$/;

export function getShipmentRow(ctx: AppContext, id: string) {
  return get<ShipmentRow>(ctx.live.db, "SELECT * FROM shipments WHERE id = ?", id);
}

export function shipmentDto(ctx: AppContext, s: ShipmentRow) {
  const db = ctx.live.db;
  const stats = get<{ readings: number; first: string | null; last: string | null }>(db, "SELECT COUNT(*) AS readings, MIN(received_at) AS first, MAX(received_at) AS last FROM readings WHERE shipment_id = ?", s.id)!;
  const latest = get<{ temperature_c: number | null; received_at: string; sensor_status: string; source: string; id: string }>(db, "SELECT temperature_c, received_at, sensor_status, source, id FROM readings WHERE shipment_id = ? ORDER BY ledger_index DESC LIMIT 1", s.id);
  const excursions = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE shipment_id = ? AND kind = 'TEMP_EXCURSION' AND scope = 'LIVE'", s.id)?.c ?? 0;
  const openExcursions = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE shipment_id = ? AND kind = 'TEMP_EXCURSION' AND status = 'OPEN' AND scope = 'LIVE'", s.id)?.c ?? 0;
  const integrity = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE shipment_id = ? AND category = 'SECURITY' AND status = 'OPEN' AND scope = 'LIVE'", s.id)?.c ?? 0;
  const failing = get<{ c: number }>(db, `SELECT COUNT(*) AS c FROM readings r JOIN record_integrity i ON i.record_id = r.id WHERE r.shipment_id = ? AND i.status <> 'VERIFIED'`, s.id)?.c ?? 0;
  const verified = get<{ c: number }>(db, `SELECT COUNT(*) AS c FROM readings r JOIN record_integrity i ON i.record_id = r.id WHERE r.shipment_id = ? AND i.status = 'VERIFIED'`, s.id)?.c ?? 0;
  const dev = s.device_id ? getDeviceRow(ctx, s.device_id) : undefined;
  return {
    id: s.id, name: s.name, product: s.product, origin: s.origin, destination: s.destination, status: s.status,
    deviceId: s.device_id, deviceType: dev?.type ?? null, source: dev ? (dev.type === "ESP32" ? "HARDWARE" : "SIMULATOR") : null,
    minTempC: s.min_temp_c, maxTempC: s.max_temp_c, createdAt: s.created_at, startedAt: s.started_at, endedAt: s.ended_at,
    readingCount: stats.readings, firstReadingAt: stats.first, lastReadingAt: stats.last,
    currentReading: latest ? { id: latest.id, temperatureC: latest.temperature_c, receivedAt: latest.received_at, sensorStatus: latest.sensor_status, source: latest.source } : null,
    excursionCount: excursions, openExcursions, openIntegrityAlerts: integrity, failedRecords: failing, verifiedRecords: verified,
  };
}

export function listShipments(ctx: AppContext) {
  return all<ShipmentRow>(ctx.live.db, "SELECT * FROM shipments ORDER BY created_at DESC").map((s) => shipmentDto(ctx, s));
}

export interface CreateShipmentInput {
  id: string; name: string; product?: string | null; origin?: string | null; destination?: string | null;
  deviceId?: string | null; minTempC?: number; maxTempC?: number; status?: ShipmentRow["status"];
}

export function createShipment(ctx: AppContext, input: CreateShipmentInput, actor: Actor, ip?: string | null) {
  if (!SHIPMENT_ID_RE.test(input.id)) throw new AppError(400, "BAD_SHIPMENT_ID", "Shipment ID must be 3-40 characters: letters, digits, '-' or '_'");
  if (getShipmentRow(ctx, input.id)) throw conflict("SHIPMENT_EXISTS", `Shipment ${input.id} already exists`);
  const settings = getSettings(ctx.live.db);
  const min = input.minTempC ?? settings.tempMinC;
  const max = input.maxTempC ?? settings.tempMaxC;
  if (!(min < max)) throw new AppError(400, "BAD_RANGE", "Minimum temperature must be lower than maximum");
  if (input.deviceId) {
    const d = getDeviceRow(ctx, input.deviceId);
    if (!d) throw notFound("Device");
    if (d.type === "SANDBOX") throw new AppError(400, "BAD_DEVICE", "The sandbox device cannot be assigned to a shipment");
  }
  const status = input.status ?? (input.deviceId ? "IN_TRANSIT" : "PLANNED");
  const now = ctx.now();
  // A device can carry only one active shipment at a time.
  if (input.deviceId && status === "IN_TRANSIT") {
    const busy = get<{ id: string }>(ctx.live.db, "SELECT id FROM shipments WHERE device_id = ? AND status = 'IN_TRANSIT'", input.deviceId);
    if (busy) throw conflict("DEVICE_BUSY", `Device ${input.deviceId} is already assigned to in-transit shipment ${busy.id}`);
  }
  run(ctx.live.db, `INSERT INTO shipments (id, name, product, origin, destination, status, device_id, min_temp_c, max_temp_c, created_at, created_by, started_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, input.id, input.name, input.product ?? null, input.origin ?? null, input.destination ?? null, status,
    input.deviceId ?? null, min, max, now, actor.id, status === "IN_TRANSIT" ? now : null);
  audit(ctx, { actor, action: "shipment.create", targetType: "shipment", targetId: input.id, details: { deviceId: input.deviceId ?? null, minTempC: min, maxTempC: max }, ip });
  return shipmentDto(ctx, getShipmentRow(ctx, input.id)!);
}

export function updateShipment(ctx: AppContext, id: string, patch: { status?: ShipmentRow["status"]; deviceId?: string | null }, actor: Actor, ip?: string | null) {
  const s = getShipmentRow(ctx, id);
  if (!s) throw notFound("Shipment");
  const now = ctx.now();
  const status = patch.status ?? s.status;
  const deviceId = patch.deviceId === undefined ? s.device_id : patch.deviceId;
  if (deviceId) {
    const d = getDeviceRow(ctx, deviceId);
    if (!d) throw notFound("Device");
    if (d.type === "SANDBOX") throw new AppError(400, "BAD_DEVICE", "The sandbox device cannot be assigned to a shipment");
    if (status === "IN_TRANSIT") {
      const busy = get<{ id: string }>(ctx.live.db, "SELECT id FROM shipments WHERE device_id = ? AND status = 'IN_TRANSIT' AND id <> ?", deviceId, id);
      if (busy) throw conflict("DEVICE_BUSY", `Device ${deviceId} is already assigned to in-transit shipment ${busy.id}`);
    }
  }
  const startedAt = status === "IN_TRANSIT" && !s.started_at ? now : s.started_at;
  const endedAt = status === "DELIVERED" || status === "CANCELLED" ? (s.ended_at ?? now) : null;
  run(ctx.live.db, "UPDATE shipments SET status = ?, device_id = ?, started_at = ?, ended_at = ? WHERE id = ?", status, deviceId, startedAt, endedAt, id);
  audit(ctx, { actor, action: "shipment.update", targetType: "shipment", targetId: id, details: { status, deviceId }, ip });
  return shipmentDto(ctx, getShipmentRow(ctx, id)!);
}
