import { all, get, run, tx } from "../db/index";
import { decryptSecret, encryptSecret, hmacSha256Hex, newId, randomHex, sha256Hex, timingSafeEqualHex } from "../lib/crypto";
import { AppError, conflict, notFound } from "../lib/errors";
import type { AppContext } from "../context";
import { getSettings } from "./settings";
import { audit, type Actor } from "./audit";

export type DeviceType = "ESP32" | "SIMULATED" | "SANDBOX";

export interface DeviceRow {
  id: string; name: string; type: DeviceType; description: string | null; created_at: string; created_by: string | null;
  last_seen_at: string | null; last_temperature_c: number | null; last_sensor_status: string | null; last_reading_id: string | null;
  firmware_version: string | null; last_sequence: number;
}

interface CredRow {
  id: string; device_id: string; secret_enc: string; secret_fingerprint: string; status: "ACTIVE" | "REVOKED";
  created_at: string; revoked_at: string | null; revoked_by: string | null; last_used_at: string | null;
}

export const DEVICE_ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{2,39}$/;

export function getDeviceRow(ctx: AppContext, id: string): DeviceRow | undefined {
  return get<DeviceRow>(ctx.live.db, "SELECT * FROM devices WHERE id = ?", id);
}

export function deviceDto(ctx: AppContext, d: DeviceRow, staleSeconds = getSettings(ctx.live.db).staleSeconds, nowMs = Date.now()) {
  const cred = get<CredRow>(ctx.live.db, "SELECT * FROM device_credentials WHERE device_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 1", d.id);
  const ageSec = d.last_seen_at ? Math.max(0, Math.round((nowMs - Date.parse(d.last_seen_at)) / 1000)) : null;
  const connectivity = d.last_seen_at === null ? "NEVER_SEEN" : ageSec! <= staleSeconds ? "ONLINE" : "OFFLINE";
  const ship = get<{ id: string }>(ctx.live.db, "SELECT id FROM shipments WHERE device_id = ? AND status = 'IN_TRANSIT' ORDER BY started_at DESC LIMIT 1", d.id);
  const open = get<{ c: number }>(ctx.live.db, "SELECT COUNT(*) AS c FROM alerts WHERE device_id = ? AND status = 'OPEN' AND scope = 'LIVE'", d.id)?.c ?? 0;
  return {
    id: d.id, name: d.name, type: d.type, description: d.description, createdAt: d.created_at,
    source: d.type === "ESP32" ? "HARDWARE" : d.type === "SIMULATED" ? "SIMULATOR" : "SANDBOX",
    lastSeenAt: d.last_seen_at, secondsSinceLastSeen: ageSec, connectivity, online: connectivity === "ONLINE",
    latestTemperatureC: d.last_temperature_c, sensorHealth: d.last_sensor_status ?? "UNKNOWN",
    firmwareVersion: d.firmware_version, lastSequence: d.last_sequence, activeShipmentId: ship?.id ?? null, openAlerts: open,
    auth: d.type === "ESP32"
      ? { method: "HMAC-SHA256", status: cred ? cred.status : "NONE", fingerprint: cred?.secret_fingerprint ?? null, issuedAt: cred?.created_at ?? null, revokedAt: cred?.revoked_at ?? null, lastUsedAt: cred?.last_used_at ?? null }
      : { method: "INTERNAL", status: "NONE", fingerprint: null, issuedAt: null, revokedAt: null, lastUsedAt: null },
  };
}
export type DeviceDto = ReturnType<typeof deviceDto>;

export function listDevices(ctx: AppContext, opts: { includeSandbox?: boolean } = {}): DeviceDto[] {
  const settings = getSettings(ctx.live.db);
  const rows = all<DeviceRow>(ctx.live.db, "SELECT * FROM devices ORDER BY type = 'ESP32' DESC, id ASC");
  const nowMs = Date.now();
  return rows.filter((d) => opts.includeSandbox || d.type !== "SANDBOX").map((d) => deviceDto(ctx, d, settings.staleSeconds, nowMs));
}

function newSecret() {
  const secret = randomHex(32);
  return { secret, fingerprint: sha256Hex(secret).slice(0, 12) };
}

export interface CreateDeviceInput { id: string; name: string; type: DeviceType; description?: string | null }

/** Registers a device. For ESP32 devices a random HMAC secret is generated and returned ONCE. */
export function createDevice(ctx: AppContext, input: CreateDeviceInput, actor: Actor, ip?: string | null) {
  if (!DEVICE_ID_RE.test(input.id)) throw new AppError(400, "BAD_DEVICE_ID", "Device ID must be 3-40 characters: letters, digits, '-' or '_'");
  if (getDeviceRow(ctx, input.id)) throw conflict("DEVICE_EXISTS", `Device ${input.id} already exists`);
  const now = ctx.now();
  let secret: string | null = null;
  tx(ctx.live.db, () => {
    run(ctx.live.db, "INSERT INTO devices (id, name, type, description, created_at, created_by) VALUES (?,?,?,?,?,?)", input.id, input.name, input.type, input.description ?? null, now, actor.id);
    if (input.type === "ESP32") {
      const s = newSecret();
      secret = s.secret;
      run(ctx.live.db, "INSERT INTO device_credentials (id, device_id, secret_enc, secret_fingerprint, status, created_at) VALUES (?,?,?,?,'ACTIVE',?)",
        newId("cred_"), input.id, encryptSecret(ctx.config.deviceSecretKey, s.secret), s.fingerprint, now);
    }
  });
  audit(ctx, { actor, action: "device.register", targetType: "device", targetId: input.id, details: { type: input.type, name: input.name }, ip });
  const dto = deviceDto(ctx, getDeviceRow(ctx, input.id)!);
  ctx.bus.publish("device:updated", dto);
  return { device: dto, secret };
}

export function revokeCredential(ctx: AppContext, deviceId: string, actor: Actor, ip?: string | null) {
  const dev = getDeviceRow(ctx, deviceId);
  if (!dev) throw notFound("Device");
  if (dev.type !== "ESP32") throw new AppError(400, "NO_CREDENTIAL", "Only ESP32 devices have credentials");
  const res = run(ctx.live.db, "UPDATE device_credentials SET status = 'REVOKED', revoked_at = ?, revoked_by = ? WHERE device_id = ? AND status = 'ACTIVE'", ctx.now(), actor.label, deviceId);
  if (res.changes === 0) throw conflict("NOT_ACTIVE", "Device has no active credential");
  audit(ctx, { actor, action: "device.credential_revoked", targetType: "device", targetId: deviceId, ip });
  const dto = deviceDto(ctx, getDeviceRow(ctx, deviceId)!);
  ctx.bus.publish("device:updated", dto);
  return dto;
}

export function rotateCredential(ctx: AppContext, deviceId: string, actor: Actor, ip?: string | null) {
  const dev = getDeviceRow(ctx, deviceId);
  if (!dev) throw notFound("Device");
  if (dev.type !== "ESP32") throw new AppError(400, "NO_CREDENTIAL", "Only ESP32 devices have credentials");
  const s = newSecret();
  const now = ctx.now();
  tx(ctx.live.db, () => {
    run(ctx.live.db, "UPDATE device_credentials SET status = 'REVOKED', revoked_at = ?, revoked_by = ? WHERE device_id = ? AND status = 'ACTIVE'", now, actor.label, deviceId);
    run(ctx.live.db, "INSERT INTO device_credentials (id, device_id, secret_enc, secret_fingerprint, status, created_at) VALUES (?,?,?,?,'ACTIVE',?)",
      newId("cred_"), deviceId, encryptSecret(ctx.config.deviceSecretKey, s.secret), s.fingerprint, now);
  });
  audit(ctx, { actor, action: "device.credential_rotated", targetType: "device", targetId: deviceId, ip });
  const dto = deviceDto(ctx, getDeviceRow(ctx, deviceId)!);
  ctx.bus.publish("device:updated", dto);
  return { device: dto, secret: s.secret };
}

export type AuthFailureReason = "UNKNOWN_DEVICE" | "NO_CREDENTIAL" | "REVOKED" | "BAD_SIGNATURE";

/**
 * Verifies HMAC-SHA-256(secret, rawBody) against the X-Signature header.
 * The server needs the secret itself to recompute the HMAC, so it is stored AES-256-GCM-encrypted
 * under DEVICE_SECRET_ENC_KEY (never in plaintext, never returned by any API after creation).
 */
export function authenticateDevice(ctx: AppContext, deviceId: string, rawBody: Buffer, signature: string):
  { ok: true; device: DeviceRow } | { ok: false; reason: AuthFailureReason } {
  const device = getDeviceRow(ctx, deviceId);
  if (!device || device.type !== "ESP32") return { ok: false, reason: "UNKNOWN_DEVICE" };
  const cred = get<CredRow>(ctx.live.db, "SELECT * FROM device_credentials WHERE device_id = ? AND status = 'ACTIVE'", deviceId);
  if (!cred) {
    const any = get<CredRow>(ctx.live.db, "SELECT * FROM device_credentials WHERE device_id = ?", deviceId);
    return { ok: false, reason: any ? "REVOKED" : "NO_CREDENTIAL" };
  }
  let secret: string;
  try {
    secret = decryptSecret(ctx.config.deviceSecretKey, cred.secret_enc);
  } catch {
    return { ok: false, reason: "NO_CREDENTIAL" };
  }
  const expected = hmacSha256Hex(secret, rawBody);
  if (!/^[0-9a-fA-F]{64}$/.test(signature) || !timingSafeEqualHex(expected, signature.toLowerCase())) return { ok: false, reason: "BAD_SIGNATURE" };
  run(ctx.live.db, "UPDATE device_credentials SET last_used_at = ? WHERE id = ?", ctx.now(), cred.id);
  return { ok: true, device };
}

export function ensureSimulatedDevices(ctx: AppContext): void {
  const defs = [
    { id: "SIM-COLD-01", name: "Simulated Vaccine Box 01" },
    { id: "SIM-COLD-02", name: "Simulated Insulin Cooler 02" },
    { id: "SIM-COLD-03", name: "Simulated Biologics Crate 03" },
  ];
  for (const d of defs) {
    if (!getDeviceRow(ctx, d.id)) {
      run(ctx.live.db, "INSERT INTO devices (id, name, type, description, created_at) VALUES (?,?,'SIMULATED',?,?)", d.id, d.name, "Software-simulated device. Readings are NOT from physical hardware.", ctx.now());
    }
  }
}
