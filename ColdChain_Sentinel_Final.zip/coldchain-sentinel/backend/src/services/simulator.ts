import { all, get, run, tx } from "../db/index";
import type { AppContext } from "../context";
import { audit, SYSTEM_ACTOR, type Actor } from "./audit";
import { ensureSimulatedDevices, getDeviceRow } from "./devices";
import { ingestReading } from "./ingest";

type Phase = "NORMAL" | "EXCURSION" | "RECOVERY" | "DISCONNECTED";

interface DevSim {
  phase: Phase;
  temperatureC: number;
  ticksLeft: number;
  targetC: number;
}

export interface SimulatorState {
  running: boolean;
  intervalSec: number;
  deviceIds: string[];
  randomEvents: boolean;
  tickCount: number;
  startedAt: string | null;
  devices: Record<string, { phase: Phase; temperatureC: number }>;
  note: string;
}

const BASELINE_C = 5;

/**
 * Software simulator. It produces readings for SIMULATED devices and pushes them through the very same
 * `ingestReading` service as the HTTP endpoint (validation -> hash chain -> alerts -> checkpoints -> live events).
 * Every record it creates is labelled source = SIMULATOR; it can never be mistaken for hardware telemetry.
 */
export class Simulator {
  private timer: NodeJS.Timeout | null = null;
  private running = false;
  private intervalSec: number;
  private deviceIds: string[] = [];
  private randomEvents = true;
  private tickCount = 0;
  private startedAt: string | null = null;
  private sims = new Map<string, DevSim>();

  constructor(private ctx: AppContext, private rng: () => number = Math.random) {
    this.intervalSec = 3;
  }

  private gauss(): number {
    let u = 0;
    let v = 0;
    while (u === 0) u = this.rng();
    while (v === 0) v = this.rng();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  simulatedDeviceIds(): string[] {
    return all<{ id: string }>(this.ctx.live.db, "SELECT id FROM devices WHERE type = 'SIMULATED' ORDER BY id").map((r) => r.id);
  }

  state(): SimulatorState {
    const devices: SimulatorState["devices"] = {};
    for (const [id, s] of this.sims) devices[id] = { phase: s.phase, temperatureC: Math.round(s.temperatureC * 100) / 100 };
    return {
      running: this.running, intervalSec: this.intervalSec, deviceIds: this.running || this.deviceIds.length ? this.deviceIds : this.simulatedDeviceIds(),
      randomEvents: this.randomEvents, tickCount: this.tickCount, startedAt: this.startedAt, devices,
      note: "Simulated readings are labelled SIMULATOR and are not physical hardware telemetry.",
    };
  }

  configure(cfg: { intervalSec?: number; deviceIds?: string[]; randomEvents?: boolean }) {
    if (cfg.intervalSec !== undefined) this.intervalSec = Math.min(60, Math.max(1, cfg.intervalSec));
    if (cfg.randomEvents !== undefined) this.randomEvents = cfg.randomEvents;
    if (cfg.deviceIds) {
      const valid = new Set(this.simulatedDeviceIds());
      this.deviceIds = cfg.deviceIds.filter((d) => valid.has(d));
    }
    if (this.running) this.schedule();
    this.ctx.bus.publish("simulator:state", this.state());
  }

  start(cfg: { intervalSec?: number; deviceIds?: string[]; randomEvents?: boolean } = {}) {
    ensureSimulatedDevices(this.ctx);
    if (!cfg.deviceIds && this.deviceIds.length === 0) cfg.deviceIds = this.simulatedDeviceIds();
    this.configure(cfg);
    if (this.deviceIds.length === 0) this.deviceIds = this.simulatedDeviceIds();
    this.running = true;
    this.startedAt = this.ctx.now();
    this.schedule();
    this.tickOnce();
    this.ctx.bus.publish("simulator:state", this.state());
  }

  stop() {
    this.running = false;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.ctx.bus.publish("simulator:state", this.state());
  }

  private schedule() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (!this.running) return;
      this.tickOnce();
      this.schedule();
    }, this.intervalSec * 1000);
    this.timer.unref();
  }

  private simFor(id: string): DevSim {
    let s = this.sims.get(id);
    if (!s) {
      const last = getDeviceRow(this.ctx, id)?.last_temperature_c;
      s = { phase: "NORMAL", temperatureC: last ?? BASELINE_C + (this.rng() - 0.5), ticksLeft: 0, targetC: BASELINE_C };
      this.sims.set(id, s);
    }
    return s;
  }

  triggerExcursion(deviceId: string, opts: { peakC?: number; readings?: number } = {}) {
    const dev = getDeviceRow(this.ctx, deviceId);
    if (!dev || dev.type !== "SIMULATED") throw new Error("Not a simulated device");
    const s = this.simFor(deviceId);
    s.phase = "EXCURSION";
    s.ticksLeft = Math.max(2, Math.min(30, opts.readings ?? 6));
    s.targetC = Math.min(40, Math.max(8.5, opts.peakC ?? 10));
    this.ctx.bus.publish("simulator:state", this.state());
  }

  triggerDisconnect(deviceId: string, readings = 3) {
    const dev = getDeviceRow(this.ctx, deviceId);
    if (!dev || dev.type !== "SIMULATED") throw new Error("Not a simulated device");
    const s = this.simFor(deviceId);
    s.phase = "DISCONNECTED";
    s.ticksLeft = Math.max(1, Math.min(20, readings));
    this.ctx.bus.publish("simulator:state", this.state());
  }

  /** Produces one reading per selected device. Public so tests can drive the simulator deterministically. */
  tickOnce(deviceIds: string[] = this.deviceIds.length ? this.deviceIds : this.simulatedDeviceIds()) {
    this.tickCount++;
    for (const id of deviceIds) {
      try {
        this.step(id);
      } catch (err) {
        this.ctx.log.warn("simulator tick failed", { deviceId: id, error: (err as Error).message });
      }
    }
    if (this.running) this.ctx.bus.publish("simulator:state", this.state());
  }

  private step(id: string) {
    const dev = getDeviceRow(this.ctx, id);
    if (!dev || dev.type !== "SIMULATED") return;
    const s = this.simFor(id);
    let status: "OK" | "DISCONNECTED" = "OK";

    switch (s.phase) {
      case "NORMAL":
        s.temperatureC += (BASELINE_C - s.temperatureC) * 0.15 + this.gauss() * 0.1;
        s.temperatureC = Math.min(6.8, Math.max(3.2, s.temperatureC));
        if (this.randomEvents && this.rng() < 0.012) { s.phase = "EXCURSION"; s.ticksLeft = 4 + Math.floor(this.rng() * 5); s.targetC = 9 + this.rng() * 2; }
        else if (this.randomEvents && this.rng() < 0.006) { s.phase = "DISCONNECTED"; s.ticksLeft = 3 + Math.floor(this.rng() * 3); }
        break;
      case "EXCURSION":
        s.temperatureC += (s.targetC - s.temperatureC) * 0.5 + this.gauss() * 0.08;
        if (--s.ticksLeft <= 0) s.phase = "RECOVERY";
        break;
      case "RECOVERY":
        s.temperatureC += (BASELINE_C - s.temperatureC) * 0.5 + this.gauss() * 0.06;
        if (Math.abs(s.temperatureC - BASELINE_C) < 1.4) s.phase = "NORMAL";
        break;
      case "DISCONNECTED":
        status = "DISCONNECTED";
        if (--s.ticksLeft <= 0) s.phase = "NORMAL";
        break;
    }

    ingestReading(this.ctx, dev, {
      deviceId: id,
      sequence: dev.last_sequence + 1,
      temperatureC: status === "OK" ? Math.round(s.temperatureC * 1000) / 1000 : null,
      sensorStatus: status,
      recordedAt: this.ctx.now(),
      firmwareVersion: "sim-1.0.0",
    });
  }
}

/**
 * Removes ONLY simulated devices' demo data (readings, integrity marks, checkpoints, their alerts).
 * Physical-hardware records are never touched. Admin-only, dev-only, explicit confirm, always audited.
 */
export function resetDemoData(ctx: AppContext, actor: Actor = SYSTEM_ACTOR, ip?: string | null) {
  const wasRunning = ctx.simulator.state().running;
  ctx.simulator.stop();
  const ids = all<{ id: string }>(ctx.live.db, "SELECT id FROM devices WHERE type = 'SIMULATED'").map((r) => r.id);
  let removed = 0;
  tx(ctx.live.db, () => {
    for (const id of ids) {
      removed += get<{ c: number }>(ctx.live.db, "SELECT COUNT(*) AS c FROM readings WHERE device_id = ?", id)!.c;
      run(ctx.live.db, "DELETE FROM record_integrity WHERE record_id IN (SELECT id FROM readings WHERE device_id = ?)", id);
      run(ctx.live.db, "DELETE FROM readings WHERE device_id = ?", id);
      run(ctx.live.db, "DELETE FROM alerts WHERE device_id = ? AND scope = 'LIVE'", id);
      run(ctx.live.db, "UPDATE devices SET last_seen_at = NULL, last_temperature_c = NULL, last_sensor_status = NULL, last_reading_id = NULL, last_sequence = 0, firmware_version = NULL WHERE id = ?", id);
      ctx.live.checkpoints.deleteDevice(id);
    }
    if ((get<{ c: number }>(ctx.live.db, "SELECT COUNT(*) AS c FROM readings")?.c ?? 0) === 0) {
      run(ctx.live.db, "DELETE FROM verification_runs WHERE dataset = 'LIVE'");
    }
  });
  audit(ctx, { actor, action: "demo.reset", targetType: "simulator", details: { devices: ids, recordsRemoved: removed, simulatorWasRunning: wasRunning }, ip });
  ctx.bus.publish("simulator:state", ctx.simulator.state());
  return { devices: ids, recordsRemoved: removed };
}
