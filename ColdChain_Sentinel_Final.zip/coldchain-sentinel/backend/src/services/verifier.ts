import { type DB, all, get } from "../db/index";
import { computeRecordHash, genesisHash } from "../lib/crypto";
import type { LedgerRecord } from "./ledger";
import { listDeviceRecords, round3, round1 } from "./ledger";
import type { CheckpointStore } from "./checkpoints";

export type FailureKind =
  | "INVALID_HASH"
  | "BROKEN_LINK"
  | "MISSING_RECORD"
  | "SEQUENCE_GAP"
  | "REORDERED"
  | "CHECKPOINT_MISMATCH";

export const FAILURE_PRIORITY: FailureKind[] = [
  "INVALID_HASH",
  "BROKEN_LINK",
  "REORDERED",
  "MISSING_RECORD",
  "SEQUENCE_GAP",
  "CHECKPOINT_MISMATCH",
];

export interface Failure {
  kind: FailureKind;
  deviceId: string;
  recordId: string | null;
  sequence: number | null;
  message: string;
  expected?: string | null;
  actual?: string | null;
  missingSequences?: [number, number];
}

export interface ChainCheck {
  failures: Failure[];
  notes: string[];
  checked: number;
  perRecord: Map<string, FailureKind[]>;
  computedHashes: Map<string, string>;
}

function addFailure(res: ChainCheck, f: Failure) {
  res.failures.push(f);
  if (f.recordId) {
    const arr = res.perRecord.get(f.recordId) ?? [];
    if (!arr.includes(f.kind)) arr.push(f.kind);
    res.perRecord.set(f.recordId, arr);
  }
}

const short = (h: string) => h.slice(0, 12) + "…";

/**
 * Pure verification of one device chain. `rows` must be in insertion (ledger_index) order.
 * If `anchored` is true the first row is an anchor taken from just BEFORE a verified range: its own hash
 * is checked but it is not required to link to genesis.
 *
 * For every row the verifier RECOMPUTES the hash from the stored fields (it never trusts the stored hash),
 * and checks the link against the RECOMPUTED hash of the previous row.
 */
export function verifyChainRows(deviceId: string, rows: LedgerRecord[], opts: { anchored?: boolean } = {}): ChainCheck {
  const res: ChainCheck = { failures: [], notes: [], checked: 0, perRecord: new Map(), computedHashes: new Map() };
  let prev: LedgerRecord | undefined;
  let prevComputed: string | undefined;

  rows.forEach((row, i) => {
    res.checked++;
    const isAnchor = !!opts.anchored && i === 0;
    const calc = computeRecordHash(row);
    res.computedHashes.set(row.id, calc);

    // Non-canonical stored numbers (e.g. 4.2004 where 3 decimals are the contract) are treated as tampering.
    const nonCanonical =
      (row.temperatureC !== null && round3(row.temperatureC) !== row.temperatureC) ||
      (row.humidityPct !== null && round1(row.humidityPct) !== row.humidityPct);

    if (calc !== row.hash || nonCanonical) {
      addFailure(res, {
        kind: "INVALID_HASH", deviceId, recordId: row.id, sequence: row.sequence,
        message: nonCanonical
          ? `Record #${row.sequence} contains a value that is not in canonical form`
          : `Record #${row.sequence}: stored hash does not match the hash recomputed from its contents (the record was modified)`,
        expected: calc, actual: row.hash,
      });
    }

    if (!isAnchor) {
      const expectedPrev = prev ? prevComputed! : genesisHash(deviceId);
      const linkOk = row.previousHash === expectedPrev;
      if (!linkOk) {
        addFailure(res, {
          kind: "BROKEN_LINK", deviceId, recordId: row.id, sequence: row.sequence,
          message: prev
            ? `Record #${row.sequence}: previous-hash link does not match the recomputed hash of record #${prev.sequence}`
            : `Record #${row.sequence}: first record does not link to the genesis value (earlier records were removed or altered)`,
          expected: expectedPrev, actual: row.previousHash,
        });
      }
      if (prev) {
        if (row.sequence <= prev.sequence) {
          addFailure(res, {
            kind: "REORDERED", deviceId, recordId: row.id, sequence: row.sequence,
            message: `Record #${row.sequence} appears after record #${prev.sequence} in ledger order (records were reordered or duplicated)`,
          });
        } else {
          const actualGap = row.sequence - prev.sequence - 1;
          if (actualGap !== row.gapBefore) {
            const missing: [number, number] = [prev.sequence + 1 + row.gapBefore, row.sequence - 1];
            const unaccounted = actualGap - row.gapBefore;
            addFailure(res, {
              kind: !linkOk ? "MISSING_RECORD" : "SEQUENCE_GAP",
              deviceId, recordId: row.id, sequence: row.sequence,
              message: `${unaccounted} record(s) missing between #${prev.sequence} and #${row.sequence}` + (linkOk ? " (hash link is intact, but the gap was not acknowledged at ingestion)" : ""),
              missingSequences: missing[0] <= missing[1] ? missing : [prev.sequence + 1, row.sequence - 1],
            });
          } else if (actualGap > 0) {
            res.notes.push(`Device ${deviceId}: ${actualGap} sequence number(s) skipped before #${row.sequence}; the gap was recorded when the reading was accepted (device buffer loss or dropped delivery), not tampering.`);
          }
        }
      }
    }
    prev = row;
    prevComputed = calc;
  });
  return res;
}

export interface VerifyOptions {
  scope: "LEDGER" | "DEVICE" | "RANGE";
  deviceId?: string;
  from?: string;
  to?: string;
}

export interface VerificationResult {
  dataset: "LIVE" | "SANDBOX";
  scope: VerifyOptions["scope"];
  deviceId: string | null;
  rangeFrom: string | null;
  rangeTo: string | null;
  status: "VERIFIED" | "VERIFICATION_FAILED";
  recordsChecked: number;
  devicesChecked: number;
  checkpointsChecked: number;
  failures: Failure[];
  notes: string[];
  perRecord: Map<string, FailureKind[]>;
  checkedRecordIds: string[];
  startedAt: string;
  finishedAt: string;
}

export function discoverDeviceIds(db: DB, checkpoints: CheckpointStore): string[] {
  const ids = new Set<string>();
  for (const r of all<{ device_id: string }>(db, "SELECT DISTINCT device_id FROM readings")) ids.add(r.device_id);
  for (const r of all<{ device_id: string }>(db, "SELECT DISTINCT device_id FROM checkpoints")) ids.add(r.device_id);
  for (const r of all<{ id: string }>(db, "SELECT id FROM devices WHERE last_sequence > 0")) ids.add(r.id);
  for (const id of checkpoints.deviceIdsOnDisk()) ids.add(id);
  return [...ids].sort();
}

/**
 * Real verification: recompute every hash, check every link, sequence and signed checkpoint.
 * Does NOT write anything; persistence/alerting is done by the caller (verification service).
 */
export function verifyLedger(
  db: DB,
  checkpoints: CheckpointStore,
  dataset: "LIVE" | "SANDBOX",
  opts: VerifyOptions,
  now: () => string = () => new Date().toISOString(),
): VerificationResult {
  const startedAt = now();
  const deviceIds = opts.scope === "LEDGER" || (opts.scope === "RANGE" && !opts.deviceId)
    ? discoverDeviceIds(db, checkpoints)
    : [opts.deviceId!];
  const result: VerificationResult = {
    dataset, scope: opts.scope, deviceId: opts.deviceId ?? null, rangeFrom: opts.from ?? null, rangeTo: opts.to ?? null,
    status: "VERIFIED", recordsChecked: 0, devicesChecked: 0, checkpointsChecked: 0,
    failures: [], notes: [], perRecord: new Map(), checkedRecordIds: [], startedAt, finishedAt: startedAt,
  };

  for (const deviceId of deviceIds) {
    const all_ = listDeviceRecords(db, deviceId);
    let rows = all_;
    let anchored = false;
    const fullCoverage = opts.scope !== "RANGE";

    if (opts.scope === "RANGE") {
      const inRange = (r: LedgerRecord) =>
        (!opts.from || r.receivedAt >= opts.from) && (!opts.to || r.receivedAt <= opts.to);
      const idx = all_.map((r, i) => (inRange(r) ? i : -1)).filter((i) => i >= 0);
      if (idx.length === 0) continue;
      const start = idx[0]!;
      const end = idx[idx.length - 1]!;
      anchored = start > 0;
      rows = all_.slice(anchored ? start - 1 : 0, end + 1);
    }
    result.devicesChecked++;

    const chain = verifyChainRows(deviceId, rows, { anchored });
    result.recordsChecked += anchored ? chain.checked - 1 : chain.checked;
    result.failures.push(...chain.failures);
    result.notes.push(...chain.notes);
    for (const [id, kinds] of chain.perRecord) result.perRecord.set(id, [...(result.perRecord.get(id) ?? []), ...kinds]);
    rows.forEach((r, i) => {
      if (!(anchored && i === 0)) result.checkedRecordIds.push(r.id);
    });

    // --- registry cross-check (live DB only: the devices table remembers the highest accepted sequence) ---
    if (fullCoverage) {
      const dev = get<{ last_sequence: number }>(db, "SELECT last_sequence FROM devices WHERE id = ?", deviceId);
      const tailSeq = all_.reduce((m, r) => Math.max(m, r.sequence), 0);
      if (dev && dev.last_sequence > tailSeq) {
        result.failures.push({
          kind: "MISSING_RECORD", deviceId, recordId: all_[all_.length - 1]?.id ?? null, sequence: tailSeq || null,
          message: `Device registry says sequence #${dev.last_sequence} was accepted, but the ledger ends at #${tailSeq}: the newest record(s) were removed`,
          missingSequences: [tailSeq + 1, dev.last_sequence],
        });
      }
    }

    // --- signed checkpoints ---
    const file = checkpoints.read(deviceId);
    const dbCopies = checkpoints.dbCopies(deviceId);
    for (const p of file.problems) {
      result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: null, message: p.message });
    }
    if (fullCoverage) {
      const fileIds = new Set(file.checkpoints.map((c) => c.id));
      if (!file.exists && dbCopies.length > 0) {
        result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: null, message: `The trusted checkpoint file for ${deviceId} is missing although ${dbCopies.length} checkpoint(s) are known to the database` });
      }
      for (const c of dbCopies) {
        if (file.exists && !fileIds.has(c.id) && file.problems.length === 0) {
          result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: c.lastSequence, message: `Checkpoint ${c.id} (up to #${c.lastSequence}) is in the database but missing from the trusted checkpoint file (file truncated or edited)` });
        }
      }
      for (const c of file.checkpoints) {
        const copy = dbCopies.find((d) => d.id === c.id);
        if (!copy) {
          result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: c.lastSequence, message: `Checkpoint ${c.id} is in the trusted file but missing from the database copy` });
        } else if (copy.headHash !== c.headHash || copy.recordCount !== c.recordCount || copy.lastSequence !== c.lastSequence || copy.signature !== c.signature) {
          result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: c.lastSequence, message: `Database copy of checkpoint ${c.id} differs from the trusted file` });
        }
      }
    }
    const loadedMin = rows[anchored ? 1 : 0]?.sequence ?? Infinity;
    const loadedMax = rows[rows.length - 1]?.sequence ?? -Infinity;
    for (const c of file.checkpoints) {
      const inScope = fullCoverage || (c.lastSequence >= loadedMin && c.lastSequence <= loadedMax);
      if (!inScope) continue;
      result.checkpointsChecked++;
      const rec = rows.find((r) => r.sequence === c.lastSequence);
      if (!rec) {
        result.failures.push({ kind: "CHECKPOINT_MISMATCH", deviceId, recordId: null, sequence: c.lastSequence, message: `Checkpoint ${c.id} expects record #${c.lastSequence}, which is missing from the ledger` });
        continue;
      }
      const recomputed = chain.computedHashes.get(rec.id) ?? computeRecordHash(rec);
      if (recomputed !== c.headHash) {
        const f: Failure = {
          kind: "CHECKPOINT_MISMATCH", deviceId, recordId: rec.id, sequence: rec.sequence,
          message: `Record #${rec.sequence} no longer matches the signed checkpoint ${c.id} (head ${short(c.headHash)}). The history before this checkpoint was changed — even if the chain was re-hashed to look consistent.`,
          expected: c.headHash, actual: recomputed,
        };
        result.failures.push(f);
        const arr = result.perRecord.get(rec.id) ?? [];
        if (!arr.includes("CHECKPOINT_MISMATCH")) arr.push("CHECKPOINT_MISMATCH");
        result.perRecord.set(rec.id, arr);
      }
      if (fullCoverage) {
        const count = all_.filter((r) => r.sequence <= c.lastSequence).length;
        if (count !== c.recordCount) {
          result.failures.push({
            kind: "CHECKPOINT_MISMATCH", deviceId, recordId: rec.id, sequence: rec.sequence,
            message: `Checkpoint ${c.id} recorded ${c.recordCount} records up to #${c.lastSequence}, but the ledger now has ${count}`,
            expected: String(c.recordCount), actual: String(count),
          });
        }
      }
    }
  }

  result.status = result.failures.length === 0 ? "VERIFIED" : "VERIFICATION_FAILED";
  result.finishedAt = now();
  return result;
}

export function statusForKinds(kinds: FailureKind[]): FailureKind | "VERIFIED" {
  for (const k of FAILURE_PRIORITY) if (kinds.includes(k)) return k;
  return "VERIFIED";
}
