import { all, get } from "../db/index";
import type { Dataset } from "../context";
import { canonicalRecord, computeRecordHash } from "../lib/crypto";
import { type LedgerRecord, type ReadingRow, rowToRecord } from "./ledger";

export interface IntegrityInfo {
  status: string; // VERIFIED | failure kind | UNVERIFIED
  kinds: string[];
  verifiedAt: string | null;
  runId: string | null;
}

export function readingDto(rec: LedgerRecord, integrity?: IntegrityInfo | null) {
  return {
    id: rec.id, ledgerIndex: rec.ledgerIndex, deviceId: rec.deviceId, sequence: rec.sequence, temperatureC: rec.temperatureC,
    humidityPct: rec.humidityPct, sensorStatus: rec.sensorStatus, deviceTimestamp: rec.deviceTimestamp, receivedAt: rec.receivedAt,
    clockSynced: rec.deviceTimestamp !== null, source: rec.source, firmwareVersion: rec.firmwareVersion, shipmentId: rec.shipmentId,
    gapBefore: rec.gapBefore, previousHash: rec.previousHash, hash: rec.hash,
    integrity: integrity ?? { status: "UNVERIFIED", kinds: [], verifiedAt: null, runId: null },
  };
}
export type ReadingDto = ReturnType<typeof readingDto>;

type JoinedRow = ReadingRow & { i_status: string | null; i_kinds: string | null; i_at: string | null; i_run: string | null };

function joinedToDto(r: JoinedRow): ReadingDto {
  return readingDto(rowToRecord(r), r.i_status ? { status: r.i_status, kinds: JSON.parse(r.i_kinds ?? "[]") as string[], verifiedAt: r.i_at, runId: r.i_run } : null);
}

export interface ReadingQuery {
  deviceId?: string; shipmentId?: string; from?: string; to?: string; source?: string; sensorStatus?: string;
  status?: string; q?: string; order?: "asc" | "desc"; page: number; pageSize: number;
}

export function buildReadingWhere(q: Omit<ReadingQuery, "page" | "pageSize" | "order">) {
  const where: string[] = [];
  const params: unknown[] = [];
  if (q.deviceId) { where.push("r.device_id = ?"); params.push(q.deviceId); }
  if (q.shipmentId) { where.push("r.shipment_id = ?"); params.push(q.shipmentId); }
  if (q.from) { where.push("r.received_at >= ?"); params.push(q.from); }
  if (q.to) { where.push("r.received_at <= ?"); params.push(q.to); }
  if (q.source) { where.push("r.source = ?"); params.push(q.source); }
  if (q.sensorStatus) { where.push("r.sensor_status = ?"); params.push(q.sensorStatus); }
  if (q.status) {
    if (q.status === "UNVERIFIED") where.push("i.status IS NULL");
    else { where.push("i.status = ?"); params.push(q.status); }
  }
  if (q.q) {
    const like = q.q.replace(/[%_\\]/g, (m) => "\\" + m);
    where.push("(r.id LIKE ? ESCAPE '\\' OR r.hash LIKE ? ESCAPE '\\' OR r.previous_hash LIKE ? ESCAPE '\\' OR r.device_id LIKE ? ESCAPE '\\' OR CAST(r.sequence AS TEXT) = ?)");
    params.push(`${like}%`, `${like}%`, `${like}%`, `%${like}%`, q.q.trim());
  }
  return { w: where.length ? "WHERE " + where.join(" AND ") : "", params };
}

const SELECT = `SELECT r.*, i.status AS i_status, i.kinds_json AS i_kinds, i.verified_at AS i_at, i.run_id AS i_run
  FROM readings r LEFT JOIN record_integrity i ON i.record_id = r.id`;

export function listReadings(ds: Dataset, q: ReadingQuery) {
  const { w, params } = buildReadingWhere(q);
  const total = get<{ c: number }>(ds.db, `SELECT COUNT(*) AS c FROM readings r LEFT JOIN record_integrity i ON i.record_id = r.id ${w}`, ...params)?.c ?? 0;
  const dir = q.order === "asc" ? "ASC" : "DESC";
  const rows = all<JoinedRow>(ds.db, `${SELECT} ${w} ORDER BY r.ledger_index ${dir} LIMIT ? OFFSET ?`, ...params, q.pageSize, (q.page - 1) * q.pageSize);
  return { items: rows.map(joinedToDto), total, page: q.page, pageSize: q.pageSize };
}

export function getReadingDetail(ds: Dataset, id: string) {
  const row = get<JoinedRow>(ds.db, `${SELECT} WHERE r.id = ?`, id);
  if (!row) return undefined;
  const dto = joinedToDto(row);
  const rec = rowToRecord(row);
  const prev = get<JoinedRow>(ds.db, `${SELECT} WHERE r.device_id = ? AND r.sequence < ? ORDER BY r.sequence DESC LIMIT 1`, rec.deviceId, rec.sequence);
  const next = get<JoinedRow>(ds.db, `${SELECT} WHERE r.device_id = ? AND r.sequence > ? ORDER BY r.sequence ASC LIMIT 1`, rec.deviceId, rec.sequence);
  return {
    ...dto,
    canonicalForm: canonicalRecord(rec),
    recomputedHash: computeRecordHash(rec),
    previous: prev ? joinedToDto(prev) : null,
    next: next ? joinedToDto(next) : null,
  };
}
