import { all, get, run } from "../db/index";
import { newId } from "../lib/crypto";
import { AppError, notFound } from "../lib/errors";
import type { AppContext } from "../context";
import type { FailureKind } from "./verifier";

export type AlertCategory = "TEMPERATURE" | "SECURITY";
export type Severity = "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export const ALERT_KINDS = {
  // temperature / device-health alerts
  TEMP_EXCURSION: "TEMPERATURE",
  TEMP_RECOVERED: "TEMPERATURE",
  INVALID_MEASUREMENT: "TEMPERATURE",
  SENSOR_DISCONNECTED: "TEMPERATURE",
  STALE_READINGS: "TEMPERATURE",
  // security / integrity alerts
  HASH_MISMATCH: "SECURITY",
  BROKEN_LINK: "SECURITY",
  MISSING_RECORD: "SECURITY",
  SEQUENCE_GAP: "SECURITY",
  REORDERED_RECORDS: "SECURITY",
  CHECKPOINT_MISMATCH: "SECURITY",
  INVALID_DEVICE_AUTH: "SECURITY",
  REPEATED_FAILED_REQUESTS: "SECURITY",
  SEQUENCE_CONFLICT: "SECURITY",
} as const satisfies Record<string, AlertCategory>;
export type AlertKind = keyof typeof ALERT_KINDS;

export const FAILURE_TO_ALERT: Record<FailureKind, AlertKind> = {
  INVALID_HASH: "HASH_MISMATCH",
  BROKEN_LINK: "BROKEN_LINK",
  MISSING_RECORD: "MISSING_RECORD",
  SEQUENCE_GAP: "SEQUENCE_GAP",
  REORDERED: "REORDERED_RECORDS",
  CHECKPOINT_MISMATCH: "CHECKPOINT_MISMATCH",
};

export interface AlertRow {
  id: string; category: AlertCategory; kind: AlertKind; severity: Severity; status: "OPEN" | "RESOLVED"; scope: "LIVE" | "SANDBOX";
  device_id: string | null; shipment_id: string | null; record_id: string | null; title: string; description: string;
  details_json: string; dedupe_key: string | null; created_at: string; updated_at: string; acknowledged_at: string | null;
  acknowledged_by: string | null; resolved_at: string | null; resolved_by: string | null; resolution_note: string | null;
}

export function alertDto(r: AlertRow, nowIso?: string) {
  const details = JSON.parse(r.details_json) as Record<string, unknown>;
  let durationSeconds: number | null = null;
  if (r.kind === "TEMP_EXCURSION" && typeof details.startedAt === "string") {
    const end = r.resolved_at ?? details.lastOutAt ?? nowIso ?? r.updated_at;
    durationSeconds = Math.max(0, Math.round((Date.parse(String(end)) - Date.parse(details.startedAt)) / 1000));
  }
  return {
    id: r.id, category: r.category, kind: r.kind, severity: r.severity, status: r.status, scope: r.scope,
    deviceId: r.device_id, shipmentId: r.shipment_id, recordId: r.record_id, title: r.title, description: r.description,
    details, createdAt: r.created_at, updatedAt: r.updated_at,
    acknowledged: r.acknowledged_at !== null, acknowledgedAt: r.acknowledged_at, acknowledgedBy: r.acknowledged_by,
    resolvedAt: r.resolved_at, resolvedBy: r.resolved_by, resolutionNote: r.resolution_note, durationSeconds,
  };
}
export type AlertDto = ReturnType<typeof alertDto>;

export interface RaiseParams {
  kind: AlertKind;
  severity: Severity;
  title: string;
  description: string;
  scope?: "LIVE" | "SANDBOX";
  deviceId?: string | null;
  shipmentId?: string | null;
  recordId?: string | null;
  details?: Record<string, unknown>;
  dedupeKey?: string;
  at?: string;
  /** Create already resolved (informational events such as "temperature recovered"). */
  resolved?: { by: string; note: string };
}

/**
 * Raises an alert. If an OPEN alert with the same dedupeKey exists it is updated instead of duplicated.
 */
export function raiseAlert(ctx: AppContext, p: RaiseParams): { alert: AlertDto; created: boolean } {
  const db = ctx.live.db;
  const now = p.at ?? ctx.now();
  if (p.dedupeKey) {
    const open = get<AlertRow>(db, "SELECT * FROM alerts WHERE dedupe_key = ? AND status = 'OPEN'", p.dedupeKey);
    if (open) {
      run(db, "UPDATE alerts SET updated_at = ?, severity = ?, title = ?, description = ?, details_json = ? WHERE id = ?",
        now, p.severity, p.title, p.description, JSON.stringify({ ...(JSON.parse(open.details_json) as object), ...(p.details ?? {}) }), open.id);
      const updated = alertDto(get<AlertRow>(db, "SELECT * FROM alerts WHERE id = ?", open.id)!, now);
      ctx.bus.publish("alert:updated", updated);
      return { alert: updated, created: false };
    }
  }
  const id = newId("alt_");
  run(
    db,
    `INSERT INTO alerts (id, category, kind, severity, status, scope, device_id, shipment_id, record_id, title, description,
       details_json, dedupe_key, created_at, updated_at, resolved_at, resolved_by, resolution_note)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    id, ALERT_KINDS[p.kind], p.kind, p.severity, p.resolved ? "RESOLVED" : "OPEN", p.scope ?? "LIVE", p.deviceId ?? null,
    p.shipmentId ?? null, p.recordId ?? null, p.title, p.description, JSON.stringify(p.details ?? {}),
    p.resolved ? null : (p.dedupeKey ?? null), now, now, p.resolved ? now : null, p.resolved?.by ?? null, p.resolved?.note ?? null,
  );
  const alert = alertDto(get<AlertRow>(db, "SELECT * FROM alerts WHERE id = ?", id)!, now);
  ctx.bus.publish("alert:new", alert);
  return { alert, created: true };
}

export function findOpenByKey(ctx: AppContext, dedupeKey: string): AlertRow | undefined {
  return get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE dedupe_key = ? AND status = 'OPEN'", dedupeKey);
}

export function updateAlertDetails(ctx: AppContext, id: string, patch: { severity?: Severity; title?: string; description?: string; details: Record<string, unknown>; at: string }) {
  const row = get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id);
  if (!row) return;
  const merged = { ...(JSON.parse(row.details_json) as object), ...patch.details };
  run(ctx.live.db, "UPDATE alerts SET updated_at = ?, severity = ?, title = ?, description = ?, details_json = ? WHERE id = ?",
    patch.at, patch.severity ?? row.severity, patch.title ?? row.title, patch.description ?? row.description, JSON.stringify(merged), id);
  ctx.bus.publish("alert:updated", alertDto(get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id)!, patch.at));
}

export function resolveByKey(ctx: AppContext, dedupeKey: string, by: string, note: string, at?: string, extraDetails?: Record<string, unknown>): AlertDto | null {
  const row = findOpenByKey(ctx, dedupeKey);
  if (!row) return null;
  const now = at ?? ctx.now();
  const details = { ...(JSON.parse(row.details_json) as object), ...(extraDetails ?? {}) };
  run(ctx.live.db, "UPDATE alerts SET status = 'RESOLVED', resolved_at = ?, resolved_by = ?, resolution_note = ?, updated_at = ?, dedupe_key = NULL, details_json = ? WHERE id = ?",
    now, by, note, now, JSON.stringify(details), row.id);
  const dto = alertDto(get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", row.id)!, now);
  ctx.bus.publish("alert:updated", dto);
  return dto;
}

export function acknowledgeAlert(ctx: AppContext, id: string, by: string): AlertDto {
  const row = get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id);
  if (!row) throw notFound("Alert");
  if (!row.acknowledged_at) {
    run(ctx.live.db, "UPDATE alerts SET acknowledged_at = ?, acknowledged_by = ?, updated_at = ? WHERE id = ?", ctx.now(), by, ctx.now(), id);
  }
  const dto = alertDto(get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id)!);
  ctx.bus.publish("alert:updated", dto);
  return dto;
}

export function resolveAlert(ctx: AppContext, id: string, by: string, note: string): AlertDto {
  const row = get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id);
  if (!row) throw notFound("Alert");
  if (row.status === "RESOLVED") throw new AppError(409, "ALREADY_RESOLVED", "Alert is already resolved");
  const now = ctx.now();
  run(ctx.live.db,
    `UPDATE alerts SET status = 'RESOLVED', resolved_at = ?, resolved_by = ?, resolution_note = ?, updated_at = ?, dedupe_key = NULL,
       acknowledged_at = COALESCE(acknowledged_at, ?), acknowledged_by = COALESCE(acknowledged_by, ?) WHERE id = ?`,
    now, by, note, now, now, by, id);
  const dto = alertDto(get<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE id = ?", id)!);
  ctx.bus.publish("alert:updated", dto);
  return dto;
}

export interface AlertQuery {
  category?: string; status?: string; severity?: string; deviceId?: string; scope?: string; kind?: string;
  from?: string; to?: string; page: number; pageSize: number;
}

export function buildAlertWhere(q: Omit<AlertQuery, "page" | "pageSize">) {
  const where: string[] = [];
  const params: unknown[] = [];
  const eq = (col: string, v?: string) => { if (v) { where.push(`${col} = ?`); params.push(v); } };
  eq("category", q.category); eq("status", q.status); eq("severity", q.severity); eq("device_id", q.deviceId); eq("scope", q.scope); eq("kind", q.kind);
  if (q.from) { where.push("created_at >= ?"); params.push(q.from); }
  if (q.to) { where.push("created_at <= ?"); params.push(q.to); }
  return { w: where.length ? "WHERE " + where.join(" AND ") : "", params };
}

export function listAlerts(ctx: AppContext, q: AlertQuery) {
  const { w, params } = buildAlertWhere(q);
  const total = get<{ c: number }>(ctx.live.db, `SELECT COUNT(*) AS c FROM alerts ${w}`, ...params)?.c ?? 0;
  const rows = all<AlertRow>(ctx.live.db, `SELECT * FROM alerts ${w} ORDER BY created_at DESC, rowid DESC LIMIT ? OFFSET ?`, ...params, q.pageSize, (q.page - 1) * q.pageSize);
  const now = ctx.now();
  return { items: rows.map((r) => alertDto(r, now)), total, page: q.page, pageSize: q.pageSize };
}

export function alertCounts(ctx: AppContext, scope: "LIVE" | "SANDBOX" = "LIVE") {
  const rows = all<{ category: string; status: string; c: number }>(ctx.live.db, "SELECT category, status, COUNT(*) AS c FROM alerts WHERE scope = ? GROUP BY category, status", scope);
  const n = (cat: string, st: string) => rows.find((r) => r.category === cat && r.status === st)?.c ?? 0;
  return { openTemperature: n("TEMPERATURE", "OPEN"), openSecurity: n("SECURITY", "OPEN"), resolvedTemperature: n("TEMPERATURE", "RESOLVED"), resolvedSecurity: n("SECURITY", "RESOLVED") };
}
