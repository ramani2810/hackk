import { all, get, run } from "../db/index";
import { newId } from "../lib/crypto";
import { redact } from "../lib/logger";
import type { AppContext } from "../context";

export interface Actor {
  id: string | null;
  label: string;
}
export const SYSTEM_ACTOR: Actor = { id: null, label: "system" };
export const deviceActor = (deviceId: string): Actor => ({ id: null, label: `device:${deviceId}` });

export interface AuditInput {
  actor: Actor;
  action: string;
  targetType?: string;
  targetId?: string;
  details?: Record<string, unknown>;
  scope?: "LIVE" | "SANDBOX";
  ip?: string | null;
}

/** Writes an audit event. Details are passed through the redactor so secrets can never be stored. */
export function audit(ctx: AppContext, e: AuditInput): void {
  run(
    ctx.live.db,
    `INSERT INTO audit_events (id, ts, actor_id, actor_label, action, target_type, target_id, scope, details_json, ip)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    newId("aud_"), ctx.now(), e.actor.id, e.actor.label, e.action, e.targetType ?? null, e.targetId ?? null,
    e.scope ?? "LIVE", JSON.stringify(redact(e.details ?? {})), e.ip ?? null,
  );
}

interface AuditRow {
  id: string; ts: string; actor_id: string | null; actor_label: string; action: string; target_type: string | null;
  target_id: string | null; scope: string; details_json: string; ip: string | null;
}

const dto = (r: AuditRow) => ({
  id: r.id, ts: r.ts, actorId: r.actor_id, actor: r.actor_label, action: r.action, targetType: r.target_type,
  targetId: r.target_id, scope: r.scope, details: JSON.parse(r.details_json) as Record<string, unknown>, ip: r.ip,
});

export function listAudit(ctx: AppContext, q: { action?: string; actor?: string; scope?: string; page: number; pageSize: number }) {
  const where: string[] = [];
  const params: unknown[] = [];
  if (q.action) { where.push("action LIKE ?"); params.push(`%${q.action}%`); }
  if (q.actor) { where.push("actor_label LIKE ?"); params.push(`%${q.actor}%`); }
  if (q.scope) { where.push("scope = ?"); params.push(q.scope); }
  const w = where.length ? "WHERE " + where.join(" AND ") : "";
  const total = get<{ c: number }>(ctx.live.db, `SELECT COUNT(*) AS c FROM audit_events ${w}`, ...params)?.c ?? 0;
  const rows = all<AuditRow>(ctx.live.db, `SELECT * FROM audit_events ${w} ORDER BY ts DESC, rowid DESC LIMIT ? OFFSET ?`, ...params, q.pageSize, (q.page - 1) * q.pageSize);
  return { items: rows.map(dto), total, page: q.page, pageSize: q.pageSize };
}

export function recentAudit(ctx: AppContext, limit = 8) {
  return all<AuditRow>(ctx.live.db, "SELECT * FROM audit_events ORDER BY ts DESC, rowid DESC LIMIT ?", limit).map(dto);
}
