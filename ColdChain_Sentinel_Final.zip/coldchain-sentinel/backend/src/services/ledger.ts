import { type DB, tx, get, all, run } from "../db/index";
import { computeRecordHash, genesisHash, newId } from "../lib/crypto";

export type RecordSource = "HARDWARE" | "SIMULATOR" | "SANDBOX";
export type SensorStatus = "OK" | "DISCONNECTED" | "INVALID";

export interface LedgerRecord {
  ledgerIndex: number;
  id: string;
  deviceId: string;
  sequence: number;
  temperatureC: number | null;
  humidityPct: number | null;
  sensorStatus: SensorStatus;
  deviceTimestamp: string | null;
  receivedAt: string;
  source: RecordSource;
  firmwareVersion: string | null;
  shipmentId: string | null;
  gapBefore: number;
  previousHash: string;
  hash: string;
}

export interface ReadingRow {
  ledger_index: number;
  id: string;
  device_id: string;
  sequence: number;
  temperature_c: number | null;
  humidity_pct: number | null;
  sensor_status: SensorStatus;
  device_timestamp: string | null;
  received_at: string;
  source: RecordSource;
  firmware_version: string | null;
  shipment_id: string | null;
  gap_before: number;
  previous_hash: string;
  hash: string;
}

export function rowToRecord(r: ReadingRow): LedgerRecord {
  return {
    ledgerIndex: r.ledger_index,
    id: r.id,
    deviceId: r.device_id,
    sequence: r.sequence,
    temperatureC: r.temperature_c,
    humidityPct: r.humidity_pct,
    sensorStatus: r.sensor_status,
    deviceTimestamp: r.device_timestamp,
    receivedAt: r.received_at,
    source: r.source,
    firmwareVersion: r.firmware_version,
    shipmentId: r.shipment_id,
    gapBefore: r.gap_before,
    previousHash: r.previous_hash,
    hash: r.hash,
  };
}

export interface AppendInput {
  /** Optional fixed record id (used only by the deterministic sandbox dataset). */
  id?: string;
  deviceId: string;
  sequence: number;
  temperatureC: number | null;
  humidityPct: number | null;
  sensorStatus: SensorStatus;
  deviceTimestamp: string | null;
  receivedAt: string;
  source: RecordSource;
  firmwareVersion: string | null;
  shipmentId: string | null;
}

export type AppendResult =
  | { kind: "created"; record: LedgerRecord }
  | { kind: "duplicate"; record: LedgerRecord }
  | { kind: "conflict"; existing: LedgerRecord }
  | { kind: "stale"; lastSequence: number };

export const round3 = (n: number) => Math.round(n * 1000) / 1000;
export const round1 = (n: number) => Math.round(n * 10) / 10;

export function getRecordById(db: DB, id: string): LedgerRecord | undefined {
  const r = get<ReadingRow>(db, "SELECT * FROM readings WHERE id = ?", id);
  return r ? rowToRecord(r) : undefined;
}

export function getTail(db: DB, deviceId: string): LedgerRecord | undefined {
  const r = get<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? ORDER BY sequence DESC LIMIT 1", deviceId);
  return r ? rowToRecord(r) : undefined;
}

/** All records of one device chain in INSERTION order (used by the verifier to detect reordering). */
export function listDeviceRecords(db: DB, deviceId: string): LedgerRecord[] {
  return all<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? ORDER BY ledger_index ASC", deviceId).map(rowToRecord);
}

export function countDeviceRecords(db: DB, deviceId: string): number {
  return get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM readings WHERE device_id = ?", deviceId)?.c ?? 0;
}

/** A retry is the same measurement. Timestamp and firmware version are deliberately ignored so a retry that regenerates them is still idempotent. */
function sameContent(existing: LedgerRecord, input: AppendInput): boolean {
  return (
    existing.temperatureC === input.temperatureC &&
    existing.humidityPct === input.humidityPct &&
    existing.sensorStatus === input.sensorStatus
  );
}

/**
 * Appends one record to the device's hash chain.
 *
 * Runs inside a BEGIN IMMEDIATE transaction: the write lock is taken BEFORE the tail is read, so
 * concurrent callers are serialised and can never produce two records with the same previous hash
 * or the same sequence number. UNIQUE(device_id, sequence) is a second line of defence.
 *
 * - same (device, sequence) and identical content  -> duplicate (idempotent retry)
 * - same (device, sequence) and different content  -> conflict  (possible replay / forgery)
 * - sequence <= highest sequence ever accepted     -> stale
 * - sequence skips numbers                         -> accepted; the skipped count is recorded in the
 *   hashed field gapBefore so it is an *acknowledged* gap that the verifier will not report as tampering.
 */
export function appendRecord(db: DB, input: AppendInput): AppendResult {
  return tx(db, () => {
    const existingRow = get<ReadingRow>(db, "SELECT * FROM readings WHERE device_id = ? AND sequence = ?", input.deviceId, input.sequence);
    if (existingRow) {
      const existing = rowToRecord(existingRow);
      return sameContent(existing, input) ? { kind: "duplicate", record: existing } : { kind: "conflict", existing };
    }
    const device = get<{ last_sequence: number }>(db, "SELECT last_sequence FROM devices WHERE id = ?", input.deviceId);
    if (!device) throw new Error(`appendRecord: unknown device ${input.deviceId}`);
    const tail = getTail(db, input.deviceId);
    // The device registry remembers the highest sequence ever accepted, so deleting the tail of the
    // ledger cannot be used to "rewind" a device silently.
    const lastSeq = Math.max(tail?.sequence ?? 0, device.last_sequence);
    if (input.sequence <= lastSeq) return { kind: "stale", lastSequence: lastSeq };

    const gapBefore = lastSeq === 0 ? 0 : input.sequence - lastSeq - 1;
    const previousHash = tail ? tail.hash : genesisHash(input.deviceId);
    const id = input.id ?? newId();
    const base = {
      id,
      deviceId: input.deviceId,
      sequence: input.sequence,
      temperatureC: input.temperatureC,
      humidityPct: input.humidityPct,
      sensorStatus: input.sensorStatus,
      deviceTimestamp: input.deviceTimestamp,
      receivedAt: input.receivedAt,
      source: input.source,
      firmwareVersion: input.firmwareVersion,
      shipmentId: input.shipmentId,
      gapBefore,
      previousHash,
    };
    const hash = computeRecordHash(base);
    const res = run(
      db,
      `INSERT INTO readings (id, device_id, sequence, temperature_c, humidity_pct, sensor_status, device_timestamp,
         received_at, source, firmware_version, shipment_id, gap_before, previous_hash, hash)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, input.deviceId, input.sequence, input.temperatureC, input.humidityPct, input.sensorStatus, input.deviceTimestamp,
      input.receivedAt, input.source, input.firmwareVersion, input.shipmentId, gapBefore, previousHash, hash,
    );
    run(
      db,
      `UPDATE devices SET last_seen_at = ?, last_temperature_c = ?, last_sensor_status = ?, last_reading_id = ?,
         firmware_version = COALESCE(?, firmware_version), last_sequence = ? WHERE id = ?`,
      input.receivedAt, input.temperatureC, input.sensorStatus, id, input.firmwareVersion, input.sequence, input.deviceId,
    );
    return { kind: "created", record: { ledgerIndex: Number(res.lastInsertRowid), ...base, hash } };
  });
}
