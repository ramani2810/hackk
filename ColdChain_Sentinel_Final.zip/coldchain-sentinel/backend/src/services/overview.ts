import { all, get } from "../db/index";
import type { AppContext } from "../context";
import { alertCounts, alertDto, type AlertRow } from "./alerts";
import { recentAudit } from "./audit";
import { listDevices } from "./devices";
import { latestRun, latestSuccessfulRun } from "./integrity";
import { listReadings, readingDto } from "./readings";
import { listShipments } from "./shipments";
import { getSettings } from "./settings";
import { rowToRecord, type ReadingRow } from "./ledger";

export function currentMode(ctx: AppContext) {
  const devices = listDevices(ctx);
  const hardwareOnline = devices.filter((d) => d.type === "ESP32" && d.online).length;
  const sim = ctx.simulator.state();
  const mode = hardwareOnline > 0 ? "LIVE_HARDWARE" : "SIMULATION";
  const last = get<ReadingRow>(ctx.live.db, "SELECT * FROM readings ORDER BY ledger_index DESC LIMIT 1");
  return {
    mode,
    hardwareDevicesOnline: hardwareOnline,
    simulatorRunning: sim.running,
    latestRecordSource: last ? last.source : null,
    explanation: hardwareOnline > 0
      ? `${hardwareOnline} physical ESP32 device(s) delivered readings within the last ${getSettings(ctx.live.db).staleSeconds} s.`
      : "No physical hardware is currently reporting. Any live data on screen comes from the software simulator.",
  };
}

export function statusSummary(ctx: AppContext) {
  const m = currentMode(ctx);
  const settings = getSettings(ctx.live.db);
  const devices = listDevices(ctx);
  const lastRead = get<{ received_at: string }>(ctx.live.db, "SELECT received_at FROM readings ORDER BY ledger_index DESC LIMIT 1");
  return {
    serverTime: ctx.now(), ...m, simulator: ctx.simulator.state(), devEndpointsEnabled: ctx.config.enableDevEndpoints,
    environment: ctx.config.nodeEnv, settings,
    devices: { total: devices.length, online: devices.filter((d) => d.online).length },
    lastReadingAt: lastRead?.received_at ?? null,
    openAlerts: alertCounts(ctx),
  };
}

export function overview(ctx: AppContext) {
  const db = ctx.live.db;
  const settings = getSettings(db);
  const devices = listDevices(ctx);
  const latestOk = get<ReadingRow>(db, "SELECT * FROM readings WHERE sensor_status = 'OK' ORDER BY ledger_index DESC LIMIT 1");
  const totalRecords = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM readings")!.c;
  const verified = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM record_integrity i JOIN readings r ON r.id = i.record_id WHERE i.status = 'VERIFIED'")!.c;
  const failed = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM record_integrity i JOIN readings r ON r.id = i.record_id WHERE i.status <> 'VERIFIED'")!.c;
  const excursionsTotal = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE kind = 'TEMP_EXCURSION' AND scope = 'LIVE'")!.c;
  const excursionsOpen = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE kind = 'TEMP_EXCURSION' AND status = 'OPEN' AND scope = 'LIVE'")!.c;
  const integrityOpen = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM alerts WHERE dedupe_key LIKE 'integrity:LIVE:%' AND status = 'OPEN'")!.c;
  const now = ctx.now();
  const rows = (cat: string) => all<AlertRow>(db, "SELECT * FROM alerts WHERE category = ? AND scope = 'LIVE' ORDER BY created_at DESC, rowid DESC LIMIT 6", cat).map((a) => alertDto(a, now));
  const shipments = listShipments(ctx);
  const lastRun = latestRun(ctx.live);
  const lastOk = latestSuccessfulRun(ctx.live);
  return {
    generatedAt: now,
    mode: currentMode(ctx),
    settings: { tempMinC: settings.tempMinC, tempMaxC: settings.tempMaxC },
    kpis: {
      devicesTotal: devices.length,
      devicesOnline: devices.filter((d) => d.online).length,
      latestTemperature: latestOk ? { temperatureC: latestOk.temperature_c, deviceId: latestOk.device_id, receivedAt: latestOk.received_at, source: latestOk.source } : null,
      excursionsTotal, excursionsOpen,
      totalRecords, verifiedRecords: verified, failedRecords: failed, unverifiedRecords: Math.max(0, totalRecords - verified - failed),
      integrityViolationsOpen: integrityOpen,
      lastSuccessfulVerificationAt: lastOk?.finishedAt ?? null,
    },
    latestVerification: lastRun ? { id: lastRun.id, status: lastRun.status, scope: lastRun.scope, deviceId: lastRun.deviceId, recordsChecked: lastRun.recordsChecked, finishedAt: lastRun.finishedAt, failureCounts: lastRun.failureCounts, checkpointsChecked: lastRun.checkpointsChecked } : null,
    devices,
    recentReadings: listReadings(ctx.live, { order: "desc", page: 1, pageSize: 8 }).items,
    recentSecurityAlerts: rows("SECURITY"),
    recentTemperatureAlerts: rows("TEMPERATURE"),
    recentAudit: recentAudit(ctx, 6),
    shipments: { total: shipments.length, inTransit: shipments.filter((s) => s.status === "IN_TRANSIT").length, items: shipments.slice(0, 4) },
  };
}

export { readingDto, rowToRecord };
