import fs from "node:fs";
import path from "node:path";
import { type DB, get, all, run } from "../db/index";
import { canonicalize, hmacSha256Hex, sha256Hex, timingSafeEqualHex, newId } from "../lib/crypto";
import type { LedgerRecord } from "./ledger";

/**
 * Signed ledger checkpoints.
 *
 * A checkpoint is a statement "device D's chain had N records and head hash H at time T", signed with
 * HMAC-SHA-256 using CHECKPOINT_SIGNING_KEY. The signing key lives in the process environment, NOT in the
 * database, and the authoritative checkpoint log is an append-only file OUTSIDE the database
 * (data/checkpoints/<device>.jsonl). Each checkpoint also commits to the digest of the previous one, so
 * deleting or reordering checkpoints in the middle of the file is detectable.
 *
 * Honest limits: someone who controls this whole machine (database + key + checkpoint files) can still
 * rewrite everything. For real independence, copy the checkpoint file to a separate system (WORM storage,
 * another server, an email, a notarised log) or sign with a key held in a KMS/HSM.
 * Records appended AFTER the newest checkpoint are protected only by the hash chain.
 */
export interface Checkpoint {
  id: string;
  deviceId: string;
  recordCount: number;
  lastSequence: number;
  headHash: string;
  prevDigest: string;
  createdAt: string;
  keyId: string;
  signature: string;
}

const CHECKPOINT_DOMAIN = "coldchain-sentinel/checkpoint/v1\n";
const ZERO_DIGEST = "0".repeat(64);

type Body = Omit<Checkpoint, "signature">;

export interface CheckpointFileState {
  exists: boolean;
  checkpoints: Checkpoint[];
  problems: { checkpointId: string | null; message: string }[];
}

export class CheckpointStore {
  readonly keyId: string;
  constructor(
    private dir: string,
    private key: Buffer,
    private db: DB,
  ) {
    this.keyId = sha256Hex(key).slice(0, 8);
  }

  private file(deviceId: string): string {
    return path.join(this.dir, encodeURIComponent(deviceId) + ".jsonl");
  }

  private sign(body: Body): string {
    return hmacSha256Hex(this.key, CHECKPOINT_DOMAIN + canonicalize(body));
  }

  private digest(cp: Checkpoint): string {
    const { signature, ...body } = cp;
    return sha256Hex(canonicalize(body) + signature);
  }

  /** Read and cryptographically validate the checkpoint file for a device. */
  read(deviceId: string): CheckpointFileState {
    const f = this.file(deviceId);
    if (!fs.existsSync(f)) return { exists: false, checkpoints: [], problems: [] };
    const problems: CheckpointFileState["problems"] = [];
    const checkpoints: Checkpoint[] = [];
    const lines = fs.readFileSync(f, "utf8").split("\n").filter((l) => l.trim().length > 0);
    let prevDigest = ZERO_DIGEST;
    let prevSeq = 0;
    lines.forEach((line, i) => {
      let cp: Checkpoint;
      try {
        cp = JSON.parse(line) as Checkpoint;
      } catch {
        problems.push({ checkpointId: null, message: `Checkpoint file line ${i + 1} is not valid JSON` });
        return;
      }
      const { signature, ...body } = cp;
      let sigOk = false;
      try {
        sigOk = typeof signature === "string" && timingSafeEqualHex(this.sign(body as Body), signature);
      } catch {
        sigOk = false;
      }
      if (!sigOk) {
        problems.push({ checkpointId: cp.id ?? null, message: `Checkpoint ${cp.id ?? "#" + (i + 1)} has an invalid signature (edited, or signed with a different key)` });
        return;
      }
      if (cp.deviceId !== deviceId) {
        problems.push({ checkpointId: cp.id, message: `Checkpoint ${cp.id} belongs to a different device` });
        return;
      }
      if (cp.prevDigest !== prevDigest) {
        problems.push({ checkpointId: cp.id, message: `Checkpoint ${cp.id} does not link to the previous checkpoint (one was removed or reordered)` });
      }
      if (cp.lastSequence <= prevSeq) {
        problems.push({ checkpointId: cp.id, message: `Checkpoint ${cp.id} is out of order` });
      }
      prevDigest = this.digest(cp);
      prevSeq = cp.lastSequence;
      checkpoints.push(cp);
    });
    return { exists: true, checkpoints, problems };
  }

  latest(deviceId: string): Checkpoint | undefined {
    const st = this.read(deviceId);
    return st.checkpoints[st.checkpoints.length - 1];
  }

  /** Creates a signed checkpoint for the chain whose head is `head` and which has `recordCount` records. */
  create(deviceId: string, head: LedgerRecord, recordCount: number, createdAt: string): Checkpoint {
    const state = this.read(deviceId);
    const last = state.checkpoints[state.checkpoints.length - 1];
    if (last && last.lastSequence === head.sequence && last.headHash === head.hash) return last;
    const body: Body = {
      id: newId("cp_"),
      deviceId,
      recordCount,
      lastSequence: head.sequence,
      headHash: head.hash,
      prevDigest: last ? this.digest(last) : ZERO_DIGEST,
      createdAt,
      keyId: this.keyId,
    };
    const cp: Checkpoint = { ...body, signature: this.sign(body) };
    fs.mkdirSync(this.dir, { recursive: true });
    fs.appendFileSync(this.file(deviceId), JSON.stringify(cp) + "\n", { encoding: "utf8", mode: 0o600 });
    run(
      this.db,
      `INSERT OR IGNORE INTO checkpoints (id, device_id, record_count, last_sequence, head_hash, prev_digest, created_at, key_id, signature)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      cp.id, cp.deviceId, cp.recordCount, cp.lastSequence, cp.headHash, cp.prevDigest, cp.createdAt, cp.keyId, cp.signature,
    );
    return cp;
  }

  /** Checkpoint copies kept in the database (for listing and for cross-checking against the file). */
  dbCopies(deviceId?: string): Checkpoint[] {
    const rows = deviceId
      ? all<DbRow>(this.db, "SELECT * FROM checkpoints WHERE device_id = ? ORDER BY last_sequence", deviceId)
      : all<DbRow>(this.db, "SELECT * FROM checkpoints ORDER BY device_id, last_sequence");
    return rows.map((r) => ({
      id: r.id, deviceId: r.device_id, recordCount: r.record_count, lastSequence: r.last_sequence, headHash: r.head_hash,
      prevDigest: r.prev_digest, createdAt: r.created_at, keyId: r.key_id, signature: r.signature,
    }));
  }

  /** Device ids that have a checkpoint file on disk. */
  deviceIdsOnDisk(): string[] {
    if (!fs.existsSync(this.dir)) return [];
    return fs.readdirSync(this.dir).filter((f) => f.endsWith(".jsonl")).map((f) => decodeURIComponent(f.slice(0, -6)));
  }

  /** Used ONLY by the demo-data reset and sandbox reset. Removes the file and DB copies for a device. */
  deleteDevice(deviceId: string): void {
    fs.rmSync(this.file(deviceId), { force: true });
    run(this.db, "DELETE FROM checkpoints WHERE device_id = ?", deviceId);
  }

  /** Test/demo helper: overwrite a line in the file to simulate someone editing the trusted store. */
  rawFilePath(deviceId: string): string {
    return this.file(deviceId);
  }
}

interface DbRow {
  id: string; device_id: string; record_count: number; last_sequence: number; head_hash: string;
  prev_digest: string; created_at: string; key_id: string; signature: string;
}

export function countCheckpoints(db: DB): number {
  return get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM checkpoints")?.c ?? 0;
}
