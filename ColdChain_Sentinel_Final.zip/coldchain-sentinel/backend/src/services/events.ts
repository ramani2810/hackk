export type BusEventName =
  | "reading:new"
  | "alert:new"
  | "alert:updated"
  | "verification:done"
  | "device:updated"
  | "simulator:state"
  | "sandbox:updated"
  | "settings:updated";

export type BusListener = (event: BusEventName, payload: unknown) => void;

export class EventBus {
  private listeners = new Set<BusListener>();
  publish(event: BusEventName, payload: unknown = {}) {
    for (const l of this.listeners) {
      try {
        l(event, payload);
      } catch {
        /* a failing listener must never break ingestion */
      }
    }
  }
  subscribe(fn: BusListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
}
