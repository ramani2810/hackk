import { z } from "zod";
import { get } from "../db/index";
import type { AppContext } from "../context";
import { conflict } from "../lib/errors";
import { DEVICE_ID_RE, type DeviceRow, deviceDto, getDeviceRow } from "./devices";
import { type LedgerRecord, appendRecord, round1, round3 } from "./ledger";
import { evaluateReading } from "./temperature";
import { raiseAlert, resolveByKey, type AlertDto } from "./alerts";
import { autoCheckpoint } from "./integrity";
import { readingDto } from "./readings";
import type { Checkpoint } from "./checkpoints";

export const readingSchema = z
  .object({
    deviceId: z.string().regex(DEVICE_ID_RE, "invalid device id"),
    sequence: z.number().int().min(1).max(2_000_000_000),
    temperatureC: z.number().min(-80).max(150).nullable().optional(),
    humidityPct: z.number().min(0).max(100).nullable().optional(),
    recordedAt: z.iso.datetime({ offset: true }).optional(),
    sensorStatus: z.enum(["OK", "DISCONNECTED", "INVALID"]),
    firmwareVersion: z.string().regex(/^[A-Za-z0-9._+-]{1,32}$/, "invalid firmware version").optional(),
  })
  .strict()
  .refine((v) => v.sensorStatus !== "OK" || (v.temperatureC !== null && v.temperatureC !== undefined), {
    message: "temperatureC is required when sensorStatus is OK",
    path: ["temperatureC"],
  });
export type IngestPayload = z.infer<typeof readingSchema>;

export interface IngestOutcome {
  status: "created" | "duplicate";
  record: LedgerRecord;
  alerts: AlertDto[];
  checkpoint: Checkpoint | null;
  clock: "SYNCED" | "UNSYNCHRONIZED";
}

const MIN_PLAUSIBLE_CLOCK = Date.parse("2024-01-01T00:00:00Z");

/**
 * The single ingestion path for BOTH hardware (HTTP) and the simulator (direct call):
 * validate -> hash-chain append (transactional) -> temperature alerts -> checkpoint -> live events.
 * `device` must already be authenticated by the caller.
 */
export function ingestReading(ctx: AppContext, device: DeviceRow, p: IngestPayload): IngestOutcome {
  const receivedAt = ctx.now();
  const temperatureC = p.sensorStatus === "OK" && p.temperatureC != null ? round3(p.temperatureC) : null;
  const humidityPct = p.sensorStatus === "OK" && p.humidityPct != null ? round1(p.humidityPct) : null;
  let deviceTimestamp: string | null = null;
  if (p.recordedAt) {
    const ms = Date.parse(p.recordedAt);
    // Clocks that were never synchronised (NTP failed) typically report 1970/2000; treat them as "no timestamp".
    if (Number.isFinite(ms) && ms >= MIN_PLAUSIBLE_CLOCK) deviceTimestamp = new Date(ms).toISOString();
  }
  const ship = get<{ id: string }>(ctx.live.db, "SELECT id FROM shipments WHERE device_id = ? AND status = 'IN_TRANSIT' ORDER BY started_at DESC LIMIT 1", device.id);

  const res = appendRecord(ctx.live.db, {
    deviceId: device.id, sequence: p.sequence, temperatureC, humidityPct, sensorStatus: p.sensorStatus, deviceTimestamp, receivedAt,
    source: device.type === "ESP32" ? "HARDWARE" : "SIMULATOR", firmwareVersion: p.firmwareVersion ?? null, shipmentId: ship?.id ?? null,
  });

  if (res.kind === "duplicate") {
    return { status: "duplicate", record: res.record, alerts: [], checkpoint: null, clock: deviceTimestamp ? "SYNCED" : "UNSYNCHRONIZED" };
  }
  if (res.kind === "conflict") {
    raiseAlert(ctx, {
      kind: "SEQUENCE_CONFLICT", severity: "HIGH", deviceId: device.id, dedupeKey: `seqconflict:${device.id}`,
      title: "Conflicting data for an already-recorded sequence number",
      description: `Device ${device.id} sent sequence #${p.sequence} again with DIFFERENT contents than the record already stored. This may be a replay, a forged message or a device that lost its sequence counter. The original record was kept unchanged.`,
      details: { sequence: p.sequence, existingRecordId: res.existing.id },
    });
    throw conflict("SEQUENCE_CONFLICT", `Sequence #${p.sequence} was already recorded with different contents`, { sequence: p.sequence });
  }
  if (res.kind === "stale") {
    raiseAlert(ctx, {
      kind: "SEQUENCE_CONFLICT", severity: "MEDIUM", deviceId: device.id, dedupeKey: `seqconflict:${device.id}`,
      title: "Device sequence number went backwards",
      description: `Device ${device.id} sent sequence #${p.sequence}, but #${res.lastSequence} was already accepted. The reading was rejected to keep the ledger strictly ordered. The device should continue from #${res.lastSequence + 1}.`,
      details: { sequence: p.sequence, lastSequence: res.lastSequence },
    });
    throw conflict("STALE_SEQUENCE", `Sequence #${p.sequence} is not newer than the last accepted sequence #${res.lastSequence}`, { lastSequence: res.lastSequence });
  }

  const record = res.record;
  const alerts: AlertDto[] = [];
  try {
    alerts.push(...evaluateReading(ctx, record));
    if (record.gapBefore > 0) {
      alerts.push(raiseAlert(ctx, {
        kind: "SEQUENCE_GAP", severity: "LOW", deviceId: device.id, recordId: record.id, shipmentId: record.shipmentId, at: receivedAt, dedupeKey: `gap:${record.id}`,
        title: `${record.gapBefore} reading(s) skipped before #${record.sequence}`,
        description: `Device ${device.id} jumped from #${record.sequence - record.gapBefore - 1} to #${record.sequence}. The gap was recorded in the hash chain at ingestion (device buffer loss or dropped delivery). Review it if unexpected.`,
        details: { gapBefore: record.gapBefore },
      }).alert);
    }
    resolveByKey(ctx, `auth-fail:${device.id}`, "system:auto-recovery", "Device authenticated successfully again", receivedAt);
  } catch (err) {
    ctx.log.error("alert evaluation failed", { deviceId: device.id, error: (err as Error).message });
  }
  const checkpoint = autoCheckpoint(ctx, ctx.live, device.id);

  ctx.bus.publish("reading:new", readingDto(record));
  ctx.bus.publish("device:updated", deviceDto(ctx, getDeviceRow(ctx, device.id)!));
  return { status: "created", record, alerts, checkpoint, clock: deviceTimestamp ? "SYNCED" : "UNSYNCHRONIZED" };
}
