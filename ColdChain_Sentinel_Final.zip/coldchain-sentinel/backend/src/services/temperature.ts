import { get } from "../db/index";
import type { AppContext } from "../context";
import type { LedgerRecord } from "./ledger";
import { getSettings } from "./settings";
import { findOpenByKey, raiseAlert, resolveByKey, updateAlertDetails, type AlertDto, type Severity } from "./alerts";
import type { ShipmentRow } from "./shipments";

export interface Thresholds { minC: number; maxC: number; source: "shipment" | "settings"; shipmentId: string | null }

export function thresholdsFor(ctx: AppContext, shipmentId: string | null): Thresholds {
  if (shipmentId) {
    const s = get<ShipmentRow>(ctx.live.db, "SELECT * FROM shipments WHERE id = ?", shipmentId);
    if (s) return { minC: s.min_temp_c, maxC: s.max_temp_c, source: "shipment", shipmentId };
  }
  const st = getSettings(ctx.live.db);
  return { minC: st.tempMinC, maxC: st.tempMaxC, source: "settings", shipmentId: null };
}

const r2 = (n: number) => Math.round(n * 100) / 100;

/**
 * Temperature / device-health alerting.
 *
 * IMPORTANT: this is deliberately independent of the hash chain. A reading outside 2-8 C creates a TEMPERATURE
 * alert; the record itself stays cryptographically valid. Only the verifier raises SECURITY (integrity) alerts.
 *
 * Recovery rule (documented): an open excursion is resolved automatically after `recoveryReadings`
 * (default 2) consecutive valid in-range readings. Duration = first out-of-range reading -> resolving reading.
 */
export function evaluateReading(ctx: AppContext, rec: LedgerRecord, scope: "LIVE" | "SANDBOX" = "LIVE"): AlertDto[] {
  const raised: AlertDto[] = [];
  const dev = rec.deviceId;
  const settings = getSettings(ctx.live.db);
  const sc = scope === "SANDBOX" ? "sbx:" : "";
  const keyExc = `${sc}excursion:${dev}`;
  const keyDisc = `${sc}sensor:${dev}:SENSOR_DISCONNECTED`;
  const keyInv = `${sc}sensor:${dev}:INVALID_MEASUREMENT`;
  const keyStale = `${sc}stale:${dev}`;
  const at = rec.receivedAt;

  // any accepted reading clears a stale-data alert
  resolveByKey(ctx, keyStale, "system:auto-recovery", "Readings resumed", at);

  if (rec.sensorStatus !== "OK" || rec.temperatureC === null) {
    const kind = rec.sensorStatus === "DISCONNECTED" ? "SENSOR_DISCONNECTED" : "INVALID_MEASUREMENT";
    const res = raiseAlert(ctx, {
      kind, severity: kind === "SENSOR_DISCONNECTED" ? "HIGH" : "MEDIUM", scope, deviceId: dev, shipmentId: rec.shipmentId, recordId: rec.id, at,
      dedupeKey: kind === "SENSOR_DISCONNECTED" ? keyDisc : keyInv,
      title: kind === "SENSOR_DISCONNECTED" ? "Temperature sensor disconnected" : "Invalid temperature measurement",
      description: kind === "SENSOR_DISCONNECTED"
        ? `Device ${dev} reports that its temperature probe is not responding. Temperature is not being measured.`
        : `Device ${dev} reported a measurement that failed validation. The reading was recorded without a temperature value.`,
      details: { sensorStatus: rec.sensorStatus, lastRecordId: rec.id, lastSequence: rec.sequence },
    });
    if (res.created) raised.push(res.alert);
    return raised;
  }

  // a valid reading ends any sensor-fault alert
  resolveByKey(ctx, keyDisc, "system:auto-recovery", "Sensor reported a valid reading again", at);
  resolveByKey(ctx, keyInv, "system:auto-recovery", "Sensor reported a valid reading again", at);

  const th = thresholdsFor(ctx, rec.shipmentId);
  const t = rec.temperatureC;
  const above = t > th.maxC;
  const below = t < th.minC;
  const open = findOpenByKey(ctx, keyExc);

  if (above || below) {
    const limit = above ? th.maxC : th.minC;
    const deviation = r2(Math.abs(t - limit));
    const severity: Severity = deviation >= 3 ? "CRITICAL" : deviation >= 1 ? "HIGH" : "MEDIUM";
    const direction = above ? "above" : "below";
    if (!open) {
      const res = raiseAlert(ctx, {
        kind: "TEMP_EXCURSION", severity, scope, deviceId: dev, shipmentId: rec.shipmentId, recordId: rec.id, at, dedupeKey: keyExc,
        title: `Temperature excursion: ${t.toFixed(2)} °C is ${direction} the ${limit} °C limit`,
        description: `Device ${dev} measured ${t.toFixed(2)} °C, ${deviation} °C ${direction} the configured limit of ${limit} °C (allowed ${th.minC}–${th.maxC} °C). This is a genuine measurement; the record's cryptographic integrity is not affected.`,
        details: { minC: th.minC, maxC: th.maxC, limitC: limit, direction: above ? "HIGH" : "LOW", peakC: t, peakDeviationC: deviation, startedAt: at, lastOutAt: at, outOfRangeReadings: 1, inRangeStreak: 0, firstRecordId: rec.id, lastRecordId: rec.id, thresholdSource: th.source },
      });
      raised.push(res.alert);
    } else {
      const d = JSON.parse(open.details_json) as { peakC: number; peakDeviationC: number; outOfRangeReadings: number; direction: string };
      const worse = deviation > d.peakDeviationC;
      const newSev: Severity = (["MEDIUM", "HIGH", "CRITICAL"] as Severity[]).indexOf(severity) > (["MEDIUM", "HIGH", "CRITICAL"] as Severity[]).indexOf(open.severity) ? severity : open.severity;
      updateAlertDetails(ctx, open.id, {
        at, severity: newSev,
        details: { peakC: worse ? t : d.peakC, peakDeviationC: worse ? deviation : d.peakDeviationC, lastOutAt: at, outOfRangeReadings: d.outOfRangeReadings + 1, inRangeStreak: 0, lastRecordId: rec.id },
      });
    }
    return raised;
  }

  if (open) {
    const d = JSON.parse(open.details_json) as { inRangeStreak: number; startedAt: string; peakC: number; peakDeviationC: number; direction: string; outOfRangeReadings: number };
    const streak = d.inRangeStreak + 1;
    if (streak >= settings.recoveryReadings) {
      const durationSeconds = Math.max(0, Math.round((Date.parse(at) - Date.parse(d.startedAt)) / 1000));
      resolveByKey(ctx, keyExc, "system:auto-recovery", `Auto-resolved after ${streak} consecutive in-range readings`, at, { inRangeStreak: streak, resolvedAfterDurationSeconds: durationSeconds });
      const res = raiseAlert(ctx, {
        kind: "TEMP_RECOVERED", severity: "INFO", scope, deviceId: dev, shipmentId: rec.shipmentId, recordId: rec.id, at,
        title: `Temperature recovered to ${t.toFixed(2)} °C`,
        description: `Device ${dev} returned to the allowed range (${th.minC}–${th.maxC} °C). The excursion lasted ${durationSeconds} s with a peak of ${d.peakC.toFixed(2)} °C (${d.outOfRangeReadings} out-of-range reading(s)).`,
        details: { durationSeconds, peakC: d.peakC, excursionStartedAt: d.startedAt, recoveredAt: at, minC: th.minC, maxC: th.maxC },
        resolved: { by: "system:auto-recovery", note: "Informational event" },
      });
      raised.push(res.alert);
    } else {
      updateAlertDetails(ctx, open.id, { at, details: { inRangeStreak: streak } });
    }
  }
  return raised;
}
