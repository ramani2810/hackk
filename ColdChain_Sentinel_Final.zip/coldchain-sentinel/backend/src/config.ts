import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";

const here = path.dirname(fileURLToPath(import.meta.url));
export const BACKEND_ROOT = path.resolve(here, "..");

export interface AppConfig {
  nodeEnv: "development" | "test" | "production";
  port: number;
  host: string;
  dataDir: string;
  dbPath: string;
  sandboxDbPath: string;
  checkpointDir: string;
  sandboxCheckpointDir: string;
  migrationsDir: string;
  frontendOrigin: string;
  serveFrontend: boolean;
  frontendDist: string;
  deviceSecretKey: Buffer; // AES-256 key protecting device HMAC secrets at rest
  checkpointKey: Buffer; // HMAC key signing ledger checkpoints (keep separate from the database!)
  checkpointEvery: number;
  sessionTtlHours: number;
  cookieSecure: boolean;
  enableDevEndpoints: boolean;
  loginRateMax: number;
  loginRateWindowMs: number;
  ingestRateMax: number;
  ingestRateWindowMs: number;
  staleCheckIntervalMs: number;
  trustProxy: boolean;
  logLevel: "debug" | "info" | "warn" | "error" | "silent";
}

function hexKey(name: string, value: string | undefined, nodeEnv: string): Buffer {
  if (!value) {
    throw new Error(
      `Missing environment variable ${name}. Run "npm run setup" from the project root to generate backend/.env, ` +
        `or copy backend/.env.example to backend/.env and fill it in.`,
    );
  }
  if (!/^[0-9a-fA-F]{64}$/.test(value)) {
    throw new Error(`${name} must be exactly 64 hexadecimal characters (32 bytes).`);
  }
  if (nodeEnv === "production" && /^(0+|f+|(0123456789abcdef)+)$/i.test(value)) {
    throw new Error(`${name} looks like a placeholder; generate a random value.`);
  }
  return Buffer.from(value, "hex");
}

function bool(v: string | undefined, dflt: boolean): boolean {
  if (v === undefined || v === "") return dflt;
  return ["1", "true", "yes", "on"].includes(v.toLowerCase());
}

function int(v: string | undefined, dflt: number): number {
  if (v === undefined || v === "") return dflt;
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) throw new Error(`Invalid integer value: ${v}`);
  return n;
}

export function loadConfig(overrides: Partial<AppConfig> = {}): AppConfig {
  const envFile = path.join(BACKEND_ROOT, ".env");
  if (fs.existsSync(envFile)) dotenv.config({ path: envFile, quiet: true });
  const e = process.env;
  const nodeEnv = (e.NODE_ENV === "production" ? "production" : e.NODE_ENV === "test" ? "test" : "development") as AppConfig["nodeEnv"];
  const dataDir = path.resolve(BACKEND_ROOT, e.DATA_DIR ?? "data");
  const base: AppConfig = {
    nodeEnv,
    port: int(e.PORT, 4000),
    host: e.HOST ?? "0.0.0.0",
    dataDir,
    dbPath: path.join(dataDir, "coldchain.db"),
    sandboxDbPath: path.join(dataDir, "sandbox.db"),
    checkpointDir: path.join(dataDir, "checkpoints"),
    sandboxCheckpointDir: path.join(dataDir, "sandbox-checkpoints"),
    migrationsDir: path.join(BACKEND_ROOT, "migrations"),
    frontendOrigin: e.FRONTEND_ORIGIN ?? "http://localhost:5173",
    serveFrontend: bool(e.SERVE_FRONTEND, false),
    frontendDist: path.resolve(BACKEND_ROOT, "..", "frontend", "dist"),
    deviceSecretKey: Buffer.alloc(0),
    checkpointKey: Buffer.alloc(0),
    checkpointEvery: int(e.CHECKPOINT_EVERY, 10),
    sessionTtlHours: int(e.SESSION_TTL_HOURS, 12),
    cookieSecure: bool(e.COOKIE_SECURE, nodeEnv === "production"),
    enableDevEndpoints: nodeEnv !== "production" && bool(e.ENABLE_DEV_ENDPOINTS, true),
    loginRateMax: int(e.LOGIN_RATE_MAX, 10),
    loginRateWindowMs: 15 * 60 * 1000,
    ingestRateMax: int(e.INGEST_RATE_MAX, 300),
    ingestRateWindowMs: 60 * 1000,
    staleCheckIntervalMs: int(e.STALE_CHECK_INTERVAL_MS, 10_000),
    trustProxy: bool(e.TRUST_PROXY, false),
    logLevel: (e.LOG_LEVEL as AppConfig["logLevel"]) ?? (nodeEnv === "test" ? "silent" : "info"),
  };
  const merged = { ...base, ...overrides };
  if (!overrides.deviceSecretKey) merged.deviceSecretKey = hexKey("DEVICE_SECRET_ENC_KEY", e.DEVICE_SECRET_ENC_KEY, nodeEnv);
  if (!overrides.checkpointKey) merged.checkpointKey = hexKey("CHECKPOINT_SIGNING_KEY", e.CHECKPOINT_SIGNING_KEY, nodeEnv);
  // Dev endpoints can never be enabled in production, even by override.
  if (merged.nodeEnv === "production") merged.enableDevEndpoints = false;
  return merged;
}
