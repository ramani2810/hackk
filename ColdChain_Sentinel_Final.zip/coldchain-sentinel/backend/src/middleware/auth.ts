import type { NextFunction, Request, RequestHandler, Response } from "express";
import type { AppContext } from "../context";
import { AppError, forbidden, unauthorized } from "../lib/errors";
import { COOKIE_NAME, sessionUser, type Role } from "../services/auth";

export const CSRF_HEADER = "x-requested-with";
export const CSRF_VALUE = "ColdChainSentinel";

export function allowedOrigins(ctx: AppContext): string[] {
  const p = ctx.config.port;
  return Array.from(new Set([ctx.config.frontendOrigin, `http://localhost:${p}`, `http://127.0.0.1:${p}`, "http://localhost:5173", "http://127.0.0.1:5173"]));
}

/**
 * CSRF defence for cookie-authenticated, state-changing requests (defence in depth on top of SameSite=Lax cookies):
 *  1. a custom header that browsers will not add to cross-site requests without a successful CORS preflight, and
 *  2. if an Origin header is present it must be one we trust.
 */
export function csrfGuard(ctx: AppContext): RequestHandler {
  const allowed = new Set(allowedOrigins(ctx));
  return (req, _res, next) => {
    if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
    if (req.get(CSRF_HEADER) !== CSRF_VALUE) return next(new AppError(403, "CSRF_REJECTED", "Missing anti-CSRF header"));
    const origin = req.get("origin");
    if (origin && !allowed.has(origin) && origin !== `${req.protocol}://${req.get("host")}`) {
      return next(new AppError(403, "CSRF_REJECTED", "Request origin is not allowed"));
    }
    next();
  };
}

export function loadUser(ctx: AppContext): RequestHandler {
  return (req, _res, next) => {
    const token = (req.cookies as Record<string, string> | undefined)?.[COOKIE_NAME];
    req.user = sessionUser(ctx, token) ?? undefined;
    next();
  };
}

export const requireAuth: RequestHandler = (req, _res, next) => {
  if (!req.user) return next(unauthorized());
  next();
};

export function requireRole(role: Role): RequestHandler {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(unauthorized());
    if (role === "ADMIN" && req.user.role !== "ADMIN") return next(forbidden("Administrator role required"));
    next();
  };
}

export function devOnly(ctx: AppContext): RequestHandler {
  return (_req, _res, next) => {
    if (!ctx.config.enableDevEndpoints) {
      return next(new AppError(404, "DEV_ENDPOINTS_DISABLED", "Development endpoints are disabled in this environment"));
    }
    next();
  };
}

export const actorOf = (req: Request) => ({ id: req.user?.id ?? null, label: req.user ? `${req.user.email} (${req.user.role})` : "anonymous" });
