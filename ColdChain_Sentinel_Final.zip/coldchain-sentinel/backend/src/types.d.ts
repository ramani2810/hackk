import type { SessionUser } from "./services/auth";

declare global {
  namespace Express {
    interface Request {
      user?: SessionUser;
      rawBody?: Buffer;
    }
  }
}
export {};
