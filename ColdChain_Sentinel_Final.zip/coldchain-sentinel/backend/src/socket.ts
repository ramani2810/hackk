import type { Server as HttpServer } from "node:http";
import { parseCookie } from "cookie";
import { Server } from "socket.io";
import type { AppContext } from "./context";
import { allowedOrigins } from "./middleware/auth";
import { COOKIE_NAME, sessionUser } from "./services/auth";

/** Live updates. Sockets are authenticated with the same session cookie as the REST API. */
export function attachSocket(server: HttpServer, ctx: AppContext): Server {
  const io = new Server(server, { cors: { origin: allowedOrigins(ctx), credentials: true }, serveClient: false });
  io.use((socket, next) => {
    const cookies = parseCookie(socket.handshake.headers.cookie ?? "");
    const user = sessionUser(ctx, cookies[COOKIE_NAME]);
    if (!user) return next(new Error("unauthorized"));
    (socket.data as { user?: unknown }).user = user;
    next();
  });
  io.on("connection", (socket) => {
    void socket.join("authed");
    socket.emit("hello", { serverTime: ctx.now() });
  });
  ctx.bus.subscribe((event, payload) => io.to("authed").emit(event, payload));
  return io;
}
