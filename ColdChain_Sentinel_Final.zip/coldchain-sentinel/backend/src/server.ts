import http from "node:http";
import { createApp } from "./app";
import { loadConfig } from "./config";
import { createContext } from "./context";
import { get } from "./db/index";
import { SYSTEM_ACTOR } from "./services/audit";
import { ensureSimulatedDevices } from "./services/devices";
import { startMonitor } from "./services/monitor";
import { resetSandbox } from "./services/sandbox";
import { attachSocket } from "./socket";

async function main() {
  const config = loadConfig();
  const ctx = await createContext(config);
  const app = createApp(ctx);
  const server = http.createServer(app);
  attachSocket(server, ctx);
  const stopMonitor = startMonitor(ctx);

  if (config.enableDevEndpoints) {
    ensureSimulatedDevices(ctx);
    if (!get(ctx.sandbox.db, "SELECT 1 AS x FROM readings LIMIT 1")) resetSandbox(ctx, SYSTEM_ACTOR);
  }
  const users = get<{ c: number }>(ctx.live.db, "SELECT COUNT(*) AS c FROM users")!.c;

  server.on("error", (err: NodeJS.ErrnoException) => {
    if (err.code === "EADDRINUSE") {
      console.error(`\nPort ${config.port} is already in use. Close the other program (or an older copy of this server) or change PORT in backend/.env.\n`);
    } else console.error(err);
    process.exit(1);
  });

  server.listen(config.port, config.host, () => {
    console.log("");
    console.log("  ColdChain Sentinel backend is running");
    console.log(`  - API:          http://localhost:${config.port}/api/v1`);
    console.log(`  - Health check: http://localhost:${config.port}/api/v1/health`);
    console.log(`  - Environment:  ${config.nodeEnv}   Dev endpoints: ${config.enableDevEndpoints ? "ENABLED (simulator + tamper sandbox)" : "disabled"}`);
    console.log(`  - Database:     ${config.dbPath}`);
    console.log(`  - Listening on: ${config.host}:${config.port} (reachable from your LAN for ESP32 devices)`);
    if (users === 0) console.log("\n  ! No users exist yet. Run:  npm run db:seed   (creates the development admin/viewer accounts)\n");
    else console.log("");
  });

  const shutdown = (sig: string) => {
    console.log(`\n${sig} received, shutting down...`);
    stopMonitor();
    server.close(() => { ctx.close(); process.exit(0); });
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
}

main().catch((err) => {
  console.error("\nFailed to start:", (err as Error).message, "\n");
  process.exit(1);
});
