const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 99 } as const;
type Level = keyof typeof LEVELS;

const SENSITIVE = /(secret|password|token|signature|authorization|cookie|key|hmac)/i;

/** Recursively replaces values of sensitive-looking keys so secrets never reach ordinary logs. */
export function redact(value: unknown, depth = 0): unknown {
  if (depth > 5 || value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1));
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    out[k] = SENSITIVE.test(k) ? "[REDACTED]" : redact(v, depth + 1);
  }
  return out;
}

export interface Logger {
  debug(msg: string, meta?: unknown): void;
  info(msg: string, meta?: unknown): void;
  warn(msg: string, meta?: unknown): void;
  error(msg: string, meta?: unknown): void;
}

export function createLogger(level: Level = "info"): Logger {
  const min = LEVELS[level];
  const emit = (lvl: Exclude<Level, "silent">, msg: string, meta?: unknown) => {
    if (LEVELS[lvl] < min) return;
    const line = `${new Date().toISOString()} ${lvl.toUpperCase().padEnd(5)} ${msg}`;
    const fn = lvl === "error" ? console.error : lvl === "warn" ? console.warn : console.log;
    if (meta === undefined) fn(line);
    else fn(line, JSON.stringify(redact(meta)));
  };
  return {
    debug: (m, x) => emit("debug", m, x),
    info: (m, x) => emit("info", m, x),
    warn: (m, x) => emit("warn", m, x),
    error: (m, x) => emit("error", m, x),
  };
}
