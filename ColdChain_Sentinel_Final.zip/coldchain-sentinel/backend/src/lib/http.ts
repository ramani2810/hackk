import type { NextFunction, Request, Response } from "express";
import { z } from "zod";
import { AppError } from "./errors";
import type { Logger } from "./logger";

export function parse<T extends z.ZodType>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data);
  if (!r.success) {
    throw new AppError(400, "VALIDATION_ERROR", "Request validation failed", r.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })));
  }
  return r.data;
}

export const pageQuery = z.object({
  page: z.coerce.number().int().min(1).max(100000).default(1),
  pageSize: z.coerce.number().int().min(1).max(1000).default(50),
});

export const isoOpt = z.iso.datetime({ offset: true }).optional();

export function errorHandler(log: Logger) {
  return (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof AppError) {
      res.status(err.status).json({ error: { code: err.code, message: err.message, ...(err.details !== undefined ? { details: err.details } : {}) } });
      return;
    }
    const e = err as { type?: string; status?: number; statusCode?: number; message?: string };
    if (e?.type === "entity.too.large") {
      res.status(413).json({ error: { code: "PAYLOAD_TOO_LARGE", message: "Request body is too large" } });
      return;
    }
    if (e?.type === "entity.parse.failed" || err instanceof SyntaxError) {
      res.status(400).json({ error: { code: "INVALID_JSON", message: "Request body is not valid JSON" } });
      return;
    }
    if (typeof e?.status === "number" && e.status >= 400 && e.status < 500) {
      res.status(e.status).json({ error: { code: "BAD_REQUEST", message: e.message ?? "Bad request" } });
      return;
    }
    log.error("unhandled error", { message: (err as Error)?.message, stack: (err as Error)?.stack });
    res.status(500).json({ error: { code: "INTERNAL_ERROR", message: "Internal server error" } });
  };
}
