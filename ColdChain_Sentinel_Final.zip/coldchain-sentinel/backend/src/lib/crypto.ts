import crypto from "node:crypto";

/** SHA-256 is a cryptographic HASH function (a one-way fingerprint). It is not encryption. */
export function sha256Hex(data: string | Buffer): string {
  return crypto.createHash("sha256").update(data).digest("hex");
}

export function hmacSha256Hex(key: Buffer | string, data: string | Buffer): string {
  return crypto.createHmac("sha256", key).update(data).digest("hex");
}

export function timingSafeEqualHex(a: string, b: string): boolean {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const ba = Buffer.from(a, "utf8");
  const bb = Buffer.from(b, "utf8");
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

export function randomHex(bytes = 32): string {
  return crypto.randomBytes(bytes).toString("hex");
}

export function newId(prefix = ""): string {
  return prefix + crypto.randomUUID();
}

/**
 * Deterministic canonical JSON: object keys sorted lexicographically, no whitespace,
 * strings escaped by JSON.stringify. Only strings, finite integers, booleans, null,
 * arrays and plain objects are allowed (floats must be pre-encoded as strings by the caller).
 */
export function canonicalize(value: unknown): string {
  if (value === null) return "null";
  switch (typeof value) {
    case "string":
      return JSON.stringify(value);
    case "boolean":
      return value ? "true" : "false";
    case "number":
      if (!Number.isInteger(value)) throw new Error("canonicalize: non-integer numbers must be encoded as strings");
      return String(value);
    case "object": {
      if (Array.isArray(value)) return "[" + value.map(canonicalize).join(",") + "]";
      const obj = value as Record<string, unknown>;
      const keys = Object.keys(obj).sort();
      return (
        "{" +
        keys
          .map((k) => {
            if (obj[k] === undefined) throw new Error(`canonicalize: undefined value for key ${k}`);
            return JSON.stringify(k) + ":" + canonicalize(obj[k]);
          })
          .join(",") +
        "}"
      );
    }
    default:
      throw new Error(`canonicalize: unsupported type ${typeof value}`);
  }
}

/* ---------- Ledger record hashing ---------- */

export const RECORD_HASH_VERSION = 1;
const RECORD_DOMAIN = "coldchain-sentinel/record/v1\n";
const GENESIS_DOMAIN = "coldchain-sentinel/genesis/v1:";

/** Documented genesis value: the "previous hash" of the first record of each device chain. */
export function genesisHash(deviceId: string): string {
  return sha256Hex(GENESIS_DOMAIN + deviceId);
}

export interface HashableRecord {
  id: string;
  deviceId: string;
  sequence: number;
  temperatureC: number | null;
  humidityPct: number | null;
  sensorStatus: string;
  deviceTimestamp: string | null;
  receivedAt: string;
  source: string;
  firmwareVersion: string | null;
  shipmentId: string | null;
  gapBefore: number;
  previousHash: string;
}

/** Fixed-precision decimal encoding so that float formatting can never change a hash. */
export function encodeTemperature(t: number | null): string | null {
  return t === null ? null : t.toFixed(3);
}
export function encodeHumidity(h: number | null): string | null {
  return h === null ? null : h.toFixed(1);
}

export function canonicalRecord(r: HashableRecord): string {
  return canonicalize({
    v: RECORD_HASH_VERSION,
    id: r.id,
    deviceId: r.deviceId,
    sequence: r.sequence,
    temperatureC: encodeTemperature(r.temperatureC),
    humidityPct: encodeHumidity(r.humidityPct),
    sensorStatus: r.sensorStatus,
    deviceTimestamp: r.deviceTimestamp,
    receivedAt: r.receivedAt,
    source: r.source,
    firmwareVersion: r.firmwareVersion,
    shipmentId: r.shipmentId,
    gapBefore: r.gapBefore,
    previousHash: r.previousHash,
  });
}

export function computeRecordHash(r: HashableRecord): string {
  return sha256Hex(RECORD_DOMAIN + canonicalRecord(r));
}

/* ---------- Secrets at rest (AES-256-GCM) ---------- */

export function encryptSecret(key: Buffer, plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return ["v1", iv.toString("base64"), tag.toString("base64"), ct.toString("base64")].join(":");
}

export function decryptSecret(key: Buffer, blob: string): string {
  const [v, iv, tag, ct] = blob.split(":");
  if (v !== "v1" || !iv || !tag || !ct) throw new Error("Unsupported secret format");
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(ct, "base64")), decipher.final()]).toString("utf8");
}

/* ---------- Passwords (scrypt) ---------- */

const SCRYPT = { N: 16384, r: 8, p: 1, keylen: 64 };

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const dk = crypto.scryptSync(password, salt, SCRYPT.keylen, { N: SCRYPT.N, r: SCRYPT.r, p: SCRYPT.p });
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString("base64")}$${dk.toString("base64")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash!, "base64");
  const dk = crypto.scryptSync(password, Buffer.from(salt!, "base64"), expected.length, {
    N: Number(n),
    r: Number(r),
    p: Number(p),
  });
  return dk.length === expected.length && crypto.timingSafeEqual(dk, expected);
}

export const DUMMY_PASSWORD_HASH = hashPassword("not-a-real-password-for-timing-equalisation");
