import fs from "node:fs";
import path from "node:path";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { type Express } from "express";
import helmet from "helmet";
import type { AppContext } from "./context";
import { AppError } from "./lib/errors";
import { errorHandler } from "./lib/http";
import { allowedOrigins, csrfGuard, loadUser } from "./middleware/auth";
import { adminRouter } from "./routes/admin";
import { alertsRouter } from "./routes/alerts";
import { authRouter } from "./routes/auth";
import { devRouter } from "./routes/dev";
import { devicesRouter } from "./routes/devices";
import { ledgerRouter } from "./routes/ledger";
import { deviceIngestRouter, readingsRouter } from "./routes/readings";
import { reportsRouter } from "./routes/reports";
import { shipmentsRouter } from "./routes/shipments";

export const API_VERSION = "1.0.0";

export function createApp(ctx: AppContext): Express {
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", ctx.config.trustProxy);
  app.use(helmet({ crossOriginEmbedderPolicy: false }));
  app.use(cors({ origin: allowedOrigins(ctx), credentials: true, allowedHeaders: ["Content-Type", "X-Requested-With", "X-Device-Id", "X-Signature"] }));
  // Small body limit; the raw bytes are kept because the device HMAC is computed over them.
  app.use(express.json({ limit: "8kb", verify: (req, _res, buf) => { (req as express.Request).rawBody = Buffer.from(buf); } }));
  app.use(cookieParser());

  const api = express.Router();
  api.get("/health", (_req, res) => {
    let db = "ok";
    try { ctx.live.db.prepare("SELECT 1").get(); } catch { db = "error"; }
    res.status(db === "ok" ? 200 : 503).json({ status: db === "ok" ? "ok" : "degraded", service: "coldchain-sentinel", version: API_VERSION, time: ctx.now(), database: db, environment: ctx.config.nodeEnv });
  });

  // Device ingestion first: HMAC-authenticated, no cookies, no CSRF header.
  api.use(deviceIngestRouter(ctx));

  api.use(loadUser(ctx));
  api.use(csrfGuard(ctx));
  api.use(authRouter(ctx));
  api.use(readingsRouter(ctx));
  api.use(devicesRouter(ctx));
  api.use(ledgerRouter(ctx));
  api.use(alertsRouter(ctx));
  api.use(shipmentsRouter(ctx));
  api.use(reportsRouter(ctx));
  api.use(adminRouter(ctx));
  api.use(devRouter(ctx));
  api.use((_req, _res, next) => next(new AppError(404, "NOT_FOUND", "Endpoint not found")));
  app.use("/api/v1", api);

  if (ctx.config.serveFrontend && fs.existsSync(path.join(ctx.config.frontendDist, "index.html"))) {
    app.use(express.static(ctx.config.frontendDist, { index: false, maxAge: "1h" }));
    app.use((req, res, next) => {
      if (req.method !== "GET" || req.path.startsWith("/api/") || req.path.startsWith("/socket.io")) return next();
      res.sendFile(path.join(ctx.config.frontendDist, "index.html"));
    });
  }

  app.use((_req, _res, next) => next(new AppError(404, "NOT_FOUND", "Not found")));
  app.use(errorHandler(ctx.log));
  return app;
}
