import { Router } from "express";
import { z } from "zod";
import type { AppContext } from "../context";
import { isoOpt, parse } from "../lib/http";
import { actorOf, requireAuth } from "../middleware/auth";
import { audit } from "../services/audit";
import { incidentsReport, ledgerReport, shipmentReport, temperatureReport, type ReportOut } from "../services/reports";

const filters = z.object({
  deviceId: z.string().max(40).optional(), shipmentId: z.string().max(40).optional(), from: isoOpt, to: isoOpt,
  format: z.enum(["csv", "json"]).default("csv"), category: z.enum(["TEMPERATURE", "SECURITY"]).optional(), scope: z.enum(["LIVE", "SANDBOX"]).optional(),
});

export function reportsRouter(ctx: AppContext): Router {
  const r = Router();
  const send = (req: Parameters<Parameters<Router["get"]>[1]>[0], res: Parameters<Parameters<Router["get"]>[1]>[1], kind: string, out: ReportOut, details: object) => {
    audit(ctx, { actor: actorOf(req), action: "report.export", targetType: "report", targetId: kind, details: { ...details, filename: out.filename }, ip: req.ip });
    res.setHeader("Content-Type", out.contentType);
    res.setHeader("Content-Disposition", `attachment; filename="${out.filename}"`);
    res.setHeader("Cache-Control", "no-store");
    res.send(out.body);
  };
  r.get("/reports/temperature", requireAuth, (req, res) => { const f = parse(filters, req.query); send(req, res, "temperature", temperatureReport(ctx, f, f.format), f); });
  r.get("/reports/ledger", requireAuth, (req, res) => { const f = parse(filters, req.query); send(req, res, "ledger", ledgerReport(ctx, f, f.format), f); });
  r.get("/reports/incidents", requireAuth, (req, res) => { const f = parse(filters, req.query); send(req, res, "incidents", incidentsReport(ctx, f, f.format), f); });
  r.get("/reports/shipments/:id", requireAuth, (req, res) => { const f = parse(filters, req.query); send(req, res, "shipment", shipmentReport(ctx, String(req.params.id), f.format), { shipmentId: req.params.id, format: f.format }); });
  return r;
}
