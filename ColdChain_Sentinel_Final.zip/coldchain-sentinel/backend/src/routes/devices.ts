import { Router } from "express";
import { z } from "zod";
import type { AppContext } from "../context";
import { notFound } from "../lib/errors";
import { parse } from "../lib/http";
import { actorOf, requireAuth, requireRole } from "../middleware/auth";
import { createDevice, deviceDto, getDeviceRow, listDevices, revokeCredential, rotateCredential } from "../services/devices";

const createSchema = z.object({
  id: z.string().min(3).max(40), name: z.string().min(1).max(80), type: z.enum(["ESP32", "SIMULATED"]), description: z.string().max(300).nullish(),
}).strict();

export function devicesRouter(ctx: AppContext): Router {
  const r = Router();
  r.get("/devices", requireAuth, (_req, res) => res.json({ items: listDevices(ctx) }));

  r.get("/devices/:id", requireAuth, (req, res) => {
    const d = getDeviceRow(ctx, String(req.params.id));
    if (!d || d.type === "SANDBOX") throw notFound("Device");
    res.json(deviceDto(ctx, d));
  });

  r.post("/devices", requireRole("ADMIN"), (req, res) => {
    const body = parse(createSchema, req.body);
    const out = createDevice(ctx, { ...body, description: body.description ?? null }, actorOf(req), req.ip);
    res.status(201).json({
      device: out.device,
      secret: out.secret,
      secretNotice: out.secret ? "This device secret is shown ONCE. Copy it into the firmware configuration now; it cannot be retrieved later (rotate the credential if lost)." : null,
    });
  });

  r.post("/devices/:id/revoke", requireRole("ADMIN"), (req, res) => {
    res.json({ device: revokeCredential(ctx, String(req.params.id), actorOf(req), req.ip) });
  });

  r.post("/devices/:id/rotate", requireRole("ADMIN"), (req, res) => {
    const out = rotateCredential(ctx, String(req.params.id), actorOf(req), req.ip);
    res.json({ device: out.device, secret: out.secret, secretNotice: "New secret shown ONCE. The previous secret no longer works." });
  });
  return r;
}
