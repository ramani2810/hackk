import { Router } from "express";
import { z } from "zod";
import type { AppContext } from "../context";
import { isoOpt, pageQuery, parse } from "../lib/http";
import { actorOf, requireAuth, requireRole } from "../middleware/auth";
import { audit } from "../services/audit";
import { acknowledgeAlert, alertCounts, listAlerts, resolveAlert } from "../services/alerts";

const q = pageQuery.extend({
  category: z.enum(["TEMPERATURE", "SECURITY"]).optional(), status: z.enum(["OPEN", "RESOLVED"]).optional(),
  severity: z.enum(["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"]).optional(), deviceId: z.string().max(40).optional(),
  scope: z.enum(["LIVE", "SANDBOX"]).default("LIVE"), kind: z.string().max(40).optional(), from: isoOpt, to: isoOpt,
}).transform((x) => ({ ...x, pageSize: Math.min(x.pageSize, 200) }));

export function alertsRouter(ctx: AppContext): Router {
  const r = Router();
  r.get("/alerts", requireAuth, (req, res) => res.json(listAlerts(ctx, parse(q, req.query))));
  r.get("/alerts/summary", requireAuth, (req, res) => res.json(alertCounts(ctx, req.query.scope === "SANDBOX" ? "SANDBOX" : "LIVE")));
  r.patch("/alerts/:id/acknowledge", requireRole("ADMIN"), (req, res) => {
    const a = acknowledgeAlert(ctx, String(req.params.id), actorOf(req).label);
    audit(ctx, { actor: actorOf(req), action: "alert.acknowledge", targetType: "alert", targetId: a.id, scope: a.scope, details: { kind: a.kind }, ip: req.ip });
    res.json(a);
  });
  r.patch("/alerts/:id/resolve", requireRole("ADMIN"), (req, res) => {
    const { note } = parse(z.object({ note: z.string().min(1).max(500) }).strict(), req.body);
    const a = resolveAlert(ctx, String(req.params.id), actorOf(req).label, note);
    audit(ctx, { actor: actorOf(req), action: "alert.resolve", targetType: "alert", targetId: a.id, scope: a.scope, details: { kind: a.kind, note }, ip: req.ip });
    res.json(a);
  });
  return r;
}
