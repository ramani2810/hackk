import { Router } from "express";
import { z } from "zod";
import { all, get } from "../db/index";
import type { AppContext } from "../context";
import { AppError, notFound } from "../lib/errors";
import { isoOpt, pageQuery, parse } from "../lib/http";
import { actorOf, requireAuth, requireRole } from "../middleware/auth";
import { audit } from "../services/audit";
import { createCheckpointFor, getRun, latestRun, listRuns, runVerification } from "../services/integrity";
import { listReadings } from "../services/readings";
import { discoverDeviceIds } from "../services/verifier";
import { getTail } from "../services/ledger";

const ledgerQuery = pageQuery.extend({
  deviceId: z.string().max(40).optional(), q: z.string().max(80).optional(), from: isoOpt, to: isoOpt,
  status: z.enum(["VERIFIED", "UNVERIFIED", "INVALID_HASH", "BROKEN_LINK", "MISSING_RECORD", "SEQUENCE_GAP", "REORDERED", "CHECKPOINT_MISMATCH"]).optional(),
  source: z.enum(["HARDWARE", "SIMULATOR", "SANDBOX"]).optional(), order: z.enum(["asc", "desc"]).default("desc"),
}).transform((q) => ({ ...q, pageSize: Math.min(q.pageSize, 200) }));

const verifySchema = z.object({ scope: z.enum(["LEDGER", "DEVICE", "RANGE"]), deviceId: z.string().max(40).optional(), from: isoOpt, to: isoOpt }).strict()
  .superRefine((v, c) => {
    if (v.scope === "DEVICE" && !v.deviceId) c.addIssue({ code: "custom", path: ["deviceId"], message: "deviceId is required for scope DEVICE" });
    if (v.scope === "RANGE" && !v.from && !v.to) c.addIssue({ code: "custom", path: ["from"], message: "from and/or to is required for scope RANGE" });
  });

export function ledgerRouter(ctx: AppContext): Router {
  const r = Router();
  const ds = ctx.live;

  r.get("/ledger", requireAuth, (req, res) => res.json(listReadings(ds, parse(ledgerQuery, req.query))));

  r.get("/ledger/summary", requireAuth, (_req, res) => {
    const total = get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM readings")!.c;
    const run = latestRun(ds);
    const since = run ? get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM readings WHERE received_at > ?", run.finishedAt)!.c : total;
    const verified = get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM record_integrity i JOIN readings r ON r.id = i.record_id WHERE i.status = 'VERIFIED'")!.c;
    const failed = get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM record_integrity i JOIN readings r ON r.id = i.record_id WHERE i.status <> 'VERIFIED'")!.c;
    const latest = listReadings(ds, { order: "desc", page: 1, pageSize: 1 }).items[0] ?? null;
    const chains = discoverDeviceIds(ds.db, ds.checkpoints).map((id) => {
      const tail = getTail(ds.db, id);
      const cp = ds.checkpoints.latest(id);
      return {
        deviceId: id, records: get<{ c: number }>(ds.db, "SELECT COUNT(*) AS c FROM readings WHERE device_id = ?", id)!.c,
        headSequence: tail?.sequence ?? null, headHash: tail?.hash ?? null,
        lastCheckpoint: cp ? { id: cp.id, lastSequence: cp.lastSequence, createdAt: cp.createdAt, headHash: cp.headHash } : null,
      };
    });
    res.json({
      totalRecords: total, verifiedRecords: verified, failedRecords: failed, unverifiedRecords: Math.max(0, total - verified - failed),
      latestRecord: latest, chains,
      chainStatus: run
        ? { status: run.status, lastVerifiedAt: run.finishedAt, runId: run.id, scope: run.scope, deviceId: run.deviceId, recordsChecked: run.recordsChecked, newRecordsSinceVerification: since, failureCounts: run.failureCounts }
        : { status: "NEVER_VERIFIED", lastVerifiedAt: null, runId: null, scope: null, deviceId: null, recordsChecked: 0, newRecordsSinceVerification: total, failureCounts: {} },
      checkpointInfo: {
        keyId: ds.checkpoints.keyId, every: ctx.config.checkpointEvery,
        storage: "Append-only files outside the database (backend/data/checkpoints), signed with HMAC-SHA-256 using CHECKPOINT_SIGNING_KEY from the environment.",
        limitation: "Checkpoints live on the same machine as the database in this prototype. Copy them to an independent system for protection against an attacker who controls the whole server. Records after the newest checkpoint are protected only by the hash chain.",
      },
    });
  });

  r.post("/ledger/verify", requireRole("ADMIN"), (req, res) => {
    const body = parse(verifySchema, req.body);
    if (body.deviceId && !get(ds.db, "SELECT 1 AS x FROM devices WHERE id = ?", body.deviceId)) throw notFound("Device");
    res.json(runVerification(ctx, ds, body, actorOf(req), req.ip));
  });

  r.get("/ledger/verifications", requireAuth, (req, res) => {
    const limit = Math.min(100, Number(req.query.limit) || 20);
    res.json({ items: listRuns(ds, limit).map((x) => ({ ...x, failures: x.failures.slice(0, 20) })) });
  });
  r.get("/ledger/verifications/:id", requireAuth, (req, res) => {
    const run = getRun(ds, String(req.params.id));
    if (!run) throw notFound("Verification run");
    res.json(run);
  });

  r.get("/ledger/checkpoints", requireAuth, (req, res) => {
    const deviceId = typeof req.query.deviceId === "string" ? req.query.deviceId : undefined;
    const ids = deviceId ? [deviceId] : discoverDeviceIds(ds.db, ds.checkpoints);
    res.json({
      keyId: ds.checkpoints.keyId,
      items: ids.map((id) => {
        const st = ds.checkpoints.read(id);
        return { deviceId: id, fileExists: st.exists, checkpoints: st.checkpoints, problems: st.problems };
      }),
    });
  });

  r.post("/ledger/checkpoints", requireRole("ADMIN"), (req, res) => {
    const { deviceId } = parse(z.object({ deviceId: z.string().max(40) }).strict(), req.body);
    if (!get(ds.db, "SELECT 1 AS x FROM devices WHERE id = ?", deviceId)) throw notFound("Device");
    try {
      const cp = createCheckpointFor(ctx, ds, deviceId);
      audit(ctx, { actor: actorOf(req), action: "ledger.checkpoint", targetType: "device", targetId: deviceId, details: { checkpointId: cp.id, lastSequence: cp.lastSequence }, ip: req.ip });
      res.status(201).json(cp);
    } catch (e) {
      if (e instanceof AppError) throw e;
      throw e;
    }
  });
  void all;
  return r;
}
