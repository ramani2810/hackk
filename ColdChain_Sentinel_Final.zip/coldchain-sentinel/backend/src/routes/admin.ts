import { Router } from "express";
import { z } from "zod";
import type { AppContext } from "../context";
import { pageQuery, parse } from "../lib/http";
import { actorOf, requireAuth, requireRole } from "../middleware/auth";
import { audit, listAudit } from "../services/audit";
import { createUser, listUsers, setUserDisabled } from "../services/auth";
import { overview } from "../services/overview";
import { getSettings, updateSettings } from "../services/settings";
import { AppError } from "../lib/errors";

const settingsPatch = z.object({
  tempMinC: z.number().min(-100).max(100).optional(), tempMaxC: z.number().min(-100).max(100).optional(),
  staleSeconds: z.number().int().min(5).max(86400).optional(), recoveryReadings: z.number().int().min(1).max(20).optional(),
  simulatorIntervalSec: z.number().int().min(1).max(60).optional(),
}).strict();

export function adminRouter(ctx: AppContext): Router {
  const r = Router();

  r.get("/overview", requireAuth, (_req, res) => res.json(overview(ctx)));

  r.get("/settings", requireAuth, (_req, res) => res.json(getSettings(ctx.live.db)));
  r.patch("/settings", requireRole("ADMIN"), (req, res) => {
    const patch = parse(settingsPatch, req.body);
    const cur = getSettings(ctx.live.db);
    const min = patch.tempMinC ?? cur.tempMinC;
    const max = patch.tempMaxC ?? cur.tempMaxC;
    if (!(min < max)) throw new AppError(400, "BAD_RANGE", "Minimum temperature must be lower than maximum");
    const next = updateSettings(ctx.live.db, patch);
    audit(ctx, { actor: actorOf(req), action: "settings.update", targetType: "settings", details: { before: cur, after: next }, ip: req.ip });
    ctx.bus.publish("settings:updated", next);
    res.json(next);
  });

  r.get("/audit", requireRole("ADMIN"), (req, res) => {
    const q = parse(pageQuery.extend({ action: z.string().max(60).optional(), actor: z.string().max(80).optional(), scope: z.enum(["LIVE", "SANDBOX"]).optional() }), req.query);
    res.json(listAudit(ctx, q));
  });

  r.get("/users", requireRole("ADMIN"), (_req, res) => res.json({ items: listUsers(ctx) }));
  r.post("/users", requireRole("ADMIN"), (req, res) => {
    const body = parse(z.object({ email: z.string().email().max(200), name: z.string().min(1).max(80), role: z.enum(["ADMIN", "VIEWER"]), password: z.string().min(10).max(200) }).strict(), req.body);
    const u = createUser(ctx, body);
    audit(ctx, { actor: actorOf(req), action: "user.create", targetType: "user", targetId: u.id, details: { email: u.email, role: u.role }, ip: req.ip });
    res.status(201).json(u);
  });
  r.patch("/users/:id", requireRole("ADMIN"), (req, res) => {
    const { disabled } = parse(z.object({ disabled: z.boolean() }).strict(), req.body);
    if (req.user!.id === req.params.id && disabled) throw new AppError(409, "SELF_DISABLE", "You cannot disable your own account");
    const u = setUserDisabled(ctx, String(req.params.id), disabled);
    audit(ctx, { actor: actorOf(req), action: disabled ? "user.disable" : "user.enable", targetType: "user", targetId: u.id, ip: req.ip });
    res.json(u);
  });
  return r;
}
