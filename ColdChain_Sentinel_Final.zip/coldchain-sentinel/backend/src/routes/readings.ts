import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import type { AppContext } from "../context";
import { AppError, notFound } from "../lib/errors";
import { isoOpt, pageQuery, parse } from "../lib/http";
import { raiseAlert } from "../services/alerts";
import { authenticateDevice, type AuthFailureReason } from "../services/devices";
import { ingestReading, readingSchema } from "../services/ingest";
import { getReadingDetail, listReadings } from "../services/readings";
import { requireAuth } from "../middleware/auth";

const WINDOW_MS = 5 * 60_000;

function recordAuthFailure(ctx: AppContext, ip: string, headerDeviceId: string | undefined, reason: AuthFailureReason) {
  const key = `${headerDeviceId ?? "-"}|${ip}`;
  const nowMs = Date.now();
  if (ctx.authFailures.size > 5000) for (const [k, v] of ctx.authFailures) if (nowMs - v.first > WINDOW_MS) ctx.authFailures.delete(k);
  let e = ctx.authFailures.get(key);
  if (!e || nowMs - e.first > WINDOW_MS) e = { count: 0, first: nowMs };
  e.count++;
  ctx.authFailures.set(key, e);
  const known = reason !== "UNKNOWN_DEVICE";
  // Alerts are keyed by the real device (if it exists) or by source IP, so attackers cannot create unbounded alerts by inventing device IDs.
  const subject = known ? headerDeviceId! : `ip:${ip}`;
  raiseAlert(ctx, {
    kind: "INVALID_DEVICE_AUTH", severity: reason === "REVOKED" ? "HIGH" : "MEDIUM", deviceId: known ? headerDeviceId : null,
    dedupeKey: `auth-fail:${subject}`,
    title: reason === "REVOKED" ? "Revoked device credential was used" : "Device authentication failed",
    description: reason === "REVOKED"
      ? `A request signed for device ${headerDeviceId} was rejected because that device's credential has been revoked.`
      : `A request to the ingestion endpoint was rejected (${reason.replace("_", " ").toLowerCase()}) ${known ? `for device ${headerDeviceId}` : `from ${ip}`}. ${e.count} failure(s) in the last 5 minutes.`,
    details: { reason, sourceIp: ip, failuresInWindow: e.count },
  });
  if (e.count >= 5) {
    raiseAlert(ctx, {
      kind: "REPEATED_FAILED_REQUESTS", severity: "HIGH", deviceId: known ? headerDeviceId : null, dedupeKey: `auth-repeat:${subject}`,
      title: "Repeated failed ingestion requests",
      description: `${e.count} failed authentication attempts from ${ip} within 5 minutes. This may be a misconfigured device secret or a guessing attack.`,
      details: { sourceIp: ip, failuresInWindow: e.count, reason },
    });
  }
}

/** Device-authenticated ingestion endpoint. Mounted BEFORE the cookie/CSRF stack: devices use HMAC signatures, not cookies. */
export function deviceIngestRouter(ctx: AppContext): Router {
  const r = Router();
  const general = rateLimit({
    windowMs: ctx.config.ingestRateWindowMs, limit: ctx.config.ingestRateMax, standardHeaders: "draft-7", legacyHeaders: false,
    message: { error: { code: "RATE_LIMITED", message: "Too many requests" } },
  });
  const failures = rateLimit({
    windowMs: WINDOW_MS, limit: 30, skipSuccessfulRequests: true, standardHeaders: "draft-7", legacyHeaders: false,
    message: { error: { code: "RATE_LIMITED", message: "Too many failed requests" } },
  });
  r.post("/readings", failures, general, (req, res) => {
    const deviceId = req.get("x-device-id") ?? undefined;
    const sig = req.get("x-signature") ?? "";
    const ip = req.ip ?? "unknown";
    if (!deviceId || !sig || !req.rawBody) {
      recordAuthFailure(ctx, ip, undefined, "UNKNOWN_DEVICE");
      throw new AppError(401, "DEVICE_AUTH_FAILED", "Device authentication failed");
    }
    const auth = authenticateDevice(ctx, deviceId, req.rawBody, sig);
    if (!auth.ok) {
      recordAuthFailure(ctx, ip, deviceId, auth.reason);
      throw new AppError(401, "DEVICE_AUTH_FAILED", "Device authentication failed");
    }
    const payload = parse(readingSchema, req.body);
    if (payload.deviceId !== auth.device.id) throw new AppError(400, "VALIDATION_ERROR", "deviceId in the body must match X-Device-Id");
    const out = ingestReading(ctx, auth.device, payload);
    res.status(out.status === "created" ? 201 : 200).json({
      status: out.status,
      record: { id: out.record.id, sequence: out.record.sequence, hash: out.record.hash, previousHash: out.record.previousHash, receivedAt: out.record.receivedAt },
      nextSequence: out.record.sequence + 1,
      serverTime: ctx.now(),
      clock: out.clock,
    });
  });
  return r;
}

const listQuery = pageQuery.extend({
  deviceId: z.string().max(40).optional(), shipmentId: z.string().max(40).optional(), from: isoOpt, to: isoOpt,
  source: z.enum(["HARDWARE", "SIMULATOR", "SANDBOX"]).optional(), sensorStatus: z.enum(["OK", "DISCONNECTED", "INVALID"]).optional(),
  order: z.enum(["asc", "desc"]).default("desc"),
}).transform((q) => ({ ...q, pageSize: Math.min(q.pageSize, 1000) }));

export function readingsRouter(ctx: AppContext): Router {
  const r = Router();
  r.get("/readings", requireAuth, (req, res) => {
    const q = parse(listQuery, req.query);
    res.json(listReadings(ctx.live, q));
  });
  r.get("/readings/:id", requireAuth, (req, res) => {
    const d = getReadingDetail(ctx.live, String(req.params.id));
    if (!d) throw notFound("Reading");
    res.json(d);
  });
  return r;
}
