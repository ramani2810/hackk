import { Router } from "express";
import { z } from "zod";
import { all } from "../db/index";
import type { AppContext } from "../context";
import { notFound } from "../lib/errors";
import { parse } from "../lib/http";
import { actorOf, requireAuth, requireRole } from "../middleware/auth";
import { alertDto, type AlertRow } from "../services/alerts";
import { listReadings } from "../services/readings";
import { createShipment, getShipmentRow, listShipments, shipmentDto, updateShipment } from "../services/shipments";

const createSchema = z.object({
  id: z.string().min(3).max(40), name: z.string().min(1).max(100), product: z.string().max(100).nullish(), origin: z.string().max(100).nullish(),
  destination: z.string().max(100).nullish(), deviceId: z.string().max(40).nullish(), minTempC: z.number().min(-100).max(100).optional(),
  maxTempC: z.number().min(-100).max(100).optional(), status: z.enum(["PLANNED", "IN_TRANSIT"]).optional(),
}).strict();
const patchSchema = z.object({ status: z.enum(["PLANNED", "IN_TRANSIT", "DELIVERED", "CANCELLED"]).optional(), deviceId: z.string().max(40).nullable().optional() }).strict();

export function shipmentsRouter(ctx: AppContext): Router {
  const r = Router();
  r.get("/shipments", requireAuth, (_req, res) => res.json({ items: listShipments(ctx) }));

  r.get("/shipments/:id", requireAuth, (req, res) => {
    const s = getShipmentRow(ctx, String(req.params.id));
    if (!s) throw notFound("Shipment");
    const dto = shipmentDto(ctx, s);
    const history = listReadings(ctx.live, { shipmentId: s.id, order: "desc", page: 1, pageSize: 300 }).items.reverse();
    const alerts = all<AlertRow>(ctx.live.db, "SELECT * FROM alerts WHERE shipment_id = ? AND scope = 'LIVE' ORDER BY created_at DESC LIMIT 100", s.id).map((a) => alertDto(a, ctx.now()));
    const timeline: { ts: string; type: string; title: string; detail?: string }[] = [{ ts: s.created_at, type: "SHIPMENT", title: "Shipment created" }];
    if (s.started_at) timeline.push({ ts: s.started_at, type: "SHIPMENT", title: "Shipment in transit", detail: s.device_id ? `Monitored by ${s.device_id}` : undefined });
    for (const a of alerts) {
      timeline.push({ ts: a.createdAt, type: a.category, title: a.title, detail: `${a.severity} · ${a.kind}` });
      if (a.resolvedAt && a.kind === "TEMP_EXCURSION") timeline.push({ ts: a.resolvedAt, type: "TEMPERATURE", title: "Excursion resolved", detail: a.durationSeconds !== null ? `Lasted ${a.durationSeconds} s` : undefined });
    }
    if (s.ended_at) timeline.push({ ts: s.ended_at, type: "SHIPMENT", title: s.status === "DELIVERED" ? "Shipment delivered" : "Shipment ended" });
    timeline.sort((a, b) => (a.ts < b.ts ? 1 : -1));
    res.json({ shipment: dto, history, alerts, timeline: timeline.slice(0, 200) });
  });

  r.post("/shipments", requireRole("ADMIN"), (req, res) => {
    const body = parse(createSchema, req.body);
    res.status(201).json(createShipment(ctx, body, actorOf(req), req.ip));
  });

  r.patch("/shipments/:id", requireRole("ADMIN"), (req, res) => {
    res.json(updateShipment(ctx, String(req.params.id), parse(patchSchema, req.body), actorOf(req), req.ip));
  });
  return r;
}
