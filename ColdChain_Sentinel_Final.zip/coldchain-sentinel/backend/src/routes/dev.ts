import { Router } from "express";
import { z } from "zod";
import type { AppContext } from "../context";
import { AppError } from "../lib/errors";
import { parse } from "../lib/http";
import { actorOf, devOnly, requireRole } from "../middleware/auth";
import { audit } from "../services/audit";
import { resetDemoData } from "../services/simulator";
import { resetSandbox, sandboxState, tamper, verifySandbox } from "../services/sandbox";

const simCfg = z.object({ intervalSec: z.number().int().min(1).max(60).optional(), deviceIds: z.array(z.string().max(40)).max(20).optional(), randomEvents: z.boolean().optional() }).strict();
const tamperSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("modify"), sequence: z.number().int().min(1), temperatureC: z.number().min(-80).max(150) }).strict(),
  z.object({ action: z.literal("rewrite_chain"), sequence: z.number().int().min(1), temperatureC: z.number().min(-80).max(150) }).strict(),
  z.object({ action: z.literal("delete"), sequence: z.number().int().min(1) }).strict(),
  z.object({ action: z.literal("reorder"), sequence: z.number().int().min(1) }).strict(),
  z.object({ action: z.literal("append"), count: z.number().int().min(1).max(20) }).strict(),
]);

/**
 * Development-only controls: simulator + tamper sandbox. Disabled (404) when NODE_ENV=production
 * or ENABLE_DEV_ENDPOINTS=false, and always require the ADMIN role.
 */
export function devRouter(ctx: AppContext): Router {
  const r = Router();
  r.use("/dev", devOnly(ctx), requireRole("ADMIN"));

  r.get("/dev/simulator", (_req, res) => res.json(ctx.simulator.state()));
  r.post("/dev/simulator/start", (req, res) => {
    const cfg = parse(simCfg, req.body ?? {});
    ctx.simulator.start(cfg);
    audit(ctx, { actor: actorOf(req), action: "simulator.start", targetType: "simulator", details: cfg, ip: req.ip });
    res.json(ctx.simulator.state());
  });
  r.post("/dev/simulator/stop", (req, res) => {
    ctx.simulator.stop();
    audit(ctx, { actor: actorOf(req), action: "simulator.stop", targetType: "simulator", ip: req.ip });
    res.json(ctx.simulator.state());
  });
  r.patch("/dev/simulator", (req, res) => {
    ctx.simulator.configure(parse(simCfg, req.body ?? {}));
    res.json(ctx.simulator.state());
  });
  r.post("/dev/simulator/excursion", (req, res) => {
    const b = parse(z.object({ deviceId: z.string().max(40), peakC: z.number().min(8.5).max(40).optional(), readings: z.number().int().min(2).max(30).optional() }).strict(), req.body);
    try { ctx.simulator.triggerExcursion(b.deviceId, b); } catch (e) { throw new AppError(400, "BAD_DEVICE", (e as Error).message); }
    audit(ctx, { actor: actorOf(req), action: "simulator.excursion", targetType: "device", targetId: b.deviceId, details: b, ip: req.ip });
    res.json(ctx.simulator.state());
  });
  r.post("/dev/simulator/disconnect", (req, res) => {
    const b = parse(z.object({ deviceId: z.string().max(40), readings: z.number().int().min(1).max(20).optional() }).strict(), req.body);
    try { ctx.simulator.triggerDisconnect(b.deviceId, b.readings); } catch (e) { throw new AppError(400, "BAD_DEVICE", (e as Error).message); }
    res.json(ctx.simulator.state());
  });
  /** Generate N readings per selected device immediately (handy to populate the ledger before a demo). */
  r.post("/dev/simulator/generate", (req, res) => {
    const b = parse(z.object({ count: z.number().int().min(1).max(300).default(20), deviceIds: z.array(z.string().max(40)).max(20).optional() }).strict(), req.body ?? {});
    const ids = b.deviceIds?.length ? b.deviceIds : ctx.simulator.simulatedDeviceIds();
    for (let i = 0; i < b.count; i++) ctx.simulator.tickOnce(ids);
    audit(ctx, { actor: actorOf(req), action: "simulator.generate", targetType: "simulator", details: { count: b.count, devices: ids }, ip: req.ip });
    res.json({ generated: b.count * ids.length, perDevice: b.count, devices: ids });
  });
  r.post("/dev/demo/reset", (req, res) => {
    parse(z.object({ confirm: z.literal(true) }).strict(), req.body);
    res.json(resetDemoData(ctx, actorOf(req), req.ip));
  });

  r.get("/dev/sandbox", (_req, res) => res.json(sandboxState(ctx)));
  r.post("/dev/sandbox/reset", (req, res) => { const out = resetSandbox(ctx, actorOf(req), req.ip); res.json({ ...out, state: sandboxState(ctx) }); });
  r.post("/dev/sandbox/tamper", (req, res) => {
    const out = tamper(ctx, parse(tamperSchema, req.body), actorOf(req), req.ip);
    res.json({ ...out, state: sandboxState(ctx) });
  });
  r.post("/dev/sandbox/verify", (req, res) => {
    const verification = verifySandbox(ctx, actorOf(req), req.ip);
    res.json({ verification, state: sandboxState(ctx) });
  });
  return r;
}
