import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import type { AppContext } from "../context";
import { AppError, unauthorized } from "../lib/errors";
import { parse } from "../lib/http";
import { requireAuth } from "../middleware/auth";
import { audit } from "../services/audit";
import { authenticate, COOKIE_NAME, createSession, destroySession } from "../services/auth";

const loginSchema = z.object({ email: z.string().email().max(200), password: z.string().min(1).max(200) }).strict();

export function authRouter(ctx: AppContext): Router {
  const r = Router();
  const limiter = rateLimit({
    windowMs: ctx.config.loginRateWindowMs, limit: ctx.config.loginRateMax, skipSuccessfulRequests: true, standardHeaders: "draft-7", legacyHeaders: false,
    message: { error: { code: "RATE_LIMITED", message: "Too many failed login attempts. Try again later." } },
  });

  r.post("/auth/login", limiter, (req, res) => {
    const { email, password } = parse(loginSchema, req.body);
    const user = authenticate(ctx, email, password);
    if (!user) {
      audit(ctx, { actor: { id: null, label: "anonymous" }, action: "auth.login_failed", details: { email: email.slice(0, 80) }, ip: req.ip });
      throw new AppError(401, "INVALID_CREDENTIALS", "Invalid e-mail or password");
    }
    const { token, expiresAt } = createSession(ctx, user.id, req.ip ?? null, req.get("user-agent") ?? null);
    res.cookie(COOKIE_NAME, token, { httpOnly: true, sameSite: "lax", secure: ctx.config.cookieSecure, path: "/", expires: new Date(expiresAt) });
    audit(ctx, { actor: { id: user.id, label: `${user.email} (${user.role})` }, action: "auth.login", ip: req.ip });
    res.json({ user });
  });

  r.post("/auth/logout", (req, res) => {
    const token = (req.cookies as Record<string, string> | undefined)?.[COOKIE_NAME];
    if (req.user) audit(ctx, { actor: { id: req.user.id, label: `${req.user.email} (${req.user.role})` }, action: "auth.logout", ip: req.ip });
    destroySession(ctx, token);
    res.clearCookie(COOKIE_NAME, { path: "/", httpOnly: true, sameSite: "lax", secure: ctx.config.cookieSecure });
    res.json({ ok: true });
  });

  r.get("/auth/me", (req, res) => {
    if (!req.user) throw unauthorized();
    res.json({ user: req.user });
  });

  r.get("/status", requireAuth, async (_req, res) => {
    const { statusSummary } = await import("../services/overview");
    res.json(statusSummary(ctx));
  });
  return r;
}
