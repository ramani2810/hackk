import { loadConfig } from "../config";
import { createContext } from "../context";
import { createDevice } from "../services/devices";
import { SYSTEM_ACTOR } from "../services/audit";

const [id, ...nameParts] = process.argv.slice(2);
if (!id) { console.error('Usage: npm run device:register -- <DEVICE_ID> "Optional display name"'); process.exit(1); }
const ctx = await createContext(loadConfig());
try {
  const r = createDevice(ctx, { id, name: nameParts.join(" ") || id, type: "ESP32" }, SYSTEM_ACTOR);
  console.log(`\nDevice ${id} registered.\nDEVICE_SECRET = ${r.secret}\n(shown only once)\n`);
} catch (e) { console.error("Failed:", (e as Error).message); process.exitCode = 1; }
ctx.close();
