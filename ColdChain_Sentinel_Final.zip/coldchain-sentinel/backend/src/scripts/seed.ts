import { loadConfig } from "../config";
import { createContext } from "../context";
import { get } from "../db/index";
import { createUser } from "../services/auth";
import { createDevice, ensureSimulatedDevices, getDeviceRow } from "../services/devices";
import { createShipment, getShipmentRow } from "../services/shipments";
import { SYSTEM_ACTOR } from "../services/audit";
import { resetSandbox } from "../services/sandbox";
import { randomHex } from "../lib/crypto";

/**
 * Development seed. Creates (only if missing):
 *  - an ADMIN and a VIEWER account (passwords from env, or randomly generated and printed ONCE)
 *  - three simulated devices, one physical-device registration (COLD-BOX-01) and two shipments
 *  - the disposable tamper-demo sandbox ledger
 * It never overwrites existing data and never runs against NODE_ENV=production.
 */
async function main() {
  const config = loadConfig();
  if (config.nodeEnv === "production") throw new Error("Refusing to seed development data when NODE_ENV=production");
  const ctx = await createContext(config);
  const out: string[] = [];

  const mk = (email: string, name: string, role: "ADMIN" | "VIEWER", envPw: string | undefined) => {
    if (get(ctx.live.db, "SELECT 1 AS x FROM users WHERE email = ?", email)) { out.push(`user ${email}: already exists (unchanged)`); return; }
    const generated = !envPw;
    const password = envPw || randomHex(8);
    createUser(ctx, { email, name, role, password });
    out.push(`user ${email} (${role}) created. Password: ${generated ? password + "   <- randomly generated, shown only now" : "(from your .env file)"}`);
  };
  mk(process.env.SEED_ADMIN_EMAIL ?? "admin@coldchain.local", "Dev Administrator", "ADMIN", process.env.SEED_ADMIN_PASSWORD);
  mk(process.env.SEED_VIEWER_EMAIL ?? "viewer@coldchain.local", "Dev Viewer", "VIEWER", process.env.SEED_VIEWER_PASSWORD);

  ensureSimulatedDevices(ctx);
  out.push("simulated devices SIM-COLD-01..03 ready");

  if (!getDeviceRow(ctx, "COLD-BOX-01")) {
    const r = createDevice(ctx, { id: "COLD-BOX-01", name: "Physical ESP32 Cold Box 01", type: "ESP32", description: "Physical ESP32 + DS18B20 hardware device" }, SYSTEM_ACTOR);
    out.push("");
    out.push("ESP32 device COLD-BOX-01 registered. Put this secret into firmware/coldchain_esp32/config.h (shown ONLY ONCE):");
    out.push(`  DEVICE_SECRET = ${r.secret}`);
    out.push("  (lost it? Log in as admin -> Devices -> Rotate credential)");
    out.push("");
  } else out.push("device COLD-BOX-01: already registered (secret not shown again)");

  const ships: [string, string, string, string][] = [
    ["SHP-2026-0001", "COVID-19 vaccine lot A (Mumbai to Pune)", "SIM-COLD-01", "Vaccine lot A"],
    ["SHP-2026-0002", "Insulin cold-chain trial", "SIM-COLD-02", "Insulin pens"],
  ];
  for (const [id, name, dev, product] of ships) {
    if (!getShipmentRow(ctx, id)) createShipment(ctx, { id, name, product, origin: "Warehouse A", destination: "Clinic B", deviceId: dev }, SYSTEM_ACTOR);
  }
  resetSandbox(ctx, SYSTEM_ACTOR);
  out.push("tamper-demo sandbox ledger created (isolated database file)");
  console.log("\n" + out.join("\n") + "\n");
  ctx.close();
}
main().catch((e) => { console.error("Seed failed:", e.message); process.exit(1); });
