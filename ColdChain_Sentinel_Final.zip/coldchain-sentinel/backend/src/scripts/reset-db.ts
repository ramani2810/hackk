import fs from "node:fs";
import { loadConfig } from "../config";

const config = loadConfig();
if (config.nodeEnv === "production") { console.error("Refusing to delete data when NODE_ENV=production"); process.exit(1); }
if (!process.argv.includes("--yes")) {
  console.error("This DELETES the local database, sandbox and checkpoint files in backend/data.\nRun again with --yes to confirm:  npm run db:reset -- --yes");
  process.exit(1);
}
fs.rmSync(config.dataDir, { recursive: true, force: true });
console.log("Deleted", config.dataDir, "\nNow run:  npm run db:migrate  and  npm run db:seed");
