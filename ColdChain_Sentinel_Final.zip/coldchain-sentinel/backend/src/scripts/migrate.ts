import { loadConfig } from "../config";
import { migrate, openDb } from "../db/index";

const config = loadConfig();
for (const [label, file] of [["live", config.dbPath], ["sandbox", config.sandboxDbPath]] as const) {
  const db = openDb(file);
  const ran = migrate(db, config.migrationsDir);
  console.log(`[${label}] ${file}: ${ran.length ? "applied " + ran.join(", ") : "already up to date"}`);
  db.close();
}
