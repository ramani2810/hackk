import type { AppConfig } from "./config";
import { type DB, openDb, migrate } from "./db/index";
import { CheckpointStore } from "./services/checkpoints";
import { EventBus } from "./services/events";
import { createLogger, type Logger } from "./lib/logger";
import type { Simulator } from "./services/simulator";

export interface Dataset {
  name: "LIVE" | "SANDBOX";
  db: DB;
  checkpoints: CheckpointStore;
}

export interface AppContext {
  config: AppConfig;
  log: Logger;
  bus: EventBus;
  live: Dataset;
  sandbox: Dataset;
  simulator: Simulator;
  /** Failed device-authentication counters (in-memory sliding windows). */
  authFailures: Map<string, { count: number; first: number }>;
  now: () => string;
  close: () => void;
}

export async function createContext(config: AppConfig, opts: { memory?: boolean } = {}): Promise<AppContext> {
  const log = createLogger(config.logLevel);
  const liveDb = openDb(opts.memory ? ":memory:" : config.dbPath);
  const sandboxDb = openDb(opts.memory ? ":memory:" : config.sandboxDbPath);
  migrate(liveDb, config.migrationsDir);
  migrate(sandboxDb, config.migrationsDir);
  const { Simulator: SimulatorClass } = await import("./services/simulator");
  const ctx: AppContext = {
    config,
    log,
    bus: new EventBus(),
    live: { name: "LIVE", db: liveDb, checkpoints: new CheckpointStore(config.checkpointDir, config.checkpointKey, liveDb) },
    sandbox: { name: "SANDBOX", db: sandboxDb, checkpoints: new CheckpointStore(config.sandboxCheckpointDir, config.checkpointKey, sandboxDb) },
    simulator: undefined as unknown as Simulator,
    authFailures: new Map(),
    now: () => new Date().toISOString(),
    close: () => {
      ctx.simulator.stop();
      liveDb.close();
      sandboxDb.close();
    },
  };
  ctx.simulator = new SimulatorClass(ctx);
  return ctx;
}
