import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createContext, type ReactNode, useCallback, useContext, useMemo } from "react";
import { api, ApiError } from "../lib/api";
import type { User } from "../lib/types";

interface AuthCtx { user: User | null; loading: boolean; backendDown: boolean; isAdmin: boolean; login: (email: string, password: string) => Promise<void>; logout: () => Promise<void> }
const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const me = useQuery({
    queryKey: ["me"], retry: false, staleTime: 30_000,
    queryFn: async () => {
      try { return (await api.get<{ user: User }>("/auth/me")).user; }
      catch (e) { if (e instanceof ApiError && e.status === 401) return null; throw e; }
    },
  });
  const login = useCallback(async (email: string, password: string) => {
    const r = await api.post<{ user: User }>("/auth/login", { email, password });
    qc.clear();
    qc.setQueryData(["me"], r.user);
  }, [qc]);
  const logout = useCallback(async () => {
    try { await api.post("/auth/logout"); } finally { qc.clear(); qc.setQueryData(["me"], null); }
  }, [qc]);
  const value = useMemo<AuthCtx>(() => ({
    user: me.data ?? null, loading: me.isLoading, backendDown: me.isError, isAdmin: me.data?.role === "ADMIN", login, logout,
  }), [me.data, me.isLoading, me.isError, login, logout]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}
