import { useQueryClient } from "@tanstack/react-query";
import { createContext, type ReactNode, useContext, useEffect, useMemo, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import type { Alert, Reading } from "../lib/types";

interface Live { connected: boolean; lastEventAt: number | null; lastReading: Reading | null; lastAlert: Alert | null; unseenAlerts: number; clearUnseen: () => void }
const Ctx = createContext<Live>({ connected: false, lastEventAt: null, lastReading: null, lastAlert: null, unseenAlerts: 0, clearUnseen: () => {} });

/**
 * Socket.IO live updates. Events invalidate the relevant React Query caches (the data itself always
 * comes from the REST API). When the socket is down, pages fall back to polling (see pollMs()).
 */
export function LiveProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const [connected, setConnected] = useState(false);
  const [lastEventAt, setLast] = useState<number | null>(null);
  const [lastReading, setLastReading] = useState<Reading | null>(null);
  const [lastAlert, setLastAlert] = useState<Alert | null>(null);
  const [unseen, setUnseen] = useState(0);
  const sock = useRef<Socket | null>(null);
  const pending = useRef<Set<string>>(new Set());
  const timer = useRef<number | null>(null);

  useEffect(() => {
    const s = io({ withCredentials: true, transports: ["websocket", "polling"], reconnectionDelayMax: 5000 });
    sock.current = s;
    // Coalesce bursts (the simulator can emit many events per second) into one refetch every 700 ms.
    const touch = (...keys: string[]) => {
      keys.forEach((k) => pending.current.add(k));
      if (timer.current) return;
      timer.current = window.setTimeout(() => {
        for (const k of pending.current) qc.invalidateQueries({ queryKey: [k] });
        pending.current.clear(); timer.current = null;
      }, 700);
    };
    s.on("connect", () => { setConnected(true); touch("overview", "readings", "devices", "ledger", "alerts", "status"); });
    s.on("disconnect", () => setConnected(false));
    s.on("connect_error", () => setConnected(false));
    s.on("reading:new", (r: Reading) => { setLast(Date.now()); setLastReading(r); touch("overview", "readings", "ledger", "devices", "shipments", "status"); });
    s.on("alert:new", (a: Alert) => { setLast(Date.now()); setLastAlert(a); if (a.scope === "LIVE") setUnseen((n) => n + 1); touch("alerts", "overview", "status"); });
    s.on("alert:updated", () => touch("alerts", "overview", "shipments"));
    s.on("verification:done", () => touch("ledger", "overview", "alerts", "verifications", "shipments"));
    s.on("device:updated", () => touch("devices", "overview"));
    s.on("simulator:state", () => touch("simulator", "status"));
    s.on("sandbox:updated", () => touch("sandbox", "alerts"));
    s.on("settings:updated", () => touch("settings", "overview", "status"));
    return () => { s.close(); if (timer.current) clearTimeout(timer.current); timer.current = null; };
  }, [qc]);

  const value = useMemo<Live>(() => ({ connected, lastEventAt, lastReading, lastAlert, unseenAlerts: unseen, clearUnseen: () => setUnseen(0) }), [connected, lastEventAt, lastReading, lastAlert, unseen]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useLive = () => useContext(Ctx);
/** Polling interval: slow when the socket is healthy, fast when it is not (the fallback). */
export function usePollMs(socketMs = 20_000, fallbackMs = 4_000) {
  return useLive().connected ? socketMs : fallbackMs;
}
