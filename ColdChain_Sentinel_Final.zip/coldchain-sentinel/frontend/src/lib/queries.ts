import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { usePollMs } from "../app/live";
import { api, qs } from "./api";
import type { Alert, AuditEvent, Device, LedgerSummary, Overview, Paged, Reading, Settings, Shipment, SimState, StatusSummary, VerifyRun } from "./types";

export const useStatus = () => { const p = usePollMs(10_000, 4000); return useQuery({ queryKey: ["status"], queryFn: () => api.get<StatusSummary>("/status"), refetchInterval: p, retry: false }); };
export const useOverview = () => { const p = usePollMs(15_000, 4000); return useQuery({ queryKey: ["overview"], queryFn: () => api.get<Overview>("/overview"), refetchInterval: p }); };
export const useDevices = () => { const p = usePollMs(10_000, 4000); return useQuery({ queryKey: ["devices"], queryFn: () => api.get<{ items: Device[] }>("/devices"), refetchInterval: p }); };
export const useSettings = () => useQuery({ queryKey: ["settings"], queryFn: () => api.get<Settings>("/settings") });
export const useSimulator = (enabled: boolean) => { const p = usePollMs(10_000, 4000); return useQuery({ queryKey: ["simulator"], queryFn: () => api.get<SimState>("/dev/simulator"), enabled, refetchInterval: p }); };
export const useShipments = () => { const p = usePollMs(15_000, 5000); return useQuery({ queryKey: ["shipments"], queryFn: () => api.get<{ items: Shipment[] }>("/shipments"), refetchInterval: p }); };
export const useLedgerSummary = () => { const p = usePollMs(15_000, 5000); return useQuery({ queryKey: ["ledger", "summary"], queryFn: () => api.get<LedgerSummary>("/ledger/summary"), refetchInterval: p }); };

export function useReadings(params: Record<string, string | number | undefined>, opts: { poll?: boolean } = {}) {
  const p = usePollMs(15_000, 4000);
  return useQuery({ queryKey: ["readings", params], queryFn: () => api.get<Paged<Reading>>(`/readings${qs(params)}`), placeholderData: keepPreviousData, refetchInterval: opts.poll === false ? false : p });
}
export function useLedger(params: Record<string, string | number | undefined>) {
  const p = usePollMs(20_000, 6000);
  return useQuery({ queryKey: ["ledger", "list", params], queryFn: () => api.get<Paged<Reading>>(`/ledger${qs(params)}`), placeholderData: keepPreviousData, refetchInterval: p });
}
export function useAlerts(params: Record<string, string | number | undefined>) {
  const p = usePollMs(15_000, 4000);
  return useQuery({ queryKey: ["alerts", params], queryFn: () => api.get<Paged<Alert>>(`/alerts${qs(params)}`), placeholderData: keepPreviousData, refetchInterval: p });
}
export const useVerifications = () => useQuery({ queryKey: ["verifications"], queryFn: () => api.get<{ items: VerifyRun[] }>("/ledger/verifications?limit=15") });
export function useAudit(params: Record<string, string | number | undefined>, enabled: boolean) {
  return useQuery({ queryKey: ["audit", params], queryFn: () => api.get<Paged<AuditEvent>>(`/audit${qs(params)}`), enabled, placeholderData: keepPreviousData });
}
