export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public details?: unknown) {
    super(message);
  }
}

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) ?? "";

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${BASE}/api/v1${path}`, {
      method,
      credentials: "include",
      headers: { "X-Requested-With": "ColdChainSentinel", ...(body !== undefined ? { "Content-Type": "application/json" } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, "NETWORK", "Cannot reach the backend. Is it running on port 4000?");
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let data: unknown = undefined;
  try { data = text ? JSON.parse(text) : undefined; } catch { /* not json */ }
  if (!res.ok) {
    const e = (data as { error?: { code?: string; message?: string; details?: unknown } } | undefined)?.error;
    if (res.status === 502 || res.status === 504 || (res.status === 500 && !e)) throw new ApiError(res.status, "BACKEND_DOWN", "The backend is not responding. Start it with: npm run dev (see RUN_INSTRUCTIONS_WINDOWS.md).");
    throw new ApiError(res.status, e?.code ?? "ERROR", e?.message ?? `Request failed (${res.status})`, e?.details);
  }
  return data as T;
}

export const api = {
  get: <T>(p: string) => request<T>("GET", p),
  post: <T>(p: string, b?: unknown) => request<T>("POST", p, b ?? {}),
  patch: <T>(p: string, b: unknown) => request<T>("PATCH", p, b),
};

export const qs = (params: Record<string, string | number | undefined | null>) => {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") u.set(k, String(v));
  const s = u.toString();
  return s ? `?${s}` : "";
};

/** Downloads an authenticated report through the API (cookie auth), saving it under the server-provided filename. */
export async function downloadReport(path: string): Promise<string> {
  let res: Response;
  try { res = await fetch(`${BASE}/api/v1${path}`, { credentials: "include", headers: { "X-Requested-With": "ColdChainSentinel" } }); }
  catch { throw new ApiError(0, "NETWORK", "Cannot reach the backend."); }
  if (!res.ok) {
    let msg = `Report failed (${res.status})`;
    try { msg = (await res.json()).error?.message ?? msg; } catch { /* ignore */ }
    throw new ApiError(res.status, "REPORT", msg);
  }
  const cd = res.headers.get("content-disposition") ?? "";
  const name = /filename="?([^"]+)"?/.exec(cd)?.[1] ?? "report.csv";
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return name;
}
