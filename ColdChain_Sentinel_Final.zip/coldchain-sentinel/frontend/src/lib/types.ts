export type Role = "ADMIN" | "VIEWER";
export interface User { id: string; email: string; name: string; role: Role }
export type Source = "HARDWARE" | "SIMULATOR" | "SANDBOX";
export interface Integrity { status: string; kinds: string[]; verifiedAt: string | null; runId: string | null }
export interface Reading {
  id: string; ledgerIndex: number; deviceId: string; sequence: number; temperatureC: number | null; humidityPct: number | null;
  sensorStatus: "OK" | "DISCONNECTED" | "INVALID"; deviceTimestamp: string | null; receivedAt: string; clockSynced: boolean; source: Source;
  firmwareVersion: string | null; shipmentId: string | null; gapBefore: number; previousHash: string; hash: string; integrity: Integrity;
}
export interface ReadingDetail extends Reading { canonicalForm: string; recomputedHash: string; previous: Reading | null; next: Reading | null }
export interface Paged<T> { items: T[]; total: number; page: number; pageSize: number }
export interface Device {
  id: string; name: string; type: "ESP32" | "SIMULATED" | "SANDBOX"; description: string | null; createdAt: string; source: Source;
  lastSeenAt: string | null; secondsSinceLastSeen: number | null; connectivity: "ONLINE" | "OFFLINE" | "NEVER_SEEN"; online: boolean;
  latestTemperatureC: number | null; sensorHealth: string; firmwareVersion: string | null; lastSequence: number; activeShipmentId: string | null; openAlerts: number;
  auth: { method: string; status: string; fingerprint: string | null; issuedAt: string | null; revokedAt: string | null; lastUsedAt: string | null };
}
export interface Alert {
  id: string; category: "TEMPERATURE" | "SECURITY"; kind: string; severity: "INFO" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"; status: "OPEN" | "RESOLVED";
  scope: "LIVE" | "SANDBOX"; deviceId: string | null; shipmentId: string | null; recordId: string | null; title: string; description: string;
  details: Record<string, unknown>; createdAt: string; updatedAt: string; acknowledged: boolean; acknowledgedAt: string | null; acknowledgedBy: string | null;
  resolvedAt: string | null; resolvedBy: string | null; resolutionNote: string | null; durationSeconds: number | null;
}
export interface Failure { kind: string; deviceId: string; recordId: string | null; sequence: number | null; message: string; expected?: string | null; actual?: string | null }
export interface VerifyRun {
  id: string; dataset: string; scope: string; deviceId: string | null; rangeFrom: string | null; rangeTo: string | null; status: "VERIFIED" | "VERIFICATION_FAILED";
  recordsChecked: number; devicesChecked: number; checkpointsChecked: number; failures: Failure[]; failureCounts: Record<string, number>; notes: string[];
  startedAt: string; finishedAt: string; triggeredBy: string | null;
}
export interface Shipment {
  id: string; name: string; product: string | null; origin: string | null; destination: string | null; status: string; deviceId: string | null;
  deviceType: string | null; source: Source | null; minTempC: number; maxTempC: number; createdAt: string; startedAt: string | null; endedAt: string | null;
  readingCount: number; lastReadingAt: string | null; currentReading: { id: string; temperatureC: number | null; receivedAt: string; sensorStatus: string; source: Source } | null;
  excursionCount: number; openExcursions: number; openIntegrityAlerts: number; failedRecords: number; verifiedRecords: number;
}
export interface AuditEvent { id: string; ts: string; actor: string; action: string; targetType: string | null; targetId: string | null; scope: string; details: Record<string, unknown>; ip: string | null }
export interface Settings { tempMinC: number; tempMaxC: number; staleSeconds: number; recoveryReadings: number; simulatorIntervalSec: number }
export interface ModeInfo { mode: "SIMULATION" | "LIVE_HARDWARE"; hardwareDevicesOnline: number; simulatorRunning: boolean; latestRecordSource: Source | null; explanation: string }
export interface SimState { running: boolean; intervalSec: number; deviceIds: string[]; randomEvents: boolean; tickCount: number; startedAt: string | null; devices: Record<string, { phase: string; temperatureC: number }>; note: string }
export interface StatusSummary {
  serverTime: string; settings: Settings; devices: { total: number; online: number }; lastReadingAt: string | null; simulator: SimState; devEndpointsEnabled: boolean; environment: string;
  openAlerts: { openTemperature: number; openSecurity: number }; mode: ModeInfo["mode"]; explanation: string; hardwareDevicesOnline: number; simulatorRunning: boolean; latestRecordSource: Source | null;
}
export interface Overview {
  generatedAt: string; mode: ModeInfo; settings: { tempMinC: number; tempMaxC: number };
  kpis: {
    devicesTotal: number; devicesOnline: number; latestTemperature: { temperatureC: number; deviceId: string; receivedAt: string; source: Source } | null;
    excursionsTotal: number; excursionsOpen: number; totalRecords: number; verifiedRecords: number; failedRecords: number; unverifiedRecords: number;
    integrityViolationsOpen: number; lastSuccessfulVerificationAt: string | null;
  };
  latestVerification: { id: string; status: string; scope: string; deviceId: string | null; recordsChecked: number; finishedAt: string; failureCounts: Record<string, number>; checkpointsChecked: number } | null;
  devices: Device[]; recentReadings: Reading[]; recentSecurityAlerts: Alert[]; recentTemperatureAlerts: Alert[]; recentAudit: AuditEvent[];
  shipments: { total: number; inTransit: number; items: Shipment[] };
}
export interface LedgerSummary {
  totalRecords: number; verifiedRecords: number; failedRecords: number; unverifiedRecords: number; latestRecord: Reading | null;
  chains: { deviceId: string; records: number; headSequence: number | null; headHash: string | null; lastCheckpoint: { id: string; lastSequence: number; createdAt: string; headHash: string } | null }[];
  chainStatus: { status: string; lastVerifiedAt: string | null; runId: string | null; scope: string | null; deviceId: string | null; recordsChecked: number; newRecordsSinceVerification: number; failureCounts: Record<string, number> };
  checkpointInfo: { keyId: string; every: number; storage: string; limitation: string };
}
