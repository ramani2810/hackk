export const fmtTemp = (t: number | null | undefined, digits = 2) => (t === null || t === undefined ? "n/a" : `${t.toFixed(digits)} °C`);
export function fmtTime(iso: string | null | undefined, opts: { seconds?: boolean; date?: boolean } = {}): string {
  if (!iso) return "never";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "invalid";
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", ...(opts.seconds === false ? {} : { second: "2-digit" }), hour12: false });
  if (opts.date === false) return time;
  const sameDay = d.toDateString() === new Date().toDateString();
  return sameDay && opts.date !== true ? time : `${d.toLocaleDateString([], { day: "2-digit", month: "short" })} ${time}`;
}
export function fmtFull(iso: string | null | undefined) {
  if (!iso) return "never";
  const d = new Date(iso);
  return `${d.toLocaleString([], { hour12: false })} (${iso})`;
}
export function ago(iso: string | null | undefined, nowMs = Date.now()): string {
  if (!iso) return "never";
  const s = Math.max(0, Math.round((nowMs - Date.parse(iso)) / 1000));
  if (s < 5) return "just now";
  if (s < 60) return `${s} s ago`;
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
}
export function dur(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined) return "n/a";
  if (seconds < 60) return `${seconds} s`;
  const m = Math.floor(seconds / 60);
  if (m < 60) return `${m} min ${seconds % 60} s`;
  return `${Math.floor(m / 60)} h ${m % 60} min`;
}
export const short = (h: string | null | undefined, n = 10) => (h ? `${h.slice(0, n)}…${h.slice(-4)}` : "none");
export const num = (n: number) => n.toLocaleString();
export function humanize(s: string) {
  const t = s.replace(/_/g, " ").toLowerCase();
  return t.charAt(0).toUpperCase() + t.slice(1);
}
