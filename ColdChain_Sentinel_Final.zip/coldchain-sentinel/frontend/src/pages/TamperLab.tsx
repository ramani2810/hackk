import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import clsx from "clsx";
import { ArrowRightLeft, FlaskConical, Pencil, Plus, RotateCcw, ShieldCheck, Trash2, Wand2 } from "lucide-react";
import { useState } from "react";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, Empty, ErrorBox, Field, IntegrityBadge, Notice, SeverityBadge, Spinner, inputCls } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { fmtTemp, humanize, short } from "../lib/format";
import type { Alert, Failure, Reading, VerifyRun } from "../lib/types";
import { FailureList } from "./Ledger";

interface SandboxRecord extends Reading { original: { temperatureC: number | null; hash: string; previousHash: string } | null; modified: boolean; temperatureChanged: boolean }
interface SandboxState {
  deviceId: string; notice: string; records: SandboxRecord[]; deleted: { id: string; sequence: number; temperatureC: number | null; hash: string }[]; orderChanged: boolean;
  checkpoints: { id: string; lastSequence: number }[]; lastVerification: VerifyRun | null; alerts: { temperature: Alert[]; integrity: Alert[] }; seeded: boolean;
}

export default function TamperLab() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["sandbox"], queryFn: () => api.get<SandboxState>("/dev/sandbox") });
  const [seq, setSeq] = useState(12);
  const [temp, setTemp] = useState("3.3");
  const [last, setLast] = useState<{ title: string; text: string } | null>(null);
  const [fresh, setFresh] = useState(false);

  const call = useMutation({
    mutationFn: ({ path, body }: { path: string; body?: unknown; note?: string }) => api.post<{ state?: SandboxState; description?: string; verification?: VerifyRun }>(path, body),
    onSuccess: (r, v) => {
      if (r.state) qc.setQueryData(["sandbox"], r.state);
      qc.invalidateQueries({ queryKey: ["alerts"] });
      if (r.description) setLast({ title: v.note ?? "Change applied to the sandbox", text: r.description });
      if (v.path.endsWith("/verify") && r.verification) { setFresh(true); setTimeout(() => setFresh(false), 400); toast.push(r.verification.status === "VERIFIED" ? "ok" : "bad", r.verification.status === "VERIFIED" ? "Sandbox ledger verified" : `Verification failed: ${r.verification.failures.length} problem(s)`); }
      if (v.path.endsWith("/reset")) { setLast(null); toast.push("ok", "Sandbox reset to its original state"); }
    },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Action failed"),
  });
  const tamper = (body: object, note: string) => call.mutate({ path: "/dev/sandbox/tamper", body, note });

  if (q.isLoading) return <Spinner />;
  if (q.isError) return <ErrorBox error={q.error} retry={() => q.refetch()} />;
  const s = q.data!;
  const v = s.lastVerification;
  const failBySeq = new Map<number, string>();
  (v?.failures ?? []).forEach((f: Failure) => { if (f.sequence !== null && !failBySeq.has(f.sequence)) failBySeq.set(f.sequence, f.kind); });
  const changed = s.records.filter((r) => r.modified);
  const temperatureNotice = s.alerts.temperature.some((a) => a.kind === "TEMP_EXCURSION");

  return (
    <div className="space-y-4">
      <Notice tone="info" title="Isolated, disposable ledger">{s.notice} Edits here are raw database changes made behind the application's back, exactly like an attacker with database access would make them. The real verifier then checks them.</Notice>

      <Card title="1. The sandbox ledger" subtitle={`${s.records.length} records of ${s.deviceId}. Each block shows its sequence, temperature and the start of its hash.`}
        actions={<Button size="sm" icon={<RotateCcw size={13} />} loading={call.isPending && call.variables?.path.endsWith("/reset")} onClick={() => call.mutate({ path: "/dev/sandbox/reset" })}>Reset sandbox</Button>}>
        {s.records.length === 0 ? <Empty title="The sandbox is empty" action={<Button variant="primary" onClick={() => call.mutate({ path: "/dev/sandbox/reset" })}>Create the demo ledger</Button>} /> : (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5" role="list" aria-label="Sandbox ledger blocks">
              {s.records.map((r, i) => {
                const k = failBySeq.get(r.sequence) ?? (r.integrity.status !== "VERIFIED" && r.integrity.status !== "UNVERIFIED" ? r.integrity.status : null);
                const bad = !!k;
                const exc = r.temperatureC !== null && (r.temperatureC > 8 || r.temperatureC < 2);
                const prev = s.records[i - 1];
                const gap = prev && r.sequence - prev.sequence > 1;
                return (
                  <div key={r.id} role="listitem" className="flex items-center gap-1.5">
                    {gap && <div className="flex h-14 w-5 items-center justify-center rounded border border-dashed border-bad/60 text-[9px] text-bad" title="Missing record(s)">gone</div>}
                    <button onClick={() => { setSeq(r.sequence); setTemp(String(r.temperatureC ?? "")); }} title={`#${r.sequence}  ${fmtTemp(r.temperatureC)}\nprev ${r.previousHash}\nhash ${r.hash}`}
                      className={clsx("w-[84px] rounded-md border px-2 py-1.5 text-left transition-colors", bad ? "cc-shake border-bad bg-bad-bg" : seq === r.sequence ? "border-cyan bg-info-bg" : r.modified ? "border-warn bg-warn-bg" : "border-line bg-ink-900 hover:border-ink-600", fresh && "")}>
                      <div className="flex items-center justify-between text-[10px] text-fg-3"><span className="tnum">#{r.sequence}</span>{bad ? <span className="text-bad">fail</span> : v && v.status === "VERIFIED" ? <span className="text-ok">ok</span> : null}</div>
                      <div className={clsx("text-[13px] font-medium tnum", exc ? "text-warn" : "")}>{r.temperatureC !== null ? r.temperatureC.toFixed(1) : "n/a"}<span className="text-[10px] text-fg-3"> °C</span></div>
                      <div className="hash text-[9px] text-fg-3">{r.hash.slice(0, 8)}</div>
                    </button>
                  </div>);
              })}
            </div>
            <p className="text-[11px] text-fg-3">Amber temperatures (records 18-20) are a <b>genuine excursion</b>: the sensor really measured more than 8 °C. They raise a temperature alert, but the chain stays valid.{temperatureNotice ? "" : ""} Click a block to select it.</p>
          </div>)}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="2. Tamper with history" subtitle="Pick a record and change it behind the application's back.">
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Record sequence"><input type="number" min={1} value={seq} onChange={(e) => setSeq(Number(e.target.value))} className={inputCls} /></Field>
              <Field label="New temperature (°C)"><input type="number" step="0.1" value={temp} onChange={(e) => setTemp(e.target.value)} className={inputCls} /></Field>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <Button icon={<Pencil size={14} />} disabled={!temp || call.isPending} onClick={() => tamper({ action: "modify", sequence: seq, temperatureC: Number(temp) }, "Temperature edited")}>Change temperature</Button>
              <Button icon={<Trash2 size={14} />} disabled={call.isPending} onClick={() => tamper({ action: "delete", sequence: seq }, "Record deleted")}>Delete record</Button>
              <Button icon={<ArrowRightLeft size={14} />} disabled={call.isPending} onClick={() => tamper({ action: "reorder", sequence: seq }, "Records reordered")}>Swap with next record</Button>
              <Button icon={<Plus size={14} />} disabled={call.isPending} onClick={() => tamper({ action: "append", count: 3 }, "Legitimate records appended")}>Append 3 genuine records</Button>
            </div>
            <div className="rounded-md border border-warn/30 bg-warn-bg/40 p-3">
              <p className="mb-2 text-xs text-fg-2"><b>Skilled attacker:</b> changes the value and recomputes every later hash so the hash chain looks perfectly consistent.</p>
              <Button variant="danger" icon={<Wand2 size={14} />} disabled={!temp || call.isPending} onClick={() => tamper({ action: "rewrite_chain", sequence: seq, temperatureC: Number(temp) }, "Chain rewritten with recomputed hashes")}>Edit and re-hash the whole chain</Button>
            </div>
            {last && <Notice tone="warn" title={last.title}>{last.text}</Notice>}
          </div>
        </Card>

        <Card title="3. Run the real verifier" subtitle="The same verification service the live ledger uses."
          actions={v && <IntegrityBadge status={v.status === "VERIFIED" ? "VERIFIED" : "VERIFICATION_FAILED"} />}>
          <Button variant="primary" icon={<ShieldCheck size={14} />} loading={call.isPending && !!call.variables?.path.endsWith("/verify")} onClick={() => call.mutate({ path: "/dev/sandbox/verify" })}>Verify sandbox ledger</Button>
          {!v ? <p className="mt-3 text-xs text-fg-3">Not verified yet.</p> : (
            <div className="mt-3 space-y-3">
              <p className="text-xs text-fg-3">{v.recordsChecked} records and {v.checkpointsChecked} signed checkpoint(s) checked.</p>
              {v.failures.length === 0 ? <p className="text-xs text-ok">All hashes match, all links intact, all signed checkpoints agree.</p> : <FailureList failures={v.failures} />}
              {s.records.length > 0 && v.failures.length > 0 && !v.failures.some((f) => f.kind === "INVALID_HASH" || f.kind === "BROKEN_LINK" || f.kind === "REORDERED") && v.failures.some((f) => f.kind === "CHECKPOINT_MISMATCH") &&
                <Notice tone="warn" title="The hash chain alone was fooled">Every hash and link is consistent, because the attacker recomputed them. Only the signed checkpoint, whose key is held outside the database, exposed the change.</Notice>}
            </div>)}
        </Card>
      </div>

      {(changed.length > 0 || s.deleted.length > 0 || s.orderChanged) && (
        <Card title="Original versus modified data" pad={false}>
          <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-left text-[13px]"><thead><tr className="text-xs text-fg-3"><th className="px-3 py-2 font-medium">Record</th><th className="px-3 py-2 font-medium">Original</th><th className="px-3 py-2 font-medium">Now</th><th className="px-3 py-2 font-medium">Verifier says</th></tr></thead>
            <tbody>
              {s.deleted.map((d) => <tr key={d.id} className="border-t border-line-soft"><td className="px-3 py-2 tnum">#{d.sequence}</td><td className="px-3 py-2 tnum">{fmtTemp(d.temperatureC)}</td><td className="px-3 py-2 text-bad">deleted</td><td className="px-3 py-2"><Badge tone="bad">{v ? "Missing record" : "Run the verifier"}</Badge></td></tr>)}
              {changed.slice(0, 12).map((r) => (
                <tr key={r.id} className="border-t border-line-soft"><td className="px-3 py-2 tnum">#{r.sequence}</td>
                  <td className="px-3 py-2 tnum">{fmtTemp(r.original!.temperatureC)}<div className="hash text-fg-3">{short(r.original!.hash, 8)}</div></td>
                  <td className="px-3 py-2 tnum"><span className={r.temperatureChanged ? "text-bad" : ""}>{fmtTemp(r.temperatureC)}</span><div className={clsx("hash", r.hash === r.original!.hash ? "text-fg-3" : "text-warn")}>{short(r.hash, 8)}</div></td>
                  <td className="px-3 py-2"><IntegrityBadge status={r.integrity.status} /></td></tr>))}
              {s.orderChanged && <tr className="border-t border-line-soft"><td className="px-3 py-2" colSpan={4}>Ledger order was changed (records no longer appear in sequence order).</td></tr>}
            </tbody></table></div>
          {changed.length > 12 && <p className="px-3 py-2 text-[11px] text-fg-3">{changed.length - 12} more rewritten records not shown. Re-hashing changes every later record.</p>}
        </Card>)}

      <Card title="4. Alerts raised in the sandbox" subtitle="Temperature alerts and integrity alerts are separate categories.">
        <div className="grid gap-4 md:grid-cols-2">
          <div><h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-fg-2"><FlaskConical size={13} className="text-warn" /> Temperature</h3>
            {s.alerts.temperature.length === 0 ? <p className="text-xs text-fg-3">None</p> : <ul className="space-y-1.5">{s.alerts.temperature.map((a) => <li key={a.id} className="flex items-center justify-between gap-2 rounded border border-line-soft p-2 text-xs"><span>{a.title}</span><Badge tone={a.status === "OPEN" ? "warn" : "neutral"}>{humanize(a.status)}</Badge></li>)}</ul>}</div>
          <div><h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-fg-2"><ShieldCheck size={13} className="text-bad" /> Integrity</h3>
            {s.alerts.integrity.length === 0 ? <p className="text-xs text-fg-3">None. The chain has not failed verification.</p> : <ul className="space-y-1.5">{s.alerts.integrity.slice(0, 8).map((a) => <li key={a.id} className="rounded border border-bad/30 bg-bad-bg/30 p-2 text-xs"><div className="flex items-center justify-between gap-2"><span>{a.title}</span><SeverityBadge s={a.severity} /></div></li>)}</ul>}</div>
        </div>
      </Card>
    </div>
  );
}
