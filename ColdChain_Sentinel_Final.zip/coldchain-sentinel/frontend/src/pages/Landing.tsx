import clsx from "clsx";
import { Activity, ArrowRight, Bell, Cpu, Database, Fingerprint, GitCommitHorizontal, KeyRound, Link2, LockKeyhole, Radio, RotateCcw, ServerCog, ShieldAlert, ShieldCheck, Thermometer, Wifi } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Logo } from "../components/Shell";
import { sha256Hex } from "../lib/sha256";

const NAV = [
  { href: "#problem", label: "Problem" }, { href: "#how", label: "How it works" }, { href: "#ledger", label: "Hash chain" },
  { href: "#alerts", label: "Alerts" }, { href: "#architecture", label: "Security" }, { href: "#stack", label: "Stack" }, { href: "#limits", label: "Limitations" },
];

function Section({ id, eyebrow, title, children, className }: { id: string; eyebrow: string; title: string; children: React.ReactNode; className?: string }) {
  return (
    <section id={id} className={clsx("scroll-mt-16 border-t border-line-soft py-16", className)}>
      <div className="mx-auto max-w-6xl px-4">
        <div className="mb-8 max-w-2xl"><div className="text-xs font-medium uppercase tracking-[0.14em] text-cyan">{eyebrow}</div><h2 className="mt-2 text-2xl font-semibold tracking-tight">{title}</h2></div>
        {children}
      </div>
    </section>
  );
}

/** Original SVG pipeline: sensor -> ESP32 -> backend/hash chain -> dashboard. */
function PipelineArt() {
  return (
    <svg viewBox="0 0 560 330" role="img" aria-label="Data pipeline: DS18B20 sensor, ESP32, hash-chained ledger, monitoring dashboard" className="w-full">
      <defs>
        <linearGradient id="g1" x1="0" x2="1"><stop offset="0" stopColor="#3cc8e8" stopOpacity=".1" /><stop offset="1" stopColor="#3cc8e8" stopOpacity=".7" /></linearGradient>
        <marker id="ar" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto"><path d="M0 0 7 3.5 0 7z" fill="#3cc8e8" /></marker>
      </defs>
      <rect x="1" y="1" width="558" height="328" rx="12" fill="#0d1a2f" stroke="#1d3050" />
      {/* sensor */}
      <g transform="translate(28 40)">
        <rect width="104" height="84" rx="8" fill="#11213a" stroke="#27406a" />
        <rect x="14" y="14" width="10" height="46" rx="5" fill="#0a1424" stroke="#3cc8e8" />
        <rect x="16.5" y="34" width="5" height="24" rx="2.5" fill="#3cc8e8" />
        <circle cx="19" cy="62" r="7" fill="#3cc8e8" />
        <text x="38" y="34" fill="#e6edf7" fontSize="19" fontWeight="600" fontFamily="IBM Plex Mono, monospace">4.2°C</text>
        <text x="38" y="52" fill="#8397b5" fontSize="10.5">DS18B20</text>
        <text x="38" y="66" fill="#8397b5" fontSize="10.5">1-Wire probe</text>
      </g>
      {/* esp32 */}
      <g transform="translate(28 190)">
        <rect width="104" height="96" rx="8" fill="#11213a" stroke="#27406a" />
        <rect x="14" y="16" width="44" height="30" rx="3" fill="#0a1424" stroke="#3cc8e8" />
        <path d="M66 22h22M66 31h22M66 40h22" stroke="#27406a" strokeWidth="3" strokeLinecap="round" />
        <rect x="14" y="56" width="76" height="22" rx="3" fill="#0a1424" stroke="#1d3050" />
        <text x="20" y="71" fill="#35d399" fontSize="9" fontFamily="IBM Plex Mono, monospace">4.2C  WiFi OK</text>
        <text x="14" y="90" fill="#8397b5" fontSize="10.5">ESP32 + OLED</text>
      </g>
      <path d="M80 124v66" stroke="#3cc8e8" strokeWidth="1.6" strokeDasharray="4 4" markerEnd="url(#ar)" />
      <path d="M132 238h58" stroke="#3cc8e8" strokeWidth="1.6" strokeDasharray="4 4" markerEnd="url(#ar)" />
      <text x="146" y="230" fill="#8397b5" fontSize="9.5">HMAC</text>
      <text x="140" y="257" fill="#8397b5" fontSize="9.5">HTTP POST</text>
      {/* ledger */}
      <g transform="translate(196 40)">
        <rect width="190" height="246" rx="8" fill="#11213a" stroke="#27406a" />
        <text x="14" y="24" fill="#e6edf7" fontSize="12" fontWeight="600">Backend ledger</text>
        {[0, 1, 2, 3].map((i) => (
          <g key={i} transform={`translate(14 ${38 + i * 50})`}>
            <rect width="162" height="38" rx="5" fill="#0a1424" stroke={i === 3 ? "#3cc8e8" : "#1d3050"} />
            <text x="8" y="15" fill="#8397b5" fontSize="9.5">#{9 + i}   prev {["7f3a", "c91e", "04bd", "e2a8"][i]}…</text>
            <text x="8" y="29" fill="#35d399" fontSize="10.5" fontFamily="IBM Plex Mono, monospace">hash {["c91e", "04bd", "e2a8", "5d10"][i]}…</text>
            {i < 3 && <path d="M81 38v12" stroke="#3cc8e8" strokeWidth="1.6" markerEnd="url(#ar)" />}
          </g>
        ))}
      </g>
      <path d="M386 163h40" stroke="#3cc8e8" strokeWidth="1.6" markerEnd="url(#ar)" />
      {/* dashboard */}
      <g transform="translate(430 70)">
        <rect width="104" height="186" rx="8" fill="#11213a" stroke="#27406a" />
        <text x="10" y="20" fill="#e6edf7" fontSize="11" fontWeight="600">Dashboard</text>
        <rect x="10" y="30" width="84" height="46" rx="4" fill="#0a1424" stroke="#1d3050" />
        <path d="M14 66 28 56 40 61 54 46 68 52 90 40" fill="none" stroke="#3cc8e8" strokeWidth="1.8" />
        <rect x="14" y="48" width="76" height="12" fill="url(#g1)" opacity=".18" />
        <rect x="10" y="86" width="84" height="22" rx="4" fill="#0f3a31" stroke="#35d399" strokeOpacity=".4" />
        <text x="18" y="101" fill="#35d399" fontSize="10">Chain verified</text>
        <rect x="10" y="114" width="84" height="22" rx="4" fill="#3d2f12" stroke="#f5b547" strokeOpacity=".4" />
        <text x="18" y="129" fill="#f5b547" fontSize="10">Excursion 9.2°C</text>
        <rect x="10" y="142" width="84" height="22" rx="4" fill="#431a24" stroke="#f2656f" strokeOpacity=".4" />
        <text x="18" y="157" fill="#f2656f" fontSize="10">Hash mismatch</text>
      </g>
    </svg>
  );
}

interface Block { id: number; temp: string; time: string }
const SEED: Block[] = [
  { id: 1, temp: "4.1", time: "08:00" }, { id: 2, temp: "4.3", time: "08:01" }, { id: 3, temp: "4.6", time: "08:02" },
  { id: 4, temp: "5.0", time: "08:03" }, { id: 5, temp: "9.2", time: "08:04" }, { id: 6, temp: "6.4", time: "08:05" },
];
const GENESIS = "0".repeat(64);

/** Real SHA-256 computed in the browser. A local teaching demo; it is not data from the backend. */
function ChainDemo() {
  const [blocks, setBlocks] = useState<Block[]>(SEED);
  const [rechain, setRechain] = useState(false);
  const orig = useMemo(() => { let p = GENESIS; return SEED.map((b) => { const h = sha256Hex(`${p}|${b.id}|${b.temp}|${b.time}`); const o = { ...b, prev: p, hash: h }; p = h; return o; }); }, []);
  const chain = useMemo(() => {
    let prevRecomputed = GENESIS;
    return blocks.map((b, i) => {
      const storedPrev = rechain ? prevRecomputed : orig[i]!.prev;
      const storedHash = rechain ? sha256Hex(`${storedPrev}|${b.id}|${b.temp}|${b.time}`) : orig[i]!.hash;
      const recomputed = sha256Hex(`${storedPrev}|${b.id}|${b.temp}|${b.time}`);
      const hashOk = recomputed === storedHash;
      const linkOk = storedPrev === prevRecomputed;
      prevRecomputed = recomputed;
      return { b, storedPrev, storedHash, recomputed, hashOk, linkOk, changed: b.temp !== SEED[i]!.temp };
    });
  }, [blocks, rechain, orig]);
  const firstBad = chain.findIndex((c) => !c.hashOk || !c.linkOk);
  const anchorOk = chain[chain.length - 1]!.storedHash === orig[orig.length - 1]!.hash;
  const edit = (i: number, v: string) => setBlocks((bs) => bs.map((b, j) => (j === i ? { ...b, temp: v.replace(/[^0-9.\-]/g, "").slice(0, 5) } : b)));

  return (
    <div className="rounded-lg border border-line bg-ink-850 p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="text-[13px] text-fg-2">Edit any temperature below. The verifier recomputes every SHA-256 hash in your browser.</div>
        <div className="flex items-center gap-3 text-xs">
          <label className="flex cursor-pointer items-center gap-1.5 text-fg-2"><input type="checkbox" checked={rechain} onChange={(e) => setRechain(e.target.checked)} className="accent-cyan" /> Attacker re-computes all later hashes</label>
          <button onClick={() => { setBlocks(SEED); setRechain(false); }} className="inline-flex items-center gap-1 rounded border border-line px-2 py-1 text-fg-2 hover:bg-ink-800"><RotateCcw size={12} /> Reset</button>
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {chain.map((c, i) => {
          const bad = !c.hashOk || !c.linkOk;
          return (
            <div key={c.b.id} className={clsx("rounded-md border p-2.5 transition-colors", bad ? "border-bad/50 bg-bad-bg/40" : "border-line bg-ink-900")}>
              <div className="flex items-center justify-between text-[11px]"><span className="text-fg-3">Record #{c.b.id} · {c.b.time}</span>{bad ? <span className="font-medium text-bad">{!c.hashOk ? "INVALID HASH" : "BROKEN LINK"}</span> : <span className="font-medium text-ok">verified</span>}</div>
              <label className="mt-1.5 flex items-center gap-1.5 text-xs text-fg-2">Temperature
                <input aria-label={`Temperature of record ${c.b.id}`} value={c.b.temp} onChange={(e) => edit(i, e.target.value)} inputMode="decimal" className={clsx("w-16 rounded border bg-ink-950 px-1.5 py-0.5 text-right font-mono text-[13px]", c.changed ? "border-warn text-warn" : "border-line text-fg")} /> °C
              </label>
              <div className="mt-1.5 space-y-0.5 font-mono text-[10.5px] leading-tight">
                <div className="text-fg-3">prev  <span className="text-fg-2">{c.storedPrev.slice(0, 16)}…</span></div>
                <div className="text-fg-3">hash  <span className={bad ? "text-bad" : "text-ok"}>{c.storedHash.slice(0, 16)}…</span></div>
                {!c.hashOk && <div className="text-fg-3">calc  <span className="text-warn">{c.recomputed.slice(0, 16)}…</span></div>}
              </div>
            </div>
          );
        })}
      </div>
      <div className={clsx("mt-3 flex items-start gap-2 rounded-md border px-3 py-2 text-[13px]", firstBad < 0 ? "border-ok/30 bg-ok-bg/50 text-ok" : rechain && !anchorOk ? "border-warn/40 bg-warn-bg/60 text-warn" : "border-bad/40 bg-bad-bg/50 text-bad")}>
        {firstBad < 0 ? <ShieldCheck size={16} className="mt-0.5 shrink-0" /> : <ShieldAlert size={16} className="mt-0.5 shrink-0" />}
        <div>
          {firstBad < 0 && !blocks.some((b, i) => b.temp !== SEED[i]!.temp) && "All six records verify: every hash matches its contents and every link matches the previous record."}
          {firstBad >= 0 && `Verification failed at record #${chain[firstBad]!.b.id}. Every record after it no longer links to a valid predecessor.`}
          {firstBad < 0 && rechain && blocks.some((b, i) => b.temp !== SEED[i]!.temp) && (
            <>The chain is internally consistent again, because the attacker re-hashed everything. A hash chain alone cannot see this. {anchorOk ? "" : <strong>The signed checkpoint can: the head hash no longer matches the one signed earlier.</strong>}</>
          )}
        </div>
      </div>
      <p className="mt-2 text-[11px] text-fg-3">Local teaching demo: six fixed example records, hashed with SHA-256 in your browser. The real ledger, verifier and tamper lab run on the backend.</p>
    </div>
  );
}

const features = [
  { icon: Thermometer, title: "Real-time temperature", text: "DS18B20 readings stream in over Wi-Fi and appear live on the dashboard with the configured safe band (sample 2–8 °C)." },
  { icon: Link2, title: "Hash-chained records", text: "Every reading is linked to the previous one with SHA-256, so a later edit, deletion or reorder is detectable." },
  { icon: Bell, title: "Two kinds of alert", text: "Temperature excursions and integrity violations are separate. A genuine warm reading is not tampering." },
  { icon: Wifi, title: "Device health", text: "Online, offline and stale status comes from server-side last-seen times, never from the browser being open." },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-ink-900">
      <header className="sticky top-0 z-40 border-b border-line bg-ink-900/90 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
          <a href="#top" className="flex items-center gap-2 font-semibold"><Logo size={22} /> ColdChain Sentinel</a>
          <nav aria-label="Sections" className="ml-6 hidden gap-4 text-[13px] text-fg-3 lg:flex">{NAV.map((n) => <a key={n.href} href={n.href} className="hover:text-fg">{n.label}</a>)}</nav>
          <div className="ml-auto flex items-center gap-2">
            <Link to="/login" className="rounded-md px-3 py-1.5 text-[13px] text-fg-2 hover:bg-ink-800">Sign in</Link>
            <Link to="/app" className="rounded-md bg-cyan px-3 py-1.5 text-[13px] font-semibold text-ink-950 hover:brightness-110">Open dashboard</Link>
          </div>
        </div>
      </header>

      <main id="top">
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-[1.05fr_1fr] md:py-20">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full border border-line bg-ink-850 px-3 py-1 text-xs text-fg-2"><Fingerprint size={13} className="text-cyan" /> Every Reading Accounted For. Every Record Verifiable.</div>
            <h1 className="mt-5 text-4xl font-semibold leading-[1.1] tracking-tight md:text-[44px]">Trust Every Temperature. Verify Every Record.</h1>
            <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-fg-2">An IoT-powered cold-chain monitoring platform that combines real-time temperature tracking with cryptographic record verification to help identify unsafe conditions and unauthorized data modifications.</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/app" className="inline-flex items-center gap-2 rounded-md bg-cyan px-4 py-2.5 text-sm font-semibold text-ink-950 hover:brightness-110">Open Monitoring Dashboard <ArrowRight size={16} /></Link>
              <a href="#architecture" className="inline-flex items-center gap-2 rounded-md border border-line bg-ink-850 px-4 py-2.5 text-sm font-medium text-fg hover:bg-ink-800">Explore Security Architecture</a>
            </div>
            <p className="mt-5 max-w-lg text-xs text-fg-3">Educational prototype. Not a certified, validated or regulator-approved pharmaceutical monitoring system.</p>
          </div>
          <PipelineArt />
        </section>

        <div className="mx-auto grid max-w-6xl gap-3 px-4 pb-14 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="rounded-lg border border-line bg-ink-850 p-4">
              <f.icon size={18} className="text-cyan" /><h3 className="mt-3 text-[13px] font-semibold">{f.title}</h3><p className="mt-1 text-[13px] leading-relaxed text-fg-3">{f.text}</p>
            </div>
          ))}
        </div>

        <Section id="problem" eyebrow="The problem" title="A temperature log is only useful if you can trust it">
          <div className="grid gap-6 md:grid-cols-2">
            <p className="text-[14px] leading-relaxed text-fg-2">Vaccines, insulin and biologics must stay inside product-specific temperature limits while they travel. During transport, readings can be lost, overwritten or quietly changed. A conventional monitor can display numbers, but it cannot easily show that yesterday's numbers are still the numbers the sensor reported.</p>
            <ul className="space-y-2 text-[14px] text-fg-2">
              {["A bad reading is deleted so a shipment looks compliant.", "A warm period is overwritten with in-range values.", "A device is replaced and the history is re-labelled.", "A database administrator edits records after the fact."].map((t) => <li key={t} className="flex gap-2"><ShieldAlert size={16} className="mt-0.5 shrink-0 text-warn" />{t}</li>)}
            </ul>
          </div>
        </Section>

        <Section id="how" eyebrow="How it works" title="From probe to verified record in five steps">
          <ol className="grid gap-3 md:grid-cols-5">
            {[["Measure", "DS18B20 reads the temperature; the ESP32 checks the value and shows it on its OLED.", Thermometer], ["Sign", "The reading is sent over Wi-Fi with an HMAC-SHA-256 signature made with a per-device secret.", KeyRound], ["Validate", "The backend verifies the signature, the input ranges and the sequence number.", ServerCog], ["Chain", "The record is hashed together with the previous record's hash and stored in one transaction.", Link2], ["Verify", "A verifier recomputes every hash and compares signed checkpoints kept outside the database.", ShieldCheck]].map(([t, d, I], i) => {
              const Icon = I as typeof Thermometer;
              return <li key={t as string} className="rounded-lg border border-line bg-ink-850 p-4"><div className="flex items-center gap-2 text-xs text-fg-3"><span className="flex h-5 w-5 items-center justify-center rounded-full bg-ink-700 text-[11px] text-fg">{i + 1}</span><Icon size={15} className="text-cyan" /></div><h3 className="mt-2 text-[13px] font-semibold">{t as string}</h3><p className="mt-1 text-[12.5px] leading-relaxed text-fg-3">{d as string}</p></li>;
            })}
          </ol>
          <div className="mt-6 grid gap-3 md:grid-cols-3">
            <div className="rounded-lg border border-line bg-ink-850 p-4"><Activity size={16} className="text-cyan" /><h3 className="mt-2 text-[13px] font-semibold">Live monitoring</h3><p className="mt-1 text-[12.5px] leading-relaxed text-fg-3">Socket.IO pushes new readings to the dashboard. If the socket drops, pages fall back to polling and say so.</p></div>
            <div className="rounded-lg border border-line bg-ink-850 p-4"><Radio size={16} className="text-cyan" /><h3 className="mt-2 text-[13px] font-semibold">Hardware or simulation, always labelled</h3><p className="mt-1 text-[12.5px] leading-relaxed text-fg-3">The whole system runs without hardware. Simulated records carry a SIMULATOR label everywhere and use separate device identities.</p></div>
            <div className="rounded-lg border border-line bg-ink-850 p-4"><Cpu size={16} className="text-cyan" /><h3 className="mt-2 text-[13px] font-semibold">Device health</h3><p className="mt-1 text-[12.5px] leading-relaxed text-fg-3">Sensor faults, stale readings, firmware version and credential status are tracked per device.</p></div>
          </div>
        </Section>

        <Section id="ledger" eyebrow="SHA-256 hash chain" title="Change one record and the chain tells you">
          <p className="mb-5 max-w-2xl text-[14px] leading-relaxed text-fg-2">Each record stores the hash of the one before it. SHA-256 is a one-way fingerprint function, not encryption: it does not hide data, it makes silent edits visible. Try it.</p>
          <ChainDemo />
          <div className="mt-4 flex flex-wrap gap-3 text-[13px]">
            <Link to="/app/ledger" className="inline-flex items-center gap-1.5 text-cyan hover:underline">Open the real ledger explorer <ArrowRight size={14} /></Link>
            <Link to="/app/tamper-lab" className="inline-flex items-center gap-1.5 text-cyan hover:underline">Run the tamper lab on the backend <ArrowRight size={14} /></Link>
          </div>
        </Section>

        <Section id="alerts" eyebrow="Alerts" title="A warm reading is not tampering">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border border-warn/30 bg-ink-850 p-5">
              <div className="flex items-center gap-2 text-warn"><Thermometer size={18} /><h3 className="font-semibold">Temperature alert</h3></div>
              <p className="mt-2 text-[13px] leading-relaxed text-fg-2">A genuine measurement outside the configured range: 9.2 °C against an 8 °C limit. The sensor was telling the truth, so the record's hash stays valid. Excursions track their peak and duration and resolve after consecutive in-range readings.</p>
              <div className="mt-3 rounded bg-warn-bg px-3 py-2 font-mono text-[12px] text-warn">TEMP_EXCURSION · peak 9.20 °C · integrity: VERIFIED</div>
            </div>
            <div className="rounded-lg border border-bad/30 bg-ink-850 p-5">
              <div className="flex items-center gap-2 text-bad"><ShieldAlert size={18} /><h3 className="font-semibold">Security alert</h3></div>
              <p className="mt-2 text-[13px] leading-relaxed text-fg-2">Stored history no longer matches its hashes or its signed checkpoint: a modified value, broken link, missing or reordered record, bad device signature or repeated failed requests. Corrupted records are kept for evidence, never silently repaired.</p>
              <div className="mt-3 rounded bg-bad-bg px-3 py-2 font-mono text-[12px] text-bad">HASH_MISMATCH · record #5 · BROKEN_LINK · record #6</div>
            </div>
          </div>
        </Section>

        <Section id="architecture" eyebrow="Security architecture" title="What is protected, and how">
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {[
              [KeyRound, "Device authentication", "Each ESP32 has its own random secret. Requests carry HMAC-SHA-256 over the exact body. The server stores the secret AES-256-GCM encrypted and never returns it again."],
              [Database, "Authoritative server-side chain", "The backend calculates hashes inside a write transaction, so concurrent requests cannot fork the chain or reuse a sequence number."],
              [Fingerprint, "Canonical serialization", "Records are hashed as sorted-key JSON with fixed-precision numbers and a domain prefix. No ad-hoc field concatenation."],
              [LockKeyhole, "Signed checkpoints", "Periodic HMAC-signed checkpoints live in an append-only file outside the database, with the key in the environment. They expose a rewrite where every hash was recomputed."],
              [ShieldCheck, "Access control", "Scrypt-hashed passwords, httpOnly session cookies, anti-CSRF header, login rate limits, admin and viewer roles enforced on the server."],
              [GitCommitHorizontal, "Audit trail", "Verifications, registrations, revocations, setting changes and tamper tests are recorded. Secrets are redacted before they reach logs."],
            ].map(([I, t, d]) => { const Icon = I as typeof KeyRound; return <div key={t as string} className="rounded-lg border border-line bg-ink-850 p-4"><Icon size={17} className="text-cyan" /><h3 className="mt-2 text-[13px] font-semibold">{t as string}</h3><p className="mt-1 text-[12.5px] leading-relaxed text-fg-3">{d as string}</p></div>; })}
          </div>
        </Section>

        <Section id="stack" eyebrow="Technology" title="Built with open, free tools">
          <div className="grid gap-3 text-[13px] sm:grid-cols-2 lg:grid-cols-4">
            {[["Firmware", "ESP32, Arduino C++, DS18B20, SSD1306 OLED, mbedTLS HMAC"], ["Backend", "Node.js 22, Express, TypeScript, Zod, Socket.IO"], ["Database", "SQLite (built into Node), transactional writes, migrations"], ["Frontend", "React, TypeScript, Vite, Tailwind CSS, Recharts, TanStack Query"]].map(([t, d]) => <div key={t} className="rounded-lg border border-line bg-ink-850 p-4"><div className="text-xs uppercase tracking-wider text-cyan">{t}</div><p className="mt-1.5 text-fg-2">{d}</p></div>)}
          </div>
        </Section>

        <Section id="limits" eyebrow="Honest limits" title="Limitations and future improvements">
          <div className="grid gap-6 md:grid-cols-2">
            <ul className="space-y-2 text-[13.5px] text-fg-2">
              {["Hashing protects the history the server holds. A compromised or miscalibrated sensor can still send wrong temperatures with valid signatures.", "Checkpoints sit on the same machine as the database in this prototype. Copy them to independent storage to resist an attacker who controls the whole server.", "Records written after the newest checkpoint are protected only by the hash chain.", "Not validated, calibrated or certified for pharmaceutical use. Reports say so."].map((t) => <li key={t} className="flex gap-2"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-warn" />{t}</li>)}
            </ul>
            <ul className="space-y-2 text-[13.5px] text-fg-2">
              {["Device-side signing with a secure element, so the device (not the server) vouches for each reading.", "Publishing checkpoints to an external transparency log or write-once storage.", "TLS with certificate pinning on the ESP32, OTA firmware updates, calibration records.", "Multi-sensor redundancy, GPS location and door-open detection."].map((t) => <li key={t} className="flex gap-2"><span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-cyan" />{t}</li>)}
            </ul>
          </div>
        </Section>
      </main>

      <footer className="border-t border-line bg-ink-950 py-10">
        <div className="mx-auto flex max-w-6xl flex-wrap items-start justify-between gap-6 px-4 text-[13px] text-fg-3">
          <div><div className="flex items-center gap-2 font-semibold text-fg"><Logo size={20} /> ColdChain Sentinel</div><p className="mt-2 max-w-sm">Tamper-evident IoT monitoring for pharmaceutical cold chains. An educational IoT and cybersecurity prototype.</p></div>
          <div className="flex gap-10"><div className="space-y-1.5"><div className="text-xs uppercase tracking-wider text-fg-2">App</div><Link className="block hover:text-fg" to="/app">Dashboard</Link><Link className="block hover:text-fg" to="/app/ledger">Integrity ledger</Link><Link className="block hover:text-fg" to="/login">Sign in</Link></div>
            <div className="space-y-1.5"><div className="text-xs uppercase tracking-wider text-fg-2">Learn</div><a className="block hover:text-fg" href="#how">How it works</a><a className="block hover:text-fg" href="#architecture">Security</a><a className="block hover:text-fg" href="#limits">Limitations</a></div></div>
        </div>
        <p className="mx-auto mt-8 max-w-6xl px-4 text-[11px] text-fg-3">Not a certified, validated or regulator-approved medical monitoring system. Do not use it to make decisions about real medicines.</p>
      </footer>
    </div>
  );
}
