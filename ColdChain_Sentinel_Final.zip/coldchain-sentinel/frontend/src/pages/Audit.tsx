import { useState } from "react";
import { PageHeader } from "../components/Shell";
import { Badge, Card, Empty, ErrorBox, inputCls, Pager, Spinner, Table, Td, Th } from "../components/ui";
import { fmtTime } from "../lib/format";
import { useAudit } from "../lib/queries";

export default function Audit() {
  const [page, setPage] = useState(1);
  const [action, setAction] = useState("");
  const [scope, setScope] = useState("");
  const q = useAudit({ page, pageSize: 25, action: action || undefined, scope: scope || undefined }, true);
  return (
    <>
      <PageHeader title="Audit logs" description="Administrative actions, verification runs, credential changes and tamper-lab operations. Secrets, passwords and keys are never written here."
        actions={<><input aria-label="Filter by action" placeholder="Filter by action, e.g. device" value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} className={inputCls + " w-56"} />
          <select aria-label="Scope" value={scope} onChange={(e) => { setScope(e.target.value); setPage(1); }} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs"><option value="">Live and sandbox</option><option value="LIVE">Live only</option><option value="SANDBOX">Sandbox only</option></select></>} />
      {q.isLoading && <Spinner />}{q.isError && <ErrorBox error={q.error} retry={() => q.refetch()} />}
      {q.data && (q.data.items.length === 0 ? <Card><Empty title="No audit events match" /></Card> : (
        <Card pad={false}><Table><thead><tr><Th>Time</Th><Th>Actor</Th><Th>Action</Th><Th>Target</Th><Th>Details</Th></tr></thead>
          <tbody>{q.data.items.map((e) => (<tr key={e.id} className="align-top"><Td className="tnum whitespace-nowrap text-fg-2">{fmtTime(e.ts, { date: true })}</Td><Td>{e.actor}{e.ip && <div className="text-[11px] text-fg-3">{e.ip}</div>}</Td>
            <Td><span className="font-medium">{e.action}</span> {e.scope === "SANDBOX" && <Badge tone="info">Sandbox</Badge>}</Td><Td className="text-fg-2">{e.targetType ? `${e.targetType} ${e.targetId ?? ""}` : ""}</Td>
            <Td className="max-w-xs"><span className="hash text-fg-3">{Object.keys(e.details).length ? JSON.stringify(e.details) : ""}</span></Td></tr>))}</tbody></Table>
          <Pager page={page} pageSize={25} total={q.data.total} onPage={setPage} /></Card>))}
    </>
  );
}
