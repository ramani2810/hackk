import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Plus, Truck } from "lucide-react";
import { useMemo, useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { TempChart } from "../components/TempChart";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, Drawer, Empty, ErrorBox, Field, IntegrityBadge, Modal, Notice, SeverityBadge, SourceBadge, Spinner, Table, Td, Th, inputCls } from "../components/ui";
import { api, ApiError, downloadReport } from "../lib/api";
import { dur, fmtTemp, fmtTime, humanize } from "../lib/format";
import { useDevices, useSettings, useShipments } from "../lib/queries";
import type { Alert, Reading, Shipment } from "../lib/types";

interface Detail { shipment: Shipment; history: Reading[]; alerts: Alert[]; timeline: { ts: string; type: string; title: string; detail?: string }[] }

export default function Shipments() {
  const { isAdmin } = useAuth();
  const q = useShipments();
  const devices = useDevices();
  const settings = useSettings();
  const qc = useQueryClient();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [err, setErr] = useState("");
  const [sel, setSel] = useState<string | null>(null);
  const [f, setF] = useState({ id: "", name: "", product: "", origin: "", destination: "", deviceId: "", minTempC: "", maxTempC: "" });

  const create = useMutation({
    mutationFn: () => api.post("/shipments", { id: f.id.trim(), name: f.name.trim(), product: f.product || null, origin: f.origin || null, destination: f.destination || null, deviceId: f.deviceId || null,
      ...(f.minTempC !== "" ? { minTempC: Number(f.minTempC) } : {}), ...(f.maxTempC !== "" ? { maxTempC: Number(f.maxTempC) } : {}) }),
    onSuccess: () => { setOpen(false); setErr(""); qc.invalidateQueries({ queryKey: ["shipments"] }); toast.push("ok", `Shipment ${f.id} created`); setF({ id: "", name: "", product: "", origin: "", destination: "", deviceId: "", minTempC: "", maxTempC: "" }); },
    onError: (e) => setErr(e instanceof ApiError ? e.message : "Could not create the shipment"),
  });
  const items = q.data?.items ?? [];
  const devs = (devices.data?.items ?? []).filter((d) => d.type !== "SANDBOX");

  return (
    <>
      <PageHeader title="Shipments" description="A shipment ties a monitored device to a product and its allowed temperature range. Readings received while a shipment is in transit are recorded against it."
        actions={isAdmin && <Button variant="primary" icon={<Plus size={14} />} onClick={() => setOpen(true)}>Create shipment</Button>} />
      {q.isLoading && <Spinner />}
      {q.isError && <ErrorBox error={q.error} retry={() => q.refetch()} />}
      {q.data && items.length === 0 && <Card><Empty title="No shipments yet" action={isAdmin ? <Button variant="primary" onClick={() => setOpen(true)}>Create the first shipment</Button> : undefined}>Create a shipment and assign a device to start grouping readings.</Empty></Card>}
      {items.length > 0 && (
        <Card pad={false}><Table>
          <thead><tr><Th>Shipment</Th><Th>Status</Th><Th>Device</Th><Th>Current reading</Th><Th>Allowed range</Th><Th>Excursions</Th><Th>Integrity</Th></tr></thead>
          <tbody>{items.map((s) => (
            <tr key={s.id} className="cursor-pointer hover:bg-ink-800/50" onClick={() => setSel(s.id)}>
              <Td><button className="text-left font-medium text-cyan hover:underline" onClick={(e) => { e.stopPropagation(); setSel(s.id); }}>{s.id}</button><div className="text-[11px] text-fg-3">{s.name}</div></Td>
              <Td><Badge tone={s.status === "IN_TRANSIT" ? "info" : s.status === "DELIVERED" ? "ok" : "neutral"}>{humanize(s.status)}</Badge></Td>
              <Td>{s.deviceId ?? <span className="text-fg-3">none</span>} <SourceBadge source={s.source} /></Td>
              <Td className="tnum">{s.currentReading ? <>{fmtTemp(s.currentReading.temperatureC)}<div className="text-[11px] text-fg-3">{fmtTime(s.currentReading.receivedAt)}</div></> : <span className="text-fg-3">no readings</span>}</Td>
              <Td className="tnum text-fg-2">{s.minTempC}–{s.maxTempC} °C</Td>
              <Td>{s.excursionCount === 0 ? <span className="text-fg-3">0</span> : <Badge tone={s.openExcursions ? "warn" : "neutral"}>{s.excursionCount}{s.openExcursions ? ` (${s.openExcursions} open)` : ""}</Badge>}</Td>
              <Td>{s.failedRecords > 0 ? <Badge tone="bad">{s.failedRecords} failed</Badge> : s.verifiedRecords > 0 ? <Badge tone="ok">{s.verifiedRecords} verified</Badge> : <Badge>Not verified</Badge>}</Td>
            </tr>))}</tbody></Table></Card>)}

      <Drawer open={!!sel} onClose={() => setSel(null)} title={`Shipment ${sel ?? ""}`}>{sel && <ShipmentDetail id={sel} />}</Drawer>

      <Modal open={open} onClose={() => setOpen(false)} title="Create shipment" wide
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" loading={create.isPending} disabled={!f.id || !f.name} onClick={() => create.mutate()}>Create shipment</Button></>}>
        <div className="grid gap-3 sm:grid-cols-2">
          {err && <div className="sm:col-span-2"><Notice tone="bad">{err}</Notice></div>}
          <Field label="Shipment ID"><input className={inputCls} value={f.id} onChange={(e) => setF({ ...f, id: e.target.value })} placeholder="SHP-2026-0100" autoFocus /></Field>
          <Field label="Name"><input className={inputCls} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Vaccine lot to district clinic" /></Field>
          <Field label="Product"><input className={inputCls} value={f.product} onChange={(e) => setF({ ...f, product: e.target.value })} /></Field>
          <Field label="Assigned device" hint="Assigning a device starts the shipment immediately."><select className={inputCls} value={f.deviceId} onChange={(e) => setF({ ...f, deviceId: e.target.value })}><option value="">None (planned)</option>{devs.map((d) => <option key={d.id} value={d.id}>{d.id} ({d.type === "ESP32" ? "hardware" : "simulated"})</option>)}</select></Field>
          <Field label="Origin"><input className={inputCls} value={f.origin} onChange={(e) => setF({ ...f, origin: e.target.value })} /></Field>
          <Field label="Destination"><input className={inputCls} value={f.destination} onChange={(e) => setF({ ...f, destination: e.target.value })} /></Field>
          <Field label="Minimum temperature (°C)" hint={`Blank uses the default ${settings.data?.tempMinC ?? 2} °C`}><input type="number" step="0.1" className={inputCls} value={f.minTempC} onChange={(e) => setF({ ...f, minTempC: e.target.value })} /></Field>
          <Field label="Maximum temperature (°C)" hint={`Blank uses the default ${settings.data?.tempMaxC ?? 8} °C. Use the product's real limits.`}><input type="number" step="0.1" className={inputCls} value={f.maxTempC} onChange={(e) => setF({ ...f, maxTempC: e.target.value })} /></Field>
        </div>
      </Modal>
    </>
  );
}

function ShipmentDetail({ id }: { id: string }) {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["shipments", id], queryFn: () => api.get<Detail>(`/shipments/${encodeURIComponent(id)}`), refetchInterval: 10_000 });
  const status = useMutation({
    mutationFn: (s: string) => api.patch(`/shipments/${encodeURIComponent(id)}`, { status: s }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["shipments"] }); toast.push("ok", "Shipment updated"); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Failed"),
  });
  const [busy, setBusy] = useState("");
  const dl = async (format: "csv" | "json") => { setBusy(format); try { toast.push("ok", `Saved ${await downloadReport(`/reports/shipments/${encodeURIComponent(id)}?format=${format}`)}`); } catch (e) { toast.push("bad", e instanceof Error ? e.message : "Export failed"); } finally { setBusy(""); } };
  const series = useMemo(() => q.data?.history ?? [], [q.data]);
  if (q.isLoading) return <Spinner />;
  if (q.isError) return <ErrorBox error={q.error} retry={() => q.refetch()} />;
  const d = q.data!; const s = d.shipment;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2"><Badge tone={s.status === "IN_TRANSIT" ? "info" : "neutral"} icon={<Truck size={11} />}>{humanize(s.status)}</Badge><SourceBadge source={s.source} /><span className="text-xs text-fg-3">{s.product ?? "no product"} · {s.origin ?? "?"} to {s.destination ?? "?"}</span></div>
      <dl className="grid grid-cols-2 gap-y-1.5 text-xs"><dt className="text-fg-3">Device</dt><dd>{s.deviceId ?? "none"}</dd><dt className="text-fg-3">Allowed range</dt><dd className="tnum">{s.minTempC}–{s.maxTempC} °C</dd>
        <dt className="text-fg-3">Readings</dt><dd className="tnum">{s.readingCount}</dd><dt className="text-fg-3">Excursions</dt><dd className="tnum">{s.excursionCount}</dd>
        <dt className="text-fg-3">Failed integrity checks</dt><dd className={s.failedRecords ? "text-bad" : ""}>{s.failedRecords}</dd></dl>
      {series.length > 0 ? <TempChart readings={series} minC={s.minTempC} maxC={s.maxTempC} height={200} /> : <Empty title="No readings recorded against this shipment yet" />}
      <div className="flex flex-wrap gap-2">
        <Button size="sm" icon={<Download size={13} />} loading={busy === "csv"} onClick={() => dl("csv")}>Integrity summary (CSV)</Button>
        <Button size="sm" icon={<Download size={13} />} loading={busy === "json"} onClick={() => dl("json")}>JSON</Button>
        {isAdmin && s.status === "IN_TRANSIT" && <Button size="sm" onClick={() => status.mutate("DELIVERED")}>Mark delivered</Button>}
        {isAdmin && s.status === "PLANNED" && <Button size="sm" onClick={() => status.mutate("IN_TRANSIT")}>Start transit</Button>}
        {isAdmin && (s.status === "IN_TRANSIT" || s.status === "PLANNED") && <Button size="sm" variant="danger" onClick={() => status.mutate("CANCELLED")}>Cancel</Button>}
      </div>
      <div><h3 className="mb-2 text-xs font-semibold text-fg-2">Excursions and security events</h3>
        {d.alerts.length === 0 ? <p className="text-xs text-fg-3">No alerts for this shipment.</p> : <ul className="space-y-1.5">{d.alerts.slice(0, 10).map((a) => (
          <li key={a.id} className="rounded border border-line-soft p-2 text-xs"><div className="flex items-center justify-between gap-2"><span>{a.title}</span><SeverityBadge s={a.severity} /></div><div className="mt-0.5 text-fg-3">{fmtTime(a.createdAt, { date: true })}{a.kind === "TEMP_EXCURSION" && a.durationSeconds !== null ? ` · ${dur(a.durationSeconds)}` : ""} · {a.status.toLowerCase()}</div></li>))}</ul>}
      </div>
      <div><h3 className="mb-2 text-xs font-semibold text-fg-2">Timeline</h3>
        <ol className="space-y-2 border-l border-line pl-3">{d.timeline.slice(0, 25).map((t, i) => (<li key={i} className="text-xs"><span className="text-fg-3 tnum">{fmtTime(t.ts, { date: true })}</span> <span className="text-fg">{t.title}</span>{t.detail && <span className="text-fg-3"> · {t.detail}</span>}</li>))}</ol></div>
      <div><h3 className="mb-2 text-xs font-semibold text-fg-2">Latest records</h3>
        <Table><thead><tr><Th>Seq</Th><Th>Temp</Th><Th>Integrity</Th></tr></thead><tbody>{[...series].reverse().slice(0, 6).map((r) => <tr key={r.id}><Td className="tnum">#{r.sequence}</Td><Td className="tnum">{fmtTemp(r.temperatureC)}</Td><Td><IntegrityBadge status={r.integrity.status} /></Td></tr>)}</tbody></Table></div>
    </div>
  );
}
