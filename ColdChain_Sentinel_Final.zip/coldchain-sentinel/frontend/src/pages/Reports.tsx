import { Download, FileCheck2, FileText, ShieldAlert, Thermometer, Truck } from "lucide-react";
import { type ReactNode, useState } from "react";
import { PageHeader } from "../components/Shell";
import { useToast } from "../components/Toast";
import { Button, Card, Field, Notice, inputCls } from "../components/ui";
import { downloadReport, qs } from "../lib/api";
import { useDevices, useShipments } from "../lib/queries";

export default function Reports() {
  const toast = useToast();
  const devices = useDevices();
  const shipments = useShipments();
  const [deviceId, setDeviceId] = useState("");
  const [shipmentId, setShipmentId] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [format, setFormat] = useState<"csv" | "json">("csv");
  const [busy, setBusy] = useState("");
  const iso = (v: string) => (v ? new Date(v).toISOString() : undefined);
  const base = { deviceId: deviceId || undefined, from: iso(from), to: iso(to), format };

  const run = async (key: string, path: string) => {
    setBusy(key);
    try { toast.push("ok", `Saved ${await downloadReport(path)}`); } catch (e) { toast.push("bad", e instanceof Error ? e.message : "Export failed"); } finally { setBusy(""); }
  };
  const Row = ({ id, icon, title, text, path }: { id: string; icon: ReactNode; title: string; text: string; path: string }) => (
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line-soft py-3 first:border-t-0 first:pt-0">
      <div className="flex min-w-0 items-start gap-3"><span className="mt-0.5 text-cyan">{icon}</span><div><div className="text-[13px] font-medium">{title}</div><p className="max-w-xl text-xs text-fg-3">{text}</p></div></div>
      <Button icon={<Download size={14} />} loading={busy === id} onClick={() => run(id, path)}>Download {format.toUpperCase()}</Button>
    </div>
  );
  return (
    <>
      <PageHeader title="Reports" description="Exports are generated on demand from the backend. Each file states when it was generated, its filters, the verification result and any exceptions." />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Filters" className="lg:col-span-1">
          <div className="space-y-3">
            <Field label="Device"><select className={inputCls} value={deviceId} onChange={(e) => setDeviceId(e.target.value)}><option value="">All devices</option>{(devices.data?.items ?? []).map((d) => <option key={d.id} value={d.id}>{d.id}</option>)}</select></Field>
            <Field label="Shipment" hint="Used by the temperature export and the shipment summary."><select className={inputCls} value={shipmentId} onChange={(e) => setShipmentId(e.target.value)}><option value="">All shipments</option>{(shipments.data?.items ?? []).map((s) => <option key={s.id} value={s.id}>{s.id}</option>)}</select></Field>
            <Field label="From"><input type="datetime-local" className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
            <Field label="To"><input type="datetime-local" className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} /></Field>
            <Field label="Format"><select className={inputCls} value={format} onChange={(e) => setFormat(e.target.value as "csv" | "json")}><option value="csv">CSV (opens in Excel)</option><option value="json">JSON</option></select></Field>
          </div>
        </Card>
        <Card title="Available reports" className="lg:col-span-2">
          <Row id="temp" icon={<Thermometer size={18} />} title="Temperature readings" text="Every reading with device, shipment, sensor status, source (hardware or simulated) and its latest integrity status." path={`/reports/temperature${qs({ ...base, shipmentId: shipmentId || undefined })}`} />
          <Row id="ledger" icon={<FileCheck2 size={18} />} title="Ledger verification report" text="Runs a fresh read-only verification when you click, then lists the result and every exception. No alerts or records are written." path={`/reports/ledger${qs(base)}`} />
          <Row id="inc" icon={<ShieldAlert size={18} />} title="Security incidents" text="Security and temperature alerts with severity, status, acknowledgement and resolution details." path={`/reports/incidents${qs(base)}`} />
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line-soft pt-3">
            <div className="flex items-start gap-3"><span className="mt-0.5 text-cyan"><Truck size={18} /></span><div><div className="text-[13px] font-medium">Shipment integrity summary</div><p className="max-w-xl text-xs text-fg-3">Temperature profile, excursions and a fresh integrity check limited to the shipment's time window. {shipmentId ? "" : "Choose a shipment first."}</p></div></div>
            <Button icon={<FileText size={14} />} disabled={!shipmentId} loading={busy === "ship"} onClick={() => run("ship", `/reports/shipments/${encodeURIComponent(shipmentId)}?format=${format}`)}>Download {format.toUpperCase()}</Button>
          </div>
        </Card>
      </div>
      <div className="mt-4"><Notice tone="info">Reports are educational prototype output. They are not certified, validated or regulator-approved and must not be used as proof of product safety.</Notice></div>
    </>
  );
}
