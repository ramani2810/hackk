import { useMutation, useQueryClient } from "@tanstack/react-query";
import { KeyRound, Plus, RefreshCw, ShieldOff } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, CopyButton, Dot, Empty, ErrorBox, Field, Modal, Notice, SourceBadge, Spinner, Table, Td, Th, inputCls, useNow } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { ago, fmtTemp } from "../lib/format";
import { useDevices } from "../lib/queries";
import type { Device } from "../lib/types";

export default function Devices() {
  const { isAdmin } = useAuth();
  const q = useDevices();
  const qc = useQueryClient();
  const toast = useToast();
  const now = useNow(1000);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", type: "ESP32" as "ESP32" | "SIMULATED", description: "" });
  const [secret, setSecret] = useState<{ id: string; value: string; rotated?: boolean } | null>(null);
  const [confirm, setConfirm] = useState<{ kind: "revoke" | "rotate"; dev: Device } | null>(null);
  const [err, setErr] = useState("");

  const create = useMutation({
    mutationFn: () => api.post<{ device: Device; secret: string | null }>("/devices", { id: form.id.trim(), name: form.name.trim(), type: form.type, description: form.description.trim() || null }),
    onSuccess: (r) => { setOpen(false); setErr(""); qc.invalidateQueries({ queryKey: ["devices"] }); if (r.secret) setSecret({ id: r.device.id, value: r.secret }); else toast.push("ok", `Device ${r.device.id} registered`); setForm({ id: "", name: "", type: "ESP32", description: "" }); },
    onError: (e) => setErr(e instanceof ApiError ? e.message : "Could not register the device"),
  });
  const credential = useMutation({
    mutationFn: ({ kind, id }: { kind: "revoke" | "rotate"; id: string }) => api.post<{ device: Device; secret?: string }>(`/devices/${encodeURIComponent(id)}/${kind}`),
    onSuccess: (r, v) => { setConfirm(null); qc.invalidateQueries({ queryKey: ["devices"] }); if (v.kind === "rotate" && r.secret) setSecret({ id: v.id, value: r.secret, rotated: true }); else toast.push("ok", `Credential revoked for ${v.id}`); },
    onError: (e) => { setConfirm(null); toast.push("bad", e instanceof ApiError ? e.message : "Failed"); },
  });

  const items = q.data?.items ?? [];
  return (
    <>
      <PageHeader title="Devices and sensors" description="Physical ESP32 devices authenticate each reading with an HMAC-SHA-256 signature. Simulated devices are internal and use no credentials."
        actions={isAdmin && <Button variant="primary" icon={<Plus size={14} />} onClick={() => setOpen(true)}>Register device</Button>} />
      {q.isLoading && <Spinner />}
      {q.isError && <ErrorBox error={q.error} retry={() => q.refetch()} />}
      {q.data && items.length === 0 && <Card><Empty title="No devices registered" action={isAdmin ? <Button variant="primary" onClick={() => setOpen(true)}>Register your first device</Button> : undefined}>Register an ESP32 to receive its secret, then flash the firmware.</Empty></Card>}
      {items.length > 0 && (
        <Card pad={false}>
          <Table>
            <thead><tr><Th>Device</Th><Th>Type</Th><Th>Status</Th><Th>Latest</Th><Th>Sensor</Th><Th>Firmware</Th><Th>Authentication</Th>{isAdmin && <Th>Credential</Th>}</tr></thead>
            <tbody>
              {items.map((d) => (
                <tr key={d.id} className="hover:bg-ink-800/40">
                  <Td><div className="font-medium">{d.id}</div><div className="text-[11px] text-fg-3">{d.name}</div></Td>
                  <Td><div className="flex flex-col items-start gap-1">{d.type === "ESP32" ? "ESP32 + DS18B20" : "Software simulator"}<SourceBadge source={d.source} /></div></Td>
                  <Td><span className="flex items-center gap-1.5"><Dot tone={d.online ? "ok" : d.connectivity === "NEVER_SEEN" ? "neutral" : "bad"} pulse={d.online} />{d.online ? "Online" : d.connectivity === "NEVER_SEEN" ? "Never seen" : "Offline"}</span><div className="text-[11px] text-fg-3">last seen {ago(d.lastSeenAt, now)}</div></Td>
                  <Td className="tnum">{d.latestTemperatureC !== null ? fmtTemp(d.latestTemperatureC) : <span className="text-fg-3">none</span>}<div className="text-[11px] text-fg-3">seq #{d.lastSequence}</div></Td>
                  <Td><Badge tone={d.sensorHealth === "OK" ? "ok" : d.sensorHealth === "UNKNOWN" ? "neutral" : "bad"}>{d.sensorHealth.toLowerCase()}</Badge></Td>
                  <Td className="text-fg-2">{d.firmwareVersion ?? "unknown"}</Td>
                  <Td>{d.type !== "ESP32" ? <span className="text-fg-3">internal</span> : (
                    <div><Badge tone={d.auth.status === "ACTIVE" ? "ok" : "bad"} icon={<KeyRound size={10} />}>{d.auth.status === "ACTIVE" ? "Credential active" : d.auth.status === "REVOKED" ? "Revoked" : "No credential"}</Badge>
                      <div className="mt-1 text-[11px] text-fg-3">{d.auth.method} · key {d.auth.fingerprint ?? "n/a"}</div>
                      {d.auth.lastUsedAt && <div className="text-[11px] text-fg-3">used {ago(d.auth.lastUsedAt, now)}</div>}</div>)}</Td>
                  {isAdmin && <Td>{d.type === "ESP32" ? <div className="flex gap-1.5">
                    <Button size="sm" icon={<RefreshCw size={12} />} onClick={() => setConfirm({ kind: "rotate", dev: d })}>Rotate</Button>
                    <Button size="sm" variant="danger" icon={<ShieldOff size={12} />} disabled={d.auth.status !== "ACTIVE"} onClick={() => setConfirm({ kind: "revoke", dev: d })}>Revoke</Button></div> : <span className="text-fg-3">n/a</span>}</Td>}
                </tr>))}
            </tbody>
          </Table>
        </Card>)}

      <Card className="mt-4" title="Connecting the ESP32">
        <ol className="list-decimal space-y-1 pl-5 text-[13px] text-fg-2">
          <li>Register the device above and copy its secret (it is shown only once).</li>
          <li>Copy <code className="hash">firmware/coldchain_esp32/config.example.h</code> to <code className="hash">config.h</code> and fill in Wi-Fi, device ID, secret and your laptop's LAN IP address as the backend URL (never <code className="hash">localhost</code>).</li>
          <li>Upload the sketch with the Arduino IDE. The device appears here as Online once the server accepts its first reading.</li>
        </ol>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Register device"
        footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" loading={create.isPending} disabled={!form.id || !form.name} onClick={() => create.mutate()}>Register device</Button></>}>
        <div className="space-y-3">
          {err && <Notice tone="bad">{err}</Notice>}
          <Field label="Device ID" hint="3-40 characters: letters, digits, - or _. Must match DEVICE_ID in the firmware."><input className={inputCls} value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} placeholder="COLD-BOX-02" autoFocus /></Field>
          <Field label="Display name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Vaccine cooler, truck 4" /></Field>
          <Field label="Device type"><select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as "ESP32" | "SIMULATED" })}><option value="ESP32">ESP32 hardware (gets a secret)</option><option value="SIMULATED">Simulated device</option></select></Field>
          <Field label="Description (optional)"><input className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
        </div>
      </Modal>

      <Modal open={!!secret} onClose={() => setSecret(null)} title={secret?.rotated ? "New device secret" : "Device registered"} footer={<Button variant="primary" onClick={() => setSecret(null)}>I have copied the secret</Button>}>
        {secret && <div className="space-y-3">
          <Notice tone="warn" title="Shown only once">Copy this secret into <code className="hash">config.h</code> now. The server stores it encrypted and cannot show it again. If you lose it, rotate the credential.</Notice>
          <div className="text-xs text-fg-3">Device ID</div><div className="font-medium">{secret.id}</div>
          <div className="text-xs text-fg-3">DEVICE_SECRET</div>
          <div className="flex items-center gap-1 rounded-md border border-line bg-ink-900 p-2"><span className="hash flex-1 select-all text-cyan">{secret.value}</span><CopyButton value={secret.value} label="Copy secret" /></div>
          {secret.rotated && <p className="text-xs text-fg-3">The previous secret stopped working immediately.</p>}
        </div>}
      </Modal>

      <Modal open={!!confirm} onClose={() => setConfirm(null)} title={confirm?.kind === "revoke" ? "Revoke credential?" : "Rotate credential?"}
        footer={<><Button onClick={() => setConfirm(null)}>Cancel</Button><Button variant="danger" loading={credential.isPending} onClick={() => confirm && credential.mutate({ kind: confirm.kind, id: confirm.dev.id })}>{confirm?.kind === "revoke" ? "Revoke credential" : "Rotate credential"}</Button></>}>
        <p className="text-[13px] text-fg-2">{confirm?.kind === "revoke" ? <>Device <b>{confirm?.dev.id}</b> will be unable to send readings until you rotate its credential. Requests signed with the old secret are rejected and raise a security alert.</> : <>A new secret is generated for <b>{confirm?.dev.id}</b> and the old one stops working immediately. You must update and re-flash the firmware.</>}</p>
      </Modal>
    </>
  );
}
