import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ChevronRight, FileSearch, Search, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, CopyButton, Drawer, Empty, ErrorBox, Field, HashText, IntegrityBadge, Notice, Pager, SourceBadge, Spinner, Stat, Table, Tabs, Td, Th, inputCls, useNow } from "../components/ui";
import { api, ApiError, qs } from "../lib/api";
import { ago, fmtFull, fmtTemp, fmtTime, humanize, num, short } from "../lib/format";
import { useDevices, useLedger, useLedgerSummary, useVerifications } from "../lib/queries";
import type { Failure, ReadingDetail, VerifyRun } from "../lib/types";
import TamperLab from "./TamperLab";

const STATUSES = ["VERIFIED", "UNVERIFIED", "INVALID_HASH", "BROKEN_LINK", "MISSING_RECORD", "SEQUENCE_GAP", "REORDERED", "CHECKPOINT_MISMATCH"];

export function FailureList({ failures, onOpen }: { failures: Failure[]; onOpen?: (id: string) => void }) {
  return (
    <ul className="space-y-2">
      {failures.slice(0, 50).map((f, i) => (
        <li key={i} className="rounded-md border border-bad/30 bg-bad-bg/40 p-2.5 text-xs">
          <div className="flex flex-wrap items-center gap-2"><IntegrityBadge status={f.kind} /><span className="text-fg-3">{f.deviceId}{f.sequence !== null ? ` · record #${f.sequence}` : ""}</span>
            {f.recordId && onOpen && <button className="ml-auto text-cyan hover:underline" onClick={() => onOpen(f.recordId!)}>Open record</button>}</div>
          <p className="mt-1.5 text-fg-2">{f.message}</p>
          {f.expected && <div className="mt-1.5 grid gap-0.5 text-[11px]"><div><span className="text-fg-3">Expected </span><span className="hash text-ok">{f.expected}</span></div>{f.actual && <div><span className="text-fg-3">Found </span><span className="hash text-bad">{f.actual}</span></div>}</div>}
        </li>))}
      {failures.length > 50 && <li className="text-xs text-fg-3">Showing the first 50 of {failures.length} failures. Download the ledger report for the complete list.</li>}
    </ul>
  );
}

export default function Ledger() {
  const { isAdmin } = useAuth();
  const [tab, setTab] = useState<"explorer" | "lab">("explorer");
  const status = useQuery({ queryKey: ["status"], queryFn: () => api.get<{ devEndpointsEnabled: boolean }>("/status") });
  const showLab = isAdmin && status.data?.devEndpointsEnabled;
  return (
    <>
      <PageHeader title="Integrity ledger" description="Every accepted reading is linked to the one before it with SHA-256. SHA-256 is a hash function (a one-way fingerprint), not encryption: it makes later edits detectable, it does not hide data." />
      {showLab && <div className="mb-4"><Tabs value={tab} onChange={setTab} items={[{ id: "explorer", label: "Ledger explorer" }, { id: "lab", label: "Tamper lab (demo)" }]} /></div>}
      {tab === "explorer" || !showLab ? <Explorer /> : <TamperLab />}
    </>
  );
}

function Explorer() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const now = useNow(1000);
  const summary = useLedgerSummary();
  const devices = useDevices();
  const runs = useVerifications();
  const [f, setF] = useState(() => { try { return JSON.parse(localStorage.getItem("cc.ledger.filters") ?? "{}") as Record<string, string>; } catch { return {}; } });
  const [qText, setQText] = useState(f.q ?? "");
  const [page, setPage] = useState(1);
  const [open, setOpen] = useState<string | null>(null);
  const [result, setResult] = useState<VerifyRun | null>(null);
  const [scope, setScope] = useState<"LEDGER" | "DEVICE" | "RANGE">("LEDGER");
  const [vDevice, setVDevice] = useState("");
  const [from, setFrom] = useState(""); const [to, setTo] = useState("");

  useEffect(() => { try { localStorage.setItem("cc.ledger.filters", JSON.stringify({ ...f, q: qText })); } catch { /* ignore */ } }, [f, qText]);
  useEffect(() => { const t = setTimeout(() => setPage(1), 0); return () => clearTimeout(t); }, [f.deviceId, f.status, f.source, qText]);
  const list = useLedger({ deviceId: f.deviceId, status: f.status, source: f.source, q: qText.trim() || undefined, page, pageSize: 25, order: "desc" });

  const verify = useMutation({
    mutationFn: () => api.post<VerifyRun>("/ledger/verify", {
      scope, ...(scope === "DEVICE" ? { deviceId: vDevice } : {}), ...(scope === "RANGE" ? { ...(vDevice ? { deviceId: vDevice } : {}), ...(from ? { from: new Date(from).toISOString() } : {}), ...(to ? { to: new Date(to).toISOString() } : {}) } : {}),
    }),
    onSuccess: (r) => { setResult(r); qc.invalidateQueries(); toast.push(r.status === "VERIFIED" ? "ok" : "bad", r.status === "VERIFIED" ? `Verified ${num(r.recordsChecked)} records` : `Verification failed: ${r.failures.length} problem(s) found`); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Verification could not run"),
  });
  const cp = useMutation({
    mutationFn: (deviceId: string) => api.post("/ledger/checkpoints", { deviceId }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["ledger"] }); toast.push("ok", "Signed checkpoint created"); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Checkpoint failed"),
  });

  const s = summary.data;
  const cs = s?.chainStatus;
  const failed = cs && cs.status === "VERIFICATION_FAILED";
  const rows = list.data?.items ?? [];
  const devs = devices.data?.items ?? [];

  return (
    <div className="space-y-4">
      {summary.isError && <ErrorBox error={summary.error} retry={() => summary.refetch()} />}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total records" value={s ? num(s.totalRecords) : "…"} sub={s ? `${s.chains.length} device chain(s)` : undefined} />
        <Stat label="Chain status" tone={!cs ? undefined : failed ? "bad" : cs.status === "VERIFIED" ? "ok" : "warn"}
          value={!cs ? "…" : cs.status === "VERIFIED" ? "Verified" : failed ? "Failed" : "Never verified"}
          sub={cs?.lastVerifiedAt ? `Last verified ${ago(cs.lastVerifiedAt, now)}` : "Run a verification below"} />
        <Stat label="Records since last check" value={cs ? num(cs.newRecordsSinceVerification) : "…"} sub={cs && cs.newRecordsSinceVerification > 0 ? "Not covered by the last verification" : "Fully covered"} tone={cs && cs.newRecordsSinceVerification > 0 && cs.status === "VERIFIED" ? "warn" : undefined} />
        <Stat label="Failed records" value={s ? num(s.failedRecords) : "…"} tone={s && s.failedRecords > 0 ? "bad" : undefined} sub={s ? `${num(s.verifiedRecords)} verified, ${num(s.unverifiedRecords)} unverified` : undefined} />
      </div>

      {cs?.status === "VERIFIED" && cs.newRecordsSinceVerification > 0 && <Notice tone="info">The last successful verification was {ago(cs.lastVerifiedAt, now)} and covered {num(cs.recordsChecked)} records. {num(cs.newRecordsSinceVerification)} newer record(s) show "Not yet verified" until you verify again.</Notice>}
      {failed && <Notice tone="bad" title="The last verification failed">Corrupted records are preserved exactly as found and are never repaired automatically. See the failure details below and the Security alerts page.</Notice>}

      <Card title="Verify the ledger" subtitle="Recalculates every SHA-256 hash from the stored fields, checks every link, sequence number and signed checkpoint.">
        {!isAdmin ? <p className="text-xs text-fg-3">Only administrators can start a verification. You can still see the result of the latest run above.</p> : (
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Scope"><select className={inputCls + " w-44"} value={scope} onChange={(e) => setScope(e.target.value as typeof scope)}><option value="LEDGER">Full ledger</option><option value="DEVICE">One device</option><option value="RANGE">Time range</option></select></Field>
            {scope !== "LEDGER" && <Field label={scope === "RANGE" ? "Device (optional)" : "Device"}><select className={inputCls + " w-48"} value={vDevice} onChange={(e) => setVDevice(e.target.value)}><option value="">{scope === "RANGE" ? "All devices" : "Choose a device"}</option>{devs.map((d) => <option key={d.id} value={d.id}>{d.id}</option>)}</select></Field>}
            {scope === "RANGE" && <><Field label="From"><input type="datetime-local" className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} /></Field><Field label="To"><input type="datetime-local" className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} /></Field></>}
            <Button variant="primary" icon={<ShieldCheck size={14} />} loading={verify.isPending} disabled={(scope === "DEVICE" && !vDevice) || (scope === "RANGE" && !from && !to)} onClick={() => verify.mutate()}>Verify chain</Button>
          </div>)}
        {result && (
          <div className="mt-4 space-y-3 border-t border-line-soft pt-4">
            <div className="flex flex-wrap items-center gap-2"><IntegrityBadge status={result.status === "VERIFIED" ? "VERIFIED" : "VERIFICATION_FAILED"} /><span className="text-xs text-fg-3">{num(result.recordsChecked)} records · {result.devicesChecked} device chain(s) · {result.checkpointsChecked} signed checkpoint(s) · {fmtFull(result.finishedAt)}</span></div>
            {result.failures.length === 0 ? <p className="text-xs text-ok">Every hash matched, every link was intact and no sequence number was missing.</p> : <FailureList failures={result.failures} onOpen={setOpen} />}
            {result.notes.length > 0 && <ul className="space-y-1 text-xs text-fg-3">{result.notes.slice(0, 5).map((n, i) => <li key={i}>Note: {n}</li>)}</ul>}
          </div>)}
      </Card>

      <Card title="Chain heads and signed checkpoints" pad={false} actions={<span className="text-[11px] text-fg-3" title={s?.checkpointInfo.storage}>Signing key id {s?.checkpointInfo.keyId ?? "…"}</span>}>
        {!s || s.chains.length === 0 ? <Empty title="No chains yet">The first reading from a device starts its chain at a documented genesis value.</Empty> : (
          <Table><thead><tr><Th>Device</Th><Th>Records</Th><Th>Head hash</Th><Th>Latest signed checkpoint</Th>{isAdmin && <Th />}</tr></thead>
            <tbody>{s.chains.map((c) => (<tr key={c.deviceId}><Td className="font-medium">{c.deviceId}</Td><Td className="tnum">{num(c.records)}</Td><Td><HashText value={c.headHash} /></Td>
              <Td className="text-xs">{c.lastCheckpoint ? <>up to #{c.lastCheckpoint.lastSequence}, {ago(c.lastCheckpoint.createdAt, now)}</> : <span className="text-fg-3">none yet</span>}</Td>
              {isAdmin && <Td><Button size="sm" loading={cp.isPending && cp.variables === c.deviceId} onClick={() => cp.mutate(c.deviceId)}>Create checkpoint</Button></Td>}</tr>))}</tbody></Table>)}
        {s && <p className="border-t border-line-soft px-4 py-3 text-[11px] text-fg-3">{s.checkpointInfo.limitation}</p>}
      </Card>

      <Card title="Records" pad={false}
        actions={<div className="flex flex-wrap items-center gap-2">
          <div className="relative"><Search size={13} className="pointer-events-none absolute left-2 top-2 text-fg-3" /><input aria-label="Search records" placeholder="Search hash, id or sequence" value={qText} onChange={(e) => setQText(e.target.value)} className={inputCls + " w-52 pl-7 text-xs"} /></div>
          <select aria-label="Device filter" value={f.deviceId ?? ""} onChange={(e) => setF({ ...f, deviceId: e.target.value })} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs"><option value="">All devices</option>{devs.map((d) => <option key={d.id} value={d.id}>{d.id}</option>)}</select>
          <select aria-label="Status filter" value={f.status ?? ""} onChange={(e) => setF({ ...f, status: e.target.value })} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs"><option value="">Any status</option>{STATUSES.map((x) => <option key={x} value={x}>{humanize(x)}</option>)}</select>
          <select aria-label="Source filter" value={f.source ?? ""} onChange={(e) => setF({ ...f, source: e.target.value })} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs"><option value="">Any source</option><option value="HARDWARE">Hardware</option><option value="SIMULATOR">Simulated</option></select>
        </div>}>
        {list.isLoading ? <Spinner /> : list.isError ? <div className="p-4"><ErrorBox error={list.error} retry={() => list.refetch()} /></div> : rows.length === 0 ? <Empty title="No records match">Change the filters, or start the simulator to create records.</Empty> : (
          <>
            <Table><thead><tr><Th>Device</Th><Th>Seq</Th><Th>Temperature</Th><Th>Server time</Th><Th>Chain link (previous → current)</Th><Th>Status</Th><Th /></tr></thead>
              <tbody>{rows.map((r) => (
                <tr key={r.id} className="cursor-pointer hover:bg-ink-800/50" onClick={() => setOpen(r.id)}>
                  <Td><div>{r.deviceId}</div><SourceBadge source={r.source} /></Td><Td className="tnum">#{r.sequence}{r.gapBefore > 0 && <Badge tone="warn" title={`${r.gapBefore} sequence number(s) skipped before this record`}>gap {r.gapBefore}</Badge>}</Td>
                  <Td className="tnum">{r.sensorStatus === "OK" ? fmtTemp(r.temperatureC) : <Badge tone="bad">{r.sensorStatus.toLowerCase()}</Badge>}</Td><Td className="tnum text-fg-2">{fmtTime(r.receivedAt, { date: true })}</Td>
                  <Td><span className="hash text-fg-3">{short(r.previousHash, 8)}</span> <ChevronRight size={11} className="inline text-fg-3" /> <span className="hash text-cyan">{short(r.hash, 8)}</span></Td>
                  <Td><IntegrityBadge status={r.integrity.status} />{r.integrity.verifiedAt && <div className="text-[10px] text-fg-3">checked {ago(r.integrity.verifiedAt, now)}</div>}</Td>
                  <Td><button aria-label={`Open record ${r.sequence}`} className="rounded p-1 text-fg-3 hover:bg-ink-700 hover:text-fg" onClick={(e) => { e.stopPropagation(); setOpen(r.id); }}><FileSearch size={14} /></button></Td>
                </tr>))}</tbody></Table>
            <Pager page={page} pageSize={25} total={list.data!.total} onPage={setPage} />
          </>)}
      </Card>

      {(runs.data?.items.length ?? 0) > 0 && (
        <Card title="Verification history" pad={false}><Table><thead><tr><Th>Finished</Th><Th>Scope</Th><Th>Result</Th><Th>Records</Th><Th>Problems</Th><Th>By</Th></tr></thead>
          <tbody>{runs.data!.items.map((r) => (<tr key={r.id} className="cursor-pointer hover:bg-ink-800/50" onClick={() => setResult(r)}><Td className="tnum">{fmtTime(r.finishedAt, { date: true })}</Td><Td>{r.scope === "LEDGER" ? "Full ledger" : r.scope === "DEVICE" ? r.deviceId : "Time range"}</Td><Td><IntegrityBadge status={r.status === "VERIFIED" ? "VERIFIED" : "VERIFICATION_FAILED"} /></Td><Td className="tnum">{num(r.recordsChecked)}</Td><Td className="tnum">{Object.values(r.failureCounts).reduce((a, b) => a + b, 0)}</Td><Td className="text-fg-3">{r.triggeredBy}</Td></tr>))}</tbody></Table></Card>)}

      <RecordDrawer id={open} onClose={() => setOpen(null)} onOpen={setOpen} />
    </div>
  );
}

function RecordDrawer({ id, onClose, onOpen }: { id: string | null; onClose: () => void; onOpen: (id: string) => void }) {
  const q = useQuery({ queryKey: ["reading", id], queryFn: () => api.get<ReadingDetail>(`/readings/${id}`), enabled: !!id });
  const now = useNow(5000);
  const r = q.data;
  return (
    <Drawer open={!!id} onClose={onClose} title={r ? `Record #${r.sequence} · ${r.deviceId}` : "Record"}>
      {q.isLoading && <Spinner />}{q.isError && <ErrorBox error={q.error} />}
      {r && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2"><IntegrityBadge status={r.integrity.status} /><SourceBadge source={r.source} />{r.integrity.verifiedAt ? <span className="text-xs text-fg-3">last checked {ago(r.integrity.verifiedAt, now)}</span> : <span className="text-xs text-fg-3">never checked</span>}</div>
          {r.integrity.status === "UNVERIFIED" && <Notice>This record has not been through a verification run yet, so it is not shown as verified.</Notice>}
          <dl className="grid grid-cols-[8.5rem,1fr] gap-y-2 text-xs">
            <dt className="text-fg-3">Record ID</dt><dd className="flex items-center gap-1 break-all"><span className="hash">{r.id}</span><CopyButton value={r.id} label="Copy ID" /></dd>
            <dt className="text-fg-3">Temperature</dt><dd className="tnum">{r.sensorStatus === "OK" ? fmtTemp(r.temperatureC, 3) : `no value (${r.sensorStatus.toLowerCase()})`}</dd>
            <dt className="text-fg-3">Shipment</dt><dd>{r.shipmentId ?? "none"}</dd>
            <dt className="text-fg-3">Device timestamp</dt><dd>{r.deviceTimestamp ? fmtFull(r.deviceTimestamp) : "none (device clock not synchronised)"}</dd>
            <dt className="text-fg-3">Server received</dt><dd>{fmtFull(r.receivedAt)}</dd>
            <dt className="text-fg-3">Firmware</dt><dd>{r.firmwareVersion ?? "unknown"}</dd>
            <dt className="text-fg-3">Skipped before</dt><dd>{r.gapBefore}</dd>
          </dl>
          <div className="rounded-md border border-line bg-ink-900 p-3">
            <div className="text-[11px] text-fg-3">Previous record hash (links to record before this one)</div><div className="mt-1"><HashText value={r.previousHash} full /></div>
            <div className="my-2 flex items-center gap-2 text-[11px] text-fg-3"><ArrowDown size={12} /> SHA-256 over the canonical form below</div>
            <div className="text-[11px] text-fg-3">This record's hash</div><div className="mt-1"><HashText value={r.hash} full tone={r.recomputedHash === r.hash ? "ok" : "bad"} /></div>
            <div className="mt-2 text-[11px]">{r.recomputedHash === r.hash ? <span className="text-ok">Recomputed hash from the stored fields matches.</span> : <span className="text-bad">Recomputed from the stored fields: <span className="hash">{r.recomputedHash}</span>. The stored fields do not produce the stored hash.</span>}</div>
          </div>
          <div><div className="mb-1 text-[11px] text-fg-3">Canonical serialization (what is hashed)</div><pre className="hash max-h-40 overflow-auto whitespace-pre-wrap rounded-md border border-line bg-ink-900 p-2 text-fg-2">{r.canonicalForm}</pre></div>
          <div className="flex gap-2">
            {r.previous && <Button size="sm" onClick={() => onOpen(r.previous!.id)}>Previous record #{r.previous.sequence}</Button>}
            {r.next && <Button size="sm" onClick={() => onOpen(r.next!.id)}>Next record #{r.next.sequence}</Button>}
          </div>
        </div>)}
    </Drawer>
  );
}
export { qs };
