import { type FormEvent, useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../app/auth";
import { Logo } from "../components/Shell";
import { Button, Field, Notice, inputCls } from "../components/ui";
import { ApiError } from "../lib/api";

export default function Login() {
  const { user, login, backendDown, loading } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const to = (loc.state as { from?: string } | null)?.from ?? "/app";
  if (user) return <Navigate to={to} replace />;
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try { await login(email, password); nav(to, { replace: true }); }
    catch (x) { setErr(x instanceof ApiError ? (x.status === 429 ? "Too many failed attempts. Wait a few minutes and try again." : x.message) : "Sign-in failed"); }
    finally { setBusy(false); }
  };
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-6 flex items-center justify-center gap-2 text-lg font-semibold"><Logo size={26} /> ColdChain Sentinel</Link>
        <form onSubmit={submit} className="space-y-4 rounded-lg border border-line bg-ink-850 p-5">
          <h1 className="text-base font-semibold">Sign in</h1>
          {backendDown && !loading && <Notice tone="bad" title="Backend not reachable">Start the backend (see RUN_INSTRUCTIONS_WINDOWS.md), then reload this page.</Notice>}
          {err && <Notice tone="bad">{err}</Notice>}
          <Field label="E-mail"><input className={inputCls} type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus /></Field>
          <Field label="Password"><input className={inputCls} type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
          <Button type="submit" variant="primary" loading={busy} className="w-full">Sign in</Button>
          <p className="text-[11px] text-fg-3">Development accounts are created by <code className="hash">npm run db:seed</code>. The passwords are printed once in that terminal and stored in backend/.env if you set them there.</p>
        </form>
        <p className="mt-4 text-center text-xs text-fg-3"><Link to="/" className="hover:text-fg">Back to the overview page</Link></p>
      </div>
    </div>
  );
}
