import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, ErrorBox, Field, Modal, Notice, Spinner, Table, Td, Th, inputCls } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { fmtTime } from "../lib/format";
import { useSettings, useStatus } from "../lib/queries";

interface UserRow { id: string; email: string; name: string; role: string; disabled: boolean; lastLoginAt: string | null }

export default function Settings() {
  const { isAdmin, user } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const q = useSettings();
  const status = useStatus();
  const [f, setF] = useState({ tempMinC: "2", tempMaxC: "8", staleSeconds: "60", recoveryReadings: "2" });
  useEffect(() => { if (q.data) setF({ tempMinC: String(q.data.tempMinC), tempMaxC: String(q.data.tempMaxC), staleSeconds: String(q.data.staleSeconds), recoveryReadings: String(q.data.recoveryReadings) }); }, [q.data]);
  const save = useMutation({
    mutationFn: () => api.patch("/settings", { tempMinC: Number(f.tempMinC), tempMaxC: Number(f.tempMaxC), staleSeconds: Number(f.staleSeconds), recoveryReadings: Number(f.recoveryReadings) }),
    onSuccess: () => { qc.invalidateQueries(); toast.push("ok", "Settings saved"); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Could not save"),
  });
  const users = useQuery({ queryKey: ["users"], queryFn: () => api.get<{ items: UserRow[] }>("/users"), enabled: isAdmin });
  const [open, setOpen] = useState(false);
  const [u, setU] = useState({ email: "", name: "", role: "VIEWER", password: "" });
  const [err, setErr] = useState("");
  const addUser = useMutation({
    mutationFn: () => api.post("/users", u),
    onSuccess: () => { setOpen(false); setErr(""); setU({ email: "", name: "", role: "VIEWER", password: "" }); qc.invalidateQueries({ queryKey: ["users"] }); toast.push("ok", "User created"); },
    onError: (e) => setErr(e instanceof ApiError ? e.message : "Failed"),
  });
  const toggle = useMutation({
    mutationFn: ({ id, disabled }: { id: string; disabled: boolean }) => api.patch(`/users/${id}`, { disabled }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }), onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Failed"),
  });
  const invalid = !(Number(f.tempMinC) < Number(f.tempMaxC));

  return (
    <>
      <PageHeader title="Settings" description="Alert thresholds apply to every device and shipment without its own range." />
      {q.isLoading && <Spinner />}{q.isError && <ErrorBox error={q.error} retry={() => q.refetch()} />}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Temperature and alert rules" subtitle="The 2 to 8 °C default is a sample for demonstration. Use the storage limits of the actual product.">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Minimum safe temperature (°C)"><input type="number" step="0.1" disabled={!isAdmin} className={inputCls} value={f.tempMinC} onChange={(e) => setF({ ...f, tempMinC: e.target.value })} /></Field>
            <Field label="Maximum safe temperature (°C)"><input type="number" step="0.1" disabled={!isAdmin} className={inputCls} value={f.tempMaxC} onChange={(e) => setF({ ...f, tempMaxC: e.target.value })} /></Field>
            <Field label="Mark a device offline after (seconds)" hint="No accepted reading for this long raises a stale-readings alert."><input type="number" min={5} disabled={!isAdmin} className={inputCls} value={f.staleSeconds} onChange={(e) => setF({ ...f, staleSeconds: e.target.value })} /></Field>
            <Field label="Readings needed to end an excursion" hint="Consecutive in-range readings."><input type="number" min={1} max={20} disabled={!isAdmin} className={inputCls} value={f.recoveryReadings} onChange={(e) => setF({ ...f, recoveryReadings: e.target.value })} /></Field>
          </div>
          {invalid && <p className="mt-2 text-xs text-bad">Minimum must be lower than maximum.</p>}
          {isAdmin ? <div className="mt-4"><Button variant="primary" loading={save.isPending} disabled={invalid} onClick={() => save.mutate()}>Save settings</Button></div> : <p className="mt-4 text-xs text-fg-3">Only administrators can change settings.</p>}
        </Card>
        <Card title="This installation">
          <dl className="grid grid-cols-[9rem,1fr] gap-y-2 text-xs">
            <dt className="text-fg-3">Signed in as</dt><dd>{user?.email} <Badge>{user?.role === "ADMIN" ? "Administrator" : "Viewer"}</Badge></dd>
            <dt className="text-fg-3">Environment</dt><dd>{status.data?.environment ?? "…"}</dd>
            <dt className="text-fg-3">Mode</dt><dd>{status.data?.mode === "LIVE_HARDWARE" ? "Live hardware" : "Simulation"}</dd>
            <dt className="text-fg-3">Dev endpoints</dt><dd>{status.data?.devEndpointsEnabled ? "Enabled (simulator and tamper lab)" : "Disabled"}</dd>
            <dt className="text-fg-3">Theme</dt><dd>Dark (navy)</dd>
          </dl>
          <div className="mt-4"><Notice tone="info">Filters and the sidebar state are remembered in this browser only. Nothing sensitive is stored there.</Notice></div>
        </Card>
        {isAdmin && (
          <Card className="lg:col-span-2" title="Users" pad={false} actions={<Button size="sm" variant="primary" onClick={() => setOpen(true)}>Add user</Button>}>
            {users.isLoading ? <Spinner /> : users.isError ? <div className="p-4"><ErrorBox error={users.error} /></div> : (
              <Table><thead><tr><Th>Name</Th><Th>E-mail</Th><Th>Role</Th><Th>Last login</Th><Th>Status</Th><Th /></tr></thead>
                <tbody>{users.data!.items.map((x) => (<tr key={x.id}><Td>{x.name}</Td><Td className="text-fg-2">{x.email}</Td><Td>{x.role === "ADMIN" ? "Administrator" : "Viewer"}</Td><Td className="text-fg-2">{x.lastLoginAt ? fmtTime(x.lastLoginAt, { date: true }) : "never"}</Td>
                  <Td><Badge tone={x.disabled ? "bad" : "ok"}>{x.disabled ? "Disabled" : "Active"}</Badge></Td>
                  <Td>{x.id !== user?.id && <Button size="sm" variant={x.disabled ? "secondary" : "danger"} onClick={() => toggle.mutate({ id: x.id, disabled: !x.disabled })}>{x.disabled ? "Enable" : "Disable"}</Button>}</Td></tr>))}</tbody></Table>)}
          </Card>)}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Add user" footer={<><Button onClick={() => setOpen(false)}>Cancel</Button><Button variant="primary" loading={addUser.isPending} disabled={!u.email || !u.name || u.password.length < 10} onClick={() => addUser.mutate()}>Add user</Button></>}>
        <div className="space-y-3">{err && <Notice tone="bad">{err}</Notice>}
          <Field label="Name"><input className={inputCls} value={u.name} onChange={(e) => setU({ ...u, name: e.target.value })} autoFocus /></Field>
          <Field label="E-mail"><input type="email" className={inputCls} value={u.email} onChange={(e) => setU({ ...u, email: e.target.value })} /></Field>
          <Field label="Role"><select className={inputCls} value={u.role} onChange={(e) => setU({ ...u, role: e.target.value })}><option value="VIEWER">Viewer (read-only)</option><option value="ADMIN">Administrator</option></select></Field>
          <Field label="Password" hint="At least 10 characters."><input type="password" autoComplete="new-password" className={inputCls} value={u.password} onChange={(e) => setU({ ...u, password: e.target.value })} /></Field></div>
      </Modal>
    </>
  );
}
