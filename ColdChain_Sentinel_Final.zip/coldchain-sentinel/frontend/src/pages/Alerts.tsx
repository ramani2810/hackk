import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, CheckCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { useToast } from "../components/Toast";
import { Badge, Button, Card, Empty, ErrorBox, Field, Modal, Pager, SeverityBadge, Spinner, Tabs, inputCls, useNow } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { ago, dur, fmtTime, humanize } from "../lib/format";
import { useAlerts } from "../lib/queries";
import type { Alert } from "../lib/types";

export default function Alerts() {
  const { isAdmin } = useAuth();
  const toast = useToast();
  const qc = useQueryClient();
  const now = useNow(1000);
  const [cat, setCat] = useState<"SECURITY" | "TEMPERATURE">(() => { try { return (localStorage.getItem("cc.alerts.cat") as "SECURITY" | "TEMPERATURE") || "SECURITY"; } catch { return "SECURITY"; } });
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [resolve, setResolve] = useState<Alert | null>(null);
  const [note, setNote] = useState("");
  useEffect(() => { try { localStorage.setItem("cc.alerts.cat", cat); } catch { /* ignore */ } setPage(1); }, [cat, status]);
  const q = useAlerts({ category: cat, status: status || undefined, scope: "LIVE", page, pageSize: 20 });
  const counts = { sec: useAlerts({ category: "SECURITY", status: "OPEN", scope: "LIVE", pageSize: 1 }).data?.total, tmp: useAlerts({ category: "TEMPERATURE", status: "OPEN", scope: "LIVE", pageSize: 1 }).data?.total };

  const ack = useMutation({
    mutationFn: (id: string) => api.patch(`/alerts/${id}/acknowledge`, {}),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["alerts"] }); toast.push("ok", "Alert acknowledged"); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Failed"),
  });
  const res = useMutation({
    mutationFn: () => api.patch(`/alerts/${resolve!.id}/resolve`, { note: note.trim() }),
    onSuccess: () => { setResolve(null); setNote(""); qc.invalidateQueries({ queryKey: ["alerts"] }); toast.push("ok", "Alert resolved"); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Failed"),
  });
  const items = q.data?.items ?? [];

  return (
    <>
      <PageHeader title="Security alerts" description="Security alerts mean data integrity or device authentication is in question. Temperature alerts mean a genuine measurement was unsafe or a sensor stopped reporting. The two are tracked separately on purpose." />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Tabs value={cat} onChange={setCat} items={[{ id: "SECURITY", label: "Security and integrity", count: counts.sec }, { id: "TEMPERATURE", label: "Temperature and device health", count: counts.tmp }]} />
        <select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs"><option value="">Open and resolved</option><option value="OPEN">Open only</option><option value="RESOLVED">Resolved only</option></select>
      </div>
      {q.isLoading && <Spinner />}{q.isError && <ErrorBox error={q.error} retry={() => q.refetch()} />}
      {q.data && items.length === 0 && <Card><Empty title={cat === "SECURITY" ? "No security alerts" : "No temperature alerts"}>{cat === "SECURITY" ? "Alerts appear when verification finds tampering, or when a device fails authentication." : "Alerts appear when a reading leaves the allowed range, a sensor fails or a device stops reporting."}</Empty></Card>}
      <div className="space-y-2.5">
        {items.map((a) => (
          <Card key={a.id} className={a.status === "OPEN" && (a.severity === "CRITICAL" || a.severity === "HIGH") ? "border-bad/40" : ""}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2"><SeverityBadge s={a.severity} /><Badge>{humanize(a.kind)}</Badge><Badge tone={a.status === "OPEN" ? "warn" : "ok"}>{a.status === "OPEN" ? "Open" : "Resolved"}</Badge>{a.acknowledged && <Badge tone="info" icon={<Check size={10} />}>Acknowledged</Badge>}</div>
                <h3 className="mt-1.5 text-[14px] font-medium">{a.title}</h3>
                <p className="mt-1 max-w-3xl text-xs text-fg-2">{a.description}</p>
                <dl className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[11px] text-fg-3">
                  <div>Raised {fmtTime(a.createdAt, { date: true })} ({ago(a.createdAt, now)})</div>{a.deviceId && <div>Device {a.deviceId}</div>}{a.shipmentId && <div>Shipment {a.shipmentId}</div>}
                  {a.recordId && <div>Record <span className="hash">{a.recordId.slice(0, 8)}</span></div>}
                  {a.kind === "TEMP_EXCURSION" && a.durationSeconds !== null && <div>Duration {dur(a.durationSeconds)}{a.status === "OPEN" ? " and counting" : ""}</div>}
                  {typeof a.details.peakC === "number" && <div>Peak {(a.details.peakC as number).toFixed(2)} °C</div>}
                  {a.acknowledgedBy && <div>Acknowledged by {a.acknowledgedBy}</div>}
                  {a.resolvedAt && <div>Resolved {fmtTime(a.resolvedAt, { date: true })} by {a.resolvedBy}{a.resolutionNote ? `: ${a.resolutionNote}` : ""}</div>}
                </dl>
              </div>
              {isAdmin && a.status === "OPEN" && <div className="flex gap-2">{!a.acknowledged && <Button size="sm" icon={<Check size={13} />} loading={ack.isPending && ack.variables === a.id} onClick={() => ack.mutate(a.id)}>Acknowledge</Button>}<Button size="sm" icon={<CheckCheck size={13} />} onClick={() => { setResolve(a); setNote(""); }}>Resolve</Button></div>}
            </div>
          </Card>))}
      </div>
      {q.data && q.data.total > 20 && <div className="mt-3 rounded-lg border border-line bg-ink-850"><Pager page={page} pageSize={20} total={q.data.total} onPage={setPage} /></div>}
      <Modal open={!!resolve} onClose={() => setResolve(null)} title="Resolve alert"
        footer={<><Button onClick={() => setResolve(null)}>Cancel</Button><Button variant="primary" disabled={!note.trim()} loading={res.isPending} onClick={() => res.mutate()}>Resolve alert</Button></>}>
        <p className="mb-3 text-[13px] text-fg-2">{resolve?.title}</p>
        <Field label="What was done?" hint="Recorded in the audit log together with your name."><textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} className={inputCls} autoFocus placeholder="Example: Verified the probe, door seal replaced" /></Field>
        {resolve?.category === "SECURITY" && <p className="mt-3 text-xs text-warn">Resolving an integrity alert does not repair the ledger. The affected records stay exactly as they were found.</p>}
      </Modal>
    </>
  );
}
