import { Link } from "react-router-dom";
import { Activity, AlertTriangle, CheckCircle2, Cpu, Database, FileCheck2, Gauge, Thermometer, Truck, XCircle } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../app/auth";
import { PageHeader } from "../components/Shell";
import { TempChart } from "../components/TempChart";
import { Badge, Button, Card, Dot, Empty, ErrorBox, IntegrityBadge, Notice, SeverityBadge, SourceBadge, Spinner, Stat, Table, Td, Th } from "../components/ui";
import { ago, dur, fmtTemp, fmtTime, humanize, num } from "../lib/format";
import { useOverview, useReadings } from "../lib/queries";
import { useNow } from "../components/ui";

export default function Overview() {
  const ov = useOverview();
  const { isAdmin } = useAuth();
  const now = useNow(1000);
  const [deviceId, setDeviceId] = useState<string>("");
  const devices = ov.data?.devices ?? [];
  useEffect(() => {
    if (!deviceId && devices.length) setDeviceId((devices.find((d) => d.online) ?? devices.find((d) => d.lastSeenAt) ?? devices[0]!).id);
  }, [devices, deviceId]);
  const hist = useReadings({ deviceId: deviceId || undefined, order: "desc", pageSize: 120 });
  const series = useMemo(() => [...(hist.data?.items ?? [])].reverse(), [hist.data]);

  if (ov.isLoading) return <Spinner label="Loading overview" />;
  if (ov.isError) return <ErrorBox error={ov.error} retry={() => ov.refetch()} />;
  const d = ov.data!;
  const k = d.kpis;
  const lv = d.latestVerification;
  const noData = k.totalRecords === 0;

  return (
    <>
      <PageHeader title="Overview" description="Everything on this page is read from the running backend. Allowed range for this demonstration is configurable in Settings; real limits must follow the monitored product's requirements."
        actions={<Badge tone={d.mode.mode === "LIVE_HARDWARE" ? "ok" : "warn"}>{d.mode.mode === "LIVE_HARDWARE" ? "Live hardware reporting" : "Simulation mode"}</Badge>} />
      {d.mode.mode === "SIMULATION" && <div className="mb-4"><Notice tone="warn" title="Showing simulated data">{d.mode.explanation} Every simulated record is labelled "Simulated" and is never mixed up with ESP32 readings.</Notice></div>}

      {noData && (
        <Card className="mb-4"><Empty title="No readings yet" action={isAdmin ? <Link to="/app/live"><Button variant="primary">Start the simulator</Button></Link> : undefined}>
          The ledger is empty. {isAdmin ? "Start the simulator on the Live monitoring page, or connect an ESP32." : "Ask an administrator to start the simulator or connect a device."}</Empty></Card>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Registered devices" value={k.devicesTotal} icon={<Cpu size={14} />} sub={`${d.devices.filter((x) => x.type === "ESP32").length} hardware, ${d.devices.filter((x) => x.type === "SIMULATED").length} simulated`} />
        <Stat label="Devices online" value={`${k.devicesOnline} / ${k.devicesTotal}`} icon={<Activity size={14} />} tone={k.devicesOnline === 0 ? "warn" : "ok"} sub="From server last-seen time" />
        <Stat label="Latest temperature" value={k.latestTemperature ? fmtTemp(k.latestTemperature.temperatureC) : "no data"} icon={<Thermometer size={14} />}
          tone={k.latestTemperature && (k.latestTemperature.temperatureC > d.settings.tempMaxC || k.latestTemperature.temperatureC < d.settings.tempMinC) ? "warn" : undefined}
          sub={k.latestTemperature ? <>{k.latestTemperature.deviceId} {ago(k.latestTemperature.receivedAt, now)}</> : "Waiting for a reading"} />
        <Stat label="Temperature excursions" value={k.excursionsTotal} icon={<AlertTriangle size={14} />} tone={k.excursionsOpen > 0 ? "warn" : undefined} sub={k.excursionsOpen > 0 ? `${k.excursionsOpen} still open` : "None open"} />
        <Stat label="Sensor records" value={num(k.totalRecords)} icon={<Database size={14} />} sub="In the hash-chained ledger" />
        <Stat label="Verified records" value={num(k.verifiedRecords)} icon={<CheckCircle2 size={14} />} tone={k.verifiedRecords > 0 ? "ok" : undefined} sub={k.unverifiedRecords > 0 ? `${num(k.unverifiedRecords)} not yet verified` : "All checked"} />
        <Stat label="Integrity violations" value={k.failedRecords} icon={<XCircle size={14} />} tone={k.failedRecords > 0 ? "bad" : undefined} sub={k.integrityViolationsOpen > 0 ? `${k.integrityViolationsOpen} open security alerts` : "No open integrity alerts"} />
        <Stat label="Last successful verification" value={k.lastSuccessfulVerificationAt ? ago(k.lastSuccessfulVerificationAt, now) : "never"} icon={<FileCheck2 size={14} />} sub={k.lastSuccessfulVerificationAt ? fmtTime(k.lastSuccessfulVerificationAt, { date: true }) : "Run a verification on the ledger page"} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="Temperature history" subtitle={`Safe band ${d.settings.tempMinC}–${d.settings.tempMaxC} °C. Amber dots are out-of-range readings.`}
          actions={<select aria-label="Device" value={deviceId} onChange={(e) => setDeviceId(e.target.value)} className="rounded-md border border-line bg-ink-900 px-2 py-1 text-xs">{devices.map((x) => <option key={x.id} value={x.id}>{x.id}</option>)}</select>}>
          {hist.isLoading ? <Spinner /> : series.length === 0 ? <Empty title="No readings for this device yet" /> : <TempChart readings={series} minC={d.settings.tempMinC} maxC={d.settings.tempMaxC} />}
        </Card>

        <Card title="Latest ledger verification" subtitle="Result of the last real verification run">
          {!lv ? <Empty title="Never verified" action={isAdmin ? <Link to="/app/ledger"><Button size="sm" variant="primary">Open ledger and verify</Button></Link> : undefined}>No verification has run yet, so no record is marked as verified.</Empty> : (
            <div className="space-y-3">
              <div className="flex items-center gap-2"><IntegrityBadge status={lv.status === "VERIFIED" ? "VERIFIED" : "VERIFICATION_FAILED"} /><span className="text-xs text-fg-3">{ago(lv.finishedAt, now)}</span></div>
              <dl className="grid grid-cols-2 gap-y-2 text-xs">
                <dt className="text-fg-3">Scope</dt><dd>{lv.scope === "LEDGER" ? "Whole ledger" : lv.scope === "DEVICE" ? lv.deviceId : "Time range"}</dd>
                <dt className="text-fg-3">Records checked</dt><dd className="tnum">{num(lv.recordsChecked)}</dd>
                <dt className="text-fg-3">Signed checkpoints</dt><dd className="tnum">{lv.checkpointsChecked}</dd>
                <dt className="text-fg-3">Finished</dt><dd>{fmtTime(lv.finishedAt, { date: true })}</dd>
              </dl>
              {Object.keys(lv.failureCounts).length > 0 && <div className="flex flex-wrap gap-1">{Object.entries(lv.failureCounts).map(([kind, c]) => <Badge key={kind} tone="bad">{humanize(kind)} x{c}</Badge>)}</div>}
              <Link to="/app/ledger" className="text-xs text-cyan hover:underline">Open the integrity ledger</Link>
            </div>
          )}
        </Card>

        <Card className="xl:col-span-2" title="Recent readings" pad={false} actions={<Link to="/app/live" className="text-xs text-cyan hover:underline">Live monitoring</Link>}>
          {d.recentReadings.length === 0 ? <Empty title="No readings yet" /> : (
            <Table><thead><tr><Th>Time</Th><Th>Device</Th><Th>Temperature</Th><Th>Source</Th><Th>Integrity</Th></tr></thead>
              <tbody>{d.recentReadings.map((r) => (
                <tr key={r.id} className="hover:bg-ink-800/50">
                  <Td className="tnum text-fg-2">{fmtTime(r.receivedAt)}</Td><Td>{r.deviceId}</Td>
                  <Td className="tnum">{r.sensorStatus === "OK" ? <span className={r.temperatureC! > d.settings.tempMaxC || r.temperatureC! < d.settings.tempMinC ? "text-warn" : ""}>{fmtTemp(r.temperatureC)}</span> : <Badge tone="bad">{humanize(r.sensorStatus)}</Badge>}</Td>
                  <Td><SourceBadge source={r.source} /></Td><Td><IntegrityBadge status={r.integrity.status} /></Td>
                </tr>))}</tbody></Table>)}
        </Card>

        <Card title="Device connectivity" pad={false} actions={<Link to="/app/devices" className="text-xs text-cyan hover:underline">Manage</Link>}>
          <ul className="divide-y divide-line-soft">
            {d.devices.map((x) => (
              <li key={x.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="min-w-0"><div className="flex items-center gap-2"><Dot tone={x.online ? "ok" : x.connectivity === "NEVER_SEEN" ? "neutral" : "bad"} pulse={x.online} /><span className="truncate text-[13px]">{x.id}</span></div>
                  <div className="ml-4 text-[11px] text-fg-3">{x.connectivity === "NEVER_SEEN" ? "Never reported" : `Seen ${ago(x.lastSeenAt, now)}`} · sensor {x.sensorHealth.toLowerCase()}</div></div>
                <div className="text-right"><SourceBadge source={x.source} /><div className="mt-0.5 text-[12px] tnum text-fg-2">{x.latestTemperatureC !== null ? fmtTemp(x.latestTemperatureC) : ""}</div></div>
              </li>))}
          </ul>
        </Card>

        <Card title="Recent security events" pad={false} actions={<Link to="/app/alerts" className="text-xs text-cyan hover:underline">All alerts</Link>}>
          {d.recentSecurityAlerts.length === 0 ? <Empty title="No security events">Integrity alerts appear here when verification fails or a device authenticates incorrectly.</Empty> : (
            <ul className="divide-y divide-line-soft">{d.recentSecurityAlerts.map((a) => (
              <li key={a.id} className="px-4 py-2.5"><div className="flex items-center justify-between gap-2"><span className="truncate text-[13px]">{a.title}</span><SeverityBadge s={a.severity} /></div>
                <div className="mt-0.5 text-[11px] text-fg-3">{a.deviceId ?? "no device"} · {ago(a.createdAt, now)} · {a.status === "OPEN" ? "open" : "resolved"}</div></li>))}</ul>)}
        </Card>

        <Card title="Temperature excursions" pad={false}>
          {d.recentTemperatureAlerts.filter((a) => a.kind === "TEMP_EXCURSION" || a.kind === "TEMP_RECOVERED").length === 0 ? <Empty title="No excursions recorded" /> : (
            <ul className="divide-y divide-line-soft">{d.recentTemperatureAlerts.filter((a) => a.kind === "TEMP_EXCURSION" || a.kind === "TEMP_RECOVERED").slice(0, 5).map((a) => (
              <li key={a.id} className="px-4 py-2.5"><div className="flex items-center justify-between gap-2"><span className="truncate text-[13px]">{a.title}</span>{a.status === "OPEN" ? <Badge tone="warn">Open</Badge> : <Badge>Resolved</Badge>}</div>
                <div className="mt-0.5 text-[11px] text-fg-3">{a.deviceId} · {ago(a.createdAt, now)}{a.durationSeconds !== null && a.kind === "TEMP_EXCURSION" ? ` · ${dur(a.durationSeconds)}` : ""}</div></li>))}</ul>)}
        </Card>

        <Card title="Shipments" pad={false} actions={<Link to="/app/shipments" className="text-xs text-cyan hover:underline">All shipments</Link>}>
          {d.shipments.items.length === 0 ? <Empty title="No shipments">Create one on the Shipments page.</Empty> : (
            <ul className="divide-y divide-line-soft">{d.shipments.items.map((s) => (
              <li key={s.id} className="px-4 py-2.5"><div className="flex items-center justify-between gap-2"><span className="flex items-center gap-1.5 truncate text-[13px]"><Truck size={13} className="text-fg-3" />{s.id}</span><Badge tone={s.status === "IN_TRANSIT" ? "info" : "neutral"}>{humanize(s.status)}</Badge></div>
                <div className="mt-0.5 text-[11px] text-fg-3">{s.deviceId ?? "no device"} · {s.excursionCount} excursions · {s.failedRecords} failed records</div></li>))}</ul>)}
        </Card>

        <Card title="Recent audit events" pad={false}>
          {d.recentAudit.length === 0 ? <Empty title="No audit events" /> : (
            <ul className="divide-y divide-line-soft">{d.recentAudit.map((e) => (
              <li key={e.id} className="px-4 py-2"><div className="text-[13px]">{e.action}</div><div className="text-[11px] text-fg-3">{e.actor} · {ago(e.ts, now)}</div></li>))}</ul>)}
        </Card>
      </div>
      <p className="mt-4 text-[11px] text-fg-3"><Gauge size={11} className="mr-1 inline" />Generated by the backend at {fmtTime(d.generatedAt, { date: true })}.</p>
    </>
  );
}
