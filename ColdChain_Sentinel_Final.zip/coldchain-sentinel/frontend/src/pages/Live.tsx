import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Flame, Pause, Play, PlugZap, RotateCcw, Zap } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../app/auth";
import { useLive } from "../app/live";
import { PageHeader } from "../components/Shell";
import { TempChart } from "../components/TempChart";
import { Badge, Button, Card, Dot, Empty, ErrorBox, Field, IntegrityBadge, Modal, Notice, SourceBadge, Spinner, Table, Td, Th, inputCls, useNow } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { ago, fmtFull, fmtTemp, fmtTime } from "../lib/format";
import { useDevices, useReadings, useSettings, useSimulator, useStatus } from "../lib/queries";
import { useToast } from "../components/Toast";

export default function Live() {
  const { isAdmin } = useAuth();
  const live = useLive();
  const toast = useToast();
  const qc = useQueryClient();
  const devices = useDevices();
  const settings = useSettings();
  const status = useStatus();
  const sim = useSimulator(isAdmin && !!status.data?.devEndpointsEnabled);
  const now = useNow(1000);
  const [sel, setSel] = useState("");
  const list = devices.data?.items ?? [];
  useEffect(() => { if (!sel && list.length) setSel((list.find((d) => d.online) ?? list.find((d) => d.lastSeenAt) ?? list[0]!).id); }, [list, sel]);
  const hist = useReadings({ deviceId: sel || undefined, order: "desc", pageSize: 90 });
  const series = useMemo(() => [...(hist.data?.items ?? [])].reverse(), [hist.data]);
  const latest = hist.data?.items[0];
  const dev = list.find((d) => d.id === sel);
  const th = settings.data ?? { tempMinC: 2, tempMaxC: 8, staleSeconds: 60 };
  const [confirmReset, setConfirmReset] = useState(false);
  const [interval, setIntervalSec] = useState(3);
  useEffect(() => { if (sim.data) setIntervalSec(sim.data.intervalSec); }, [sim.data?.intervalSec]);

  const act = useMutation({
    mutationFn: ({ path, body }: { path: string; body?: unknown; ok?: string }) => api.post<unknown>(path, body),
    onSuccess: (_d, v) => { if (v.ok) toast.push("ok", v.ok); qc.invalidateQueries(); },
    onError: (e) => toast.push("bad", e instanceof ApiError ? e.message : "Action failed"),
  });
  const simulated = list.filter((d) => d.type === "SIMULATED");
  const dev404 = status.data && !status.data.devEndpointsEnabled;

  const outOfRange = latest?.temperatureC !== null && latest?.temperatureC !== undefined && (latest.temperatureC > th.tempMaxC || latest.temperatureC < th.tempMinC);
  const age = latest ? Math.round((now - Date.parse(latest.receivedAt)) / 1000) : null;
  const fresh = age === null ? "none" : age <= Math.min(15, th.staleSeconds) ? "fresh" : age <= th.staleSeconds ? "aging" : "stale";

  return (
    <>
      <PageHeader title="Live monitoring" description="Current reading, history and thresholds for one device. Updates arrive through Socket.IO; if the socket drops, the page polls the API every few seconds."
        actions={<><Badge tone={live.connected ? "ok" : "warn"} icon={<Dot tone={live.connected ? "ok" : "warn"} pulse />}>{live.connected ? "Socket live" : "Polling fallback"}</Badge>
          <select aria-label="Device" value={sel} onChange={(e) => setSel(e.target.value)} className="rounded-md border border-line bg-ink-900 px-2 py-1.5 text-xs">{list.map((d) => <option key={d.id} value={d.id}>{d.id} ({d.type === "ESP32" ? "hardware" : "simulated"})</option>)}</select></>} />
      {devices.isError && <ErrorBox error={devices.error} retry={() => devices.refetch()} />}
      {devices.isLoading && <Spinner />}

      {dev && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className={outOfRange ? "border-warn/50" : ""} title="Current reading" actions={<SourceBadge source={dev.source} />}>
            {!latest ? <Empty title="No reading from this device yet">{dev.type === "ESP32" ? "Power the ESP32 and check its Wi-Fi and backend URL." : "Start the simulator below."}</Empty> : (
              <div>
                <div className="flex items-baseline gap-2">
                  <span className={`text-[44px] font-semibold leading-none tnum ${latest.sensorStatus !== "OK" ? "text-bad" : outOfRange ? "text-warn" : "text-fg"}`}>{latest.sensorStatus === "OK" ? latest.temperatureC!.toFixed(2) : "n/a"}</span>
                  <span className="text-lg text-fg-3">°C</span>
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                  {latest.sensorStatus !== "OK" ? <Badge tone="bad">Sensor {latest.sensorStatus.toLowerCase()}</Badge> : outOfRange ? <Badge tone="warn">Outside {th.tempMinC}–{th.tempMaxC} °C</Badge> : <Badge tone="ok">Within {th.tempMinC}–{th.tempMaxC} °C</Badge>}
                  <IntegrityBadge status={latest.integrity.status} />
                </div>
                <dl className="mt-4 grid grid-cols-[auto,1fr] gap-x-4 gap-y-1.5 text-xs">
                  <dt className="text-fg-3">Device</dt><dd>{latest.deviceId}</dd>
                  <dt className="text-fg-3">Shipment</dt><dd>{latest.shipmentId ?? dev.activeShipmentId ?? "not assigned"}</dd>
                  <dt className="text-fg-3">Humidity</dt><dd>{latest.humidityPct !== null ? `${latest.humidityPct} %` : "not measured (DS18B20 has no humidity sensor)"}</dd>
                  <dt className="text-fg-3">Device clock</dt><dd title={fmtFull(latest.deviceTimestamp)}>{latest.deviceTimestamp ? fmtTime(latest.deviceTimestamp, { date: true }) : "not synchronised"}</dd>
                  <dt className="text-fg-3">Server received</dt><dd title={fmtFull(latest.receivedAt)}>{fmtTime(latest.receivedAt, { date: true })}</dd>
                  <dt className="text-fg-3">Sequence</dt><dd className="tnum">#{latest.sequence}</dd>
                </dl>
              </div>)}
          </Card>

          <Card title="Device status">
            <dl className="grid grid-cols-[auto,1fr] gap-x-4 gap-y-2 text-xs">
              <dt className="text-fg-3">Connection</dt><dd className="flex items-center gap-1.5"><Dot tone={dev.online ? "ok" : dev.connectivity === "NEVER_SEEN" ? "neutral" : "bad"} pulse={dev.online} />{dev.online ? "Online" : dev.connectivity === "NEVER_SEEN" ? "Never reported" : "Offline"}</dd>
              <dt className="text-fg-3">Reading freshness</dt><dd><Badge tone={fresh === "fresh" ? "ok" : fresh === "aging" ? "warn" : fresh === "stale" ? "bad" : "neutral"}>{fresh === "none" ? "no data" : `${fresh}, ${ago(latest?.receivedAt, now)}`}</Badge></dd>
              <dt className="text-fg-3">Sensor health</dt><dd><Badge tone={dev.sensorHealth === "OK" ? "ok" : dev.sensorHealth === "UNKNOWN" ? "neutral" : "bad"}>{dev.sensorHealth.toLowerCase()}</Badge></dd>
              <dt className="text-fg-3">Last seen</dt><dd>{ago(dev.lastSeenAt, now)}</dd>
              <dt className="text-fg-3">Firmware</dt><dd>{dev.firmwareVersion ?? "unknown"}</dd>
              <dt className="text-fg-3">Offline after</dt><dd>{th.staleSeconds} s without a reading</dd>
              <dt className="text-fg-3">Open alerts</dt><dd>{dev.openAlerts}</dd>
            </dl>
            <div className="mt-3 text-[11px] text-fg-3">Online status comes from the time the server last accepted a reading, not from this page being open.</div>
          </Card>

          <Card title="Thresholds" subtitle="Demonstration range. Set the real limits for the actual product in Settings.">
            <div className="flex items-center gap-3 text-sm"><span className="rounded bg-ink-800 px-2 py-1 tnum">{th.tempMinC} °C</span><span className="text-fg-3">to</span><span className="rounded bg-ink-800 px-2 py-1 tnum">{th.tempMaxC} °C</span></div>
            <p className="mt-3 text-xs text-fg-3">An excursion opens on the first reading outside this range and closes after consecutive in-range readings (default 2). An unsafe temperature does not mean the record was tampered with; integrity is checked separately on the ledger page.</p>
          </Card>

          <Card className="lg:col-span-3" title={`Temperature history, ${sel}`} subtitle="Last 90 readings">
            {hist.isLoading ? <Spinner /> : series.length === 0 ? <Empty title="Nothing to plot yet" /> : <TempChart readings={series} minC={th.tempMinC} maxC={th.tempMaxC} height={280} />}
          </Card>

          <Card className="lg:col-span-3" title="Recent measurements" pad={false}>
            {(hist.data?.items.length ?? 0) === 0 ? <Empty title="No measurements" /> : (
              <Table><thead><tr><Th>Seq</Th><Th>Server time</Th><Th>Temperature</Th><Th>Sensor</Th><Th>Source</Th><Th>Integrity</Th></tr></thead>
                <tbody>{hist.data!.items.slice(0, 12).map((r) => (
                  <tr key={r.id}><Td className="tnum text-fg-3">#{r.sequence}</Td><Td className="tnum text-fg-2">{fmtTime(r.receivedAt)}</Td>
                    <Td className="tnum">{r.temperatureC !== null ? <span className={r.temperatureC > th.tempMaxC || r.temperatureC < th.tempMinC ? "text-warn" : ""}>{fmtTemp(r.temperatureC)}</span> : "n/a"}</Td>
                    <Td>{r.sensorStatus === "OK" ? "OK" : <Badge tone="bad">{r.sensorStatus.toLowerCase()}</Badge>}</Td><Td><SourceBadge source={r.source} /></Td><Td><IntegrityBadge status={r.integrity.status} /></Td></tr>))}</tbody></Table>)}
          </Card>
        </div>
      )}

      {isAdmin && (
        <Card className="mt-4" title="Simulator" subtitle="Generates readings for the simulated devices through the same ingestion, hash-chain and alert code as the ESP32."
          actions={sim.data && <Badge tone={sim.data.running ? "warn" : "neutral"} icon={<Dot tone={sim.data.running ? "warn" : "neutral"} pulse={sim.data.running} />}>{sim.data.running ? `Running, every ${sim.data.intervalSec} s` : "Stopped"}</Badge>}>
          {dev404 ? <Notice tone="info">Simulator controls are disabled because development endpoints are switched off on this server.</Notice> : !sim.data ? <Spinner /> : (
            <div className="space-y-4">
              <div className="flex flex-wrap items-end gap-3">
                <Field label="Sampling interval (seconds)"><input type="number" min={1} max={60} value={interval} onChange={(e) => setIntervalSec(Math.max(1, Math.min(60, Number(e.target.value) || 1)))} className={inputCls + " w-28"} /></Field>
                {sim.data.running
                  ? <><Button icon={<Pause size={14} />} loading={act.isPending} onClick={() => act.mutate({ path: "/dev/simulator/stop", ok: "Simulator stopped" })}>Stop simulator</Button>
                    <Button onClick={() => act.mutate({ path: "/dev/simulator/start", body: { intervalSec: interval }, ok: `Interval set to ${interval} s` })}>Apply interval</Button></>
                  : <Button variant="primary" icon={<Play size={14} />} loading={act.isPending} onClick={() => act.mutate({ path: "/dev/simulator/start", body: { intervalSec: interval }, ok: "Simulator started" })}>Start simulator</Button>}
                <Button icon={<Zap size={14} />} onClick={() => act.mutate({ path: "/dev/simulator/generate", body: { count: 30 }, ok: "Generated 30 readings per simulated device" })}>Generate 30 readings now</Button>
              </div>
              <div className="flex flex-wrap items-end gap-3 border-t border-line-soft pt-4">
                <Field label="Simulated device" hint="Event buttons act on this device">
                  <select value={sel} onChange={(e) => setSel(e.target.value)} className={inputCls + " w-56"}>{simulated.map((d) => <option key={d.id} value={d.id}>{d.id}</option>)}</select></Field>
                <Button icon={<Flame size={14} />} disabled={dev?.type !== "SIMULATED"} onClick={() => act.mutate({ path: "/dev/simulator/excursion", body: { deviceId: sel, peakC: 11, readings: 6 }, ok: `Excursion started on ${sel}. Keep the simulator running to see it.` })}>Trigger temperature excursion</Button>
                <Button icon={<PlugZap size={14} />} disabled={dev?.type !== "SIMULATED"} onClick={() => act.mutate({ path: "/dev/simulator/disconnect", body: { deviceId: sel, readings: 3 }, ok: `Sensor disconnect started on ${sel}` })}>Disconnect sensor</Button>
                <Button variant="danger" icon={<RotateCcw size={14} />} onClick={() => setConfirmReset(true)}>Reset demo data</Button>
              </div>
              {dev?.type === "ESP32" && <p className="text-xs text-fg-3">The selected device is physical hardware. Choose a simulated device to use the event buttons.</p>}
            </div>)}
        </Card>)}

      <Modal open={confirmReset} onClose={() => setConfirmReset(false)} title="Reset demo data?"
        footer={<><Button onClick={() => setConfirmReset(false)}>Cancel</Button><Button variant="danger" loading={act.isPending} onClick={() => { act.mutate({ path: "/dev/demo/reset", body: { confirm: true }, ok: "Simulated data removed" }); setConfirmReset(false); }}>Delete simulated data</Button></>}>
        <p className="text-[13px] text-fg-2">This stops the simulator and permanently deletes all readings, alerts and checkpoints of the <b>simulated</b> devices. Records from physical ESP32 devices are not touched. The action is written to the audit log.</p>
      </Modal>
    </>
  );
}
