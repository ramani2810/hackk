import clsx from "clsx";
import { Bell, ChevronsLeft, ChevronsRight, FileText, Gauge, HardDrive, LogOut, Menu, Radio, ScrollText, Settings as SettingsIcon, ShieldAlert, ShieldCheck, Truck, X, Link2, FlaskConical } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../app/auth";
import { useLive } from "../app/live";
import { useStatus } from "../lib/queries";
import { ago } from "../lib/format";
import { Badge, Dot, useNow } from "./ui";

const NAV = [
  { to: "/app", label: "Overview", icon: Gauge, end: true },
  { to: "/app/live", label: "Live monitoring", icon: Radio },
  { to: "/app/devices", label: "Devices and sensors", icon: HardDrive },
  { to: "/app/shipments", label: "Shipments", icon: Truck },
  { to: "/app/ledger", label: "Integrity ledger", icon: Link2 },
  { to: "/app/alerts", label: "Security alerts", icon: ShieldAlert },
  { to: "/app/audit", label: "Audit logs", icon: ScrollText, admin: true },
  { to: "/app/reports", label: "Reports", icon: FileText },
  { to: "/app/settings", label: "Settings", icon: SettingsIcon },
  { to: "/app/tamper-lab", label: "Tamper lab", icon: FlaskConical, admin: true, dev: true },
];

export function Logo({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <path d="M16 3.5 5.5 7.6v7.8c0 6.2 4.2 11 10.5 13.5 6.3-2.5 10.5-7.3 10.5-13.5V7.6z" fill="#0f2a44" stroke="#3cc8e8" strokeWidth="2" strokeLinejoin="round" />
      <path d="M16 9.5v8.2" stroke="#e6edf7" strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="16" cy="21.2" r="2.6" fill="#3cc8e8" />
    </svg>
  );
}

function SideNav({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const { isAdmin } = useAuth();
  const live = useLive();
  const devEnabled = useStatus().data?.devEndpointsEnabled ?? false;
  return (
    <nav aria-label="Main" className="flex flex-col gap-0.5 p-2">
      {NAV.filter((n) => (!n.admin || isAdmin) && (!("dev" in n) || devEnabled)).map((n) => (
        <NavLink key={n.to} to={n.to} end={n.end} onClick={() => { if (n.to === "/app/alerts") live.clearUnseen(); onNavigate?.(); }} title={collapsed ? n.label : undefined}
          className={({ isActive }) => clsx("group flex items-center gap-2.5 rounded-md px-2.5 py-2 text-[13px] transition-colors", isActive ? "bg-ink-700 text-fg" : "text-fg-3 hover:bg-ink-800 hover:text-fg", collapsed && "justify-center")}>
          <n.icon size={16} className="shrink-0" />
          {!collapsed && <span className="truncate">{n.label}</span>}
          {!collapsed && n.to === "/app/alerts" && live.unseenAlerts > 0 && <span className="ml-auto rounded-full bg-bad px-1.5 text-[10px] font-semibold text-ink-950 tnum">{live.unseenAlerts > 99 ? "99+" : live.unseenAlerts}</span>}
        </NavLink>
      ))}
    </nav>
  );
}

export function Shell() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const live = useLive();
  const status = useStatus();
  const now = useNow(1000);
  const [collapsed, setCollapsed] = useState(() => { try { return localStorage.getItem("cc.sidebar") === "1"; } catch { return false; } });
  const [mobile, setMobile] = useState(false);
  useEffect(() => { try { localStorage.setItem("cc.sidebar", collapsed ? "1" : "0"); } catch { /* storage unavailable */ } }, [collapsed]);
  useEffect(() => setMobile(false), [loc.pathname]);

  const s = status.data;
  const backendUp = !status.isError && !!s;
  const hardware = s?.mode === "LIVE_HARDWARE";
  const lastSync = s?.lastReadingAt ?? null;

  return (
    <div className="flex min-h-screen">
      <aside className={clsx("sticky top-0 hidden h-screen shrink-0 flex-col border-r border-line bg-ink-950 md:flex", collapsed ? "w-14" : "w-56")}>
        <Link to="/" className={clsx("flex h-14 items-center gap-2 border-b border-line-soft px-3", collapsed && "justify-center")} title="ColdChain Sentinel home">
          <Logo />{!collapsed && <span className="text-[14px] font-semibold tracking-tight">ColdChain Sentinel</span>}
        </Link>
        <div className="flex-1 overflow-y-auto"><SideNav collapsed={collapsed} /></div>
        <button onClick={() => setCollapsed((c) => !c)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"} className="flex h-10 items-center justify-center gap-2 border-t border-line-soft text-xs text-fg-3 hover:bg-ink-800 hover:text-fg">
          {collapsed ? <ChevronsRight size={15} /> : <><ChevronsLeft size={15} /> Collapse</>}
        </button>
      </aside>

      {mobile && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-ink-950/80" onClick={() => setMobile(false)} />
          <aside className="cc-in absolute left-0 top-0 h-full w-64 border-r border-line bg-ink-950">
            <div className="flex h-14 items-center justify-between border-b border-line-soft px-3">
              <span className="flex items-center gap-2 font-semibold"><Logo /> ColdChain Sentinel</span>
              <button aria-label="Close menu" onClick={() => setMobile(false)} className="rounded p-1 text-fg-3 hover:text-fg"><X size={18} /></button>
            </div>
            <SideNav collapsed={false} onNavigate={() => setMobile(false)} />
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex min-h-14 flex-wrap items-center gap-x-3 gap-y-1 border-b border-line bg-ink-900/95 px-3 py-2 backdrop-blur md:px-5">
          <button aria-label="Open menu" onClick={() => setMobile(true)} className="rounded p-1.5 text-fg-2 hover:bg-ink-800 md:hidden"><Menu size={18} /></button>
          <Link to="/" className="flex items-center gap-2 md:hidden"><Logo size={20} /></Link>
          <div className="hidden items-center gap-2 text-[13px] font-semibold md:flex"><Logo size={18} /> ColdChain Sentinel</div>

          <div className="ml-auto flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs">
            <span title={s?.explanation ?? "Waiting for the backend"}>
              {!s ? <Badge>Mode unknown</Badge> : hardware ? <Badge tone="ok" icon={<Dot tone="ok" pulse />}>LIVE HARDWARE</Badge> : <Badge tone="warn" icon={<Dot tone="warn" pulse={s.simulatorRunning} />}>SIMULATION</Badge>}
            </span>
            <span className="inline-flex items-center gap-1.5 text-fg-2" title={backendUp ? "The browser can reach the backend API" : "The browser cannot reach the backend API"}>
              <Dot tone={backendUp ? "ok" : "bad"} /> Backend {backendUp ? "connected" : "unreachable"}
            </span>
            <span className="hidden items-center gap-1.5 text-fg-2 sm:inline-flex" title="Based on server-side last-seen times, not on this browser being open">
              <Dot tone={!s ? "neutral" : s.devices.online > 0 ? "ok" : "warn"} /> {s ? `${s.devices.online} of ${s.devices.total} devices online` : "Devices unknown"}
            </span>
            <span className="hidden text-fg-3 lg:inline" title="Time of the newest reading received by the server">Last reading {ago(lastSync, now)}</span>
            <span className="hidden items-center gap-1 text-fg-3 lg:inline-flex" title={live.connected ? "Live updates through Socket.IO" : "Socket disconnected: using polling"}>
              <Radio size={12} className={live.connected ? "text-ok" : "text-warn"} /> {live.connected ? "Live" : "Polling"}
            </span>
            <button onClick={() => { live.clearUnseen(); nav("/app/alerts"); }} aria-label={`Alerts: ${(s?.openAlerts.openSecurity ?? 0) + (s?.openAlerts.openTemperature ?? 0)} open`} title="Open alerts" className="relative rounded p-1.5 text-fg-2 hover:bg-ink-800 hover:text-fg">
              <Bell size={16} />
              {(s?.openAlerts.openSecurity ?? 0) > 0 && <span className="absolute right-0.5 top-0.5 h-2 w-2 rounded-full bg-bad" />}
              {(s?.openAlerts.openSecurity ?? 0) === 0 && (s?.openAlerts.openTemperature ?? 0) > 0 && <span className="absolute right-0.5 top-0.5 h-2 w-2 rounded-full bg-warn" />}
            </button>
            <div className="flex items-center gap-2 border-l border-line pl-3">
              <div className="hidden text-right leading-tight sm:block"><div className="text-[12px] text-fg">{user?.name}</div><div className="text-[11px] text-fg-3">{user?.role === "ADMIN" ? "Administrator" : "Viewer"}</div></div>
              <button onClick={async () => { await logout(); nav("/login"); }} aria-label="Log out" title="Log out" className="rounded p-1.5 text-fg-2 hover:bg-ink-800 hover:text-fg"><LogOut size={16} /></button>
            </div>
          </div>
        </header>
        <main className="min-w-0 flex-1 px-3 py-5 md:px-6"><Outlet /></main>
        <footer className="border-t border-line-soft px-5 py-3 text-[11px] text-fg-3">Educational prototype. Not a certified or regulator-approved medical monitoring system.</footer>
      </div>
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-xl font-semibold tracking-tight">{title}</h1>{description && <p className="mt-1 max-w-2xl text-[13px] text-fg-3">{description}</p>}</div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
export { ShieldCheck };
