import { CheckCircle2, XCircle, Info } from "lucide-react";
import { createContext, type ReactNode, useCallback, useContext, useState } from "react";

type T = { id: number; tone: "ok" | "bad" | "info"; text: string };
const Ctx = createContext<{ push: (tone: T["tone"], text: string) => void }>({ push: () => {} });

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<T[]>([]);
  const push = useCallback((tone: T["tone"], text: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x.slice(-3), { id, tone, text }]);
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), tone === "bad" ? 7000 : 4000);
  }, []);
  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2">
        {items.map((i) => (
          <div key={i.id} role="status" className="cc-in pointer-events-auto flex items-start gap-2 rounded-md border border-line bg-ink-800 p-3 text-[13px] shadow-xl">
            {i.tone === "ok" ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-ok" /> : i.tone === "bad" ? <XCircle size={16} className="mt-0.5 shrink-0 text-bad" /> : <Info size={16} className="mt-0.5 shrink-0 text-cyan" />}
            <span className="text-fg">{i.text}</span>
          </div>))}
      </div>
    </Ctx.Provider>
  );
}
export const useToast = () => useContext(Ctx);
