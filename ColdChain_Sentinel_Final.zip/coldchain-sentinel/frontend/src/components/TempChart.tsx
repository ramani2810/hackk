import { CartesianGrid, Line, LineChart, ReferenceArea, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Reading } from "../lib/types";
import { fmtTime } from "../lib/format";

export function TempChart({ readings, minC, maxC, height = 260 }: { readings: Reading[]; minC: number; maxC: number; height?: number }) {
  const data = readings.map((r) => ({ t: r.receivedAt, temp: r.sensorStatus === "OK" ? r.temperatureC : null, seq: r.sequence, status: r.sensorStatus, bad: r.integrity.status !== "VERIFIED" && r.integrity.status !== "UNVERIFIED" }));
  const temps = data.map((d) => d.temp).filter((v): v is number => v !== null);
  const lo = Math.floor(Math.min(minC, ...temps) - 1);
  const hi = Math.ceil(Math.max(maxC, ...temps) + 1);
  return (
    <div style={{ height }} role="img" aria-label={`Temperature history, allowed range ${minC} to ${maxC} degrees Celsius`}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 14, bottom: 0, left: -12 }}>
          <CartesianGrid stroke="#16253f" vertical={false} />
          <ReferenceArea y1={minC} y2={maxC} fill="#35d399" fillOpacity={0.07} />
          <ReferenceLine y={maxC} stroke="#f5b547" strokeDasharray="4 3" strokeOpacity={0.8} label={{ value: `${maxC} °C max`, fill: "#f5b547", fontSize: 10, position: "insideTopRight" }} />
          <ReferenceLine y={minC} stroke="#f5b547" strokeDasharray="4 3" strokeOpacity={0.8} label={{ value: `${minC} °C min`, fill: "#f5b547", fontSize: 10, position: "insideBottomRight" }} />
          <XAxis dataKey="t" tickFormatter={(v: string) => fmtTime(v, { seconds: false, date: false })} stroke="#8397b5" fontSize={11} tickLine={false} minTickGap={40} />
          <YAxis domain={[lo, hi]} stroke="#8397b5" fontSize={11} tickLine={false} axisLine={false} width={44} tickFormatter={(v: number) => `${v}°`} />
          <Tooltip
            contentStyle={{ background: "#0a1424", border: "1px solid #27406a", borderRadius: 6, fontSize: 12 }} labelStyle={{ color: "#b4c2d8" }}
            labelFormatter={(v) => fmtTime(String(v), { date: true })}
            formatter={(v, _n, item) => [v === null || v === undefined ? "no valid reading" : `${Number(v).toFixed(2)} °C`, `#${(item.payload as { seq: number }).seq}`]} />
          <Line type="monotone" dataKey="temp" stroke="#3cc8e8" strokeWidth={2} isAnimationActive={false} connectNulls={false}
            dot={(p: { cx?: number; cy?: number; payload?: { temp: number | null }; index?: number }) => {
              const v = p.payload?.temp;
              if (v === null || v === undefined || p.cx === undefined || p.cy === undefined) return <g key={p.index} />;
              const out = v > maxC || v < minC;
              return out ? <circle key={p.index} cx={p.cx} cy={p.cy} r={3.5} fill="#f5b547" stroke="#0a1424" strokeWidth={1} /> : <g key={p.index} />;
            }} activeDot={{ r: 4, fill: "#3cc8e8" }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
