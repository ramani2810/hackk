import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./app/auth";
import { LiveProvider } from "./app/live";
import { Shell } from "./components/Shell";
import { Spinner } from "./components/ui";
import Alerts from "./pages/Alerts";
import Audit from "./pages/Audit";
import Devices from "./pages/Devices";
import Landing from "./pages/Landing";
import Ledger from "./pages/Ledger";
import Live from "./pages/Live";
import Login from "./pages/Login";
import Overview from "./pages/Overview";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
import Shipments from "./pages/Shipments";
import TamperLab from "./pages/TamperLab";

function Protected({ admin, children }: { admin?: boolean; children: React.ReactNode }) {
  const { user, loading, isAdmin } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="flex min-h-screen items-center justify-center"><Spinner label="Checking your session" /></div>;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  if (admin && !isAdmin) return <Navigate to="/app" replace />;
  return <>{children}</>;
}

function AppFrame() {
  return (
    <Protected>
      <LiveProvider>
        <Shell />
      </LiveProvider>
    </Protected>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/app" element={<AppFrame />}>
        <Route index element={<Overview />} />
        <Route path="live" element={<Live />} />
        <Route path="devices" element={<Devices />} />
        <Route path="shipments" element={<Shipments />} />
        <Route path="ledger" element={<Ledger />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="audit" element={<Protected admin><Audit /></Protected>} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
        <Route path="tamper-lab" element={<Protected admin><TamperLab /></Protected>} />
        <Route path="*" element={<Navigate to="/app" replace />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
